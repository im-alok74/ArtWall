import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router'
import App from './App'
import SignUp from './pages/auth/SignUp'
import SignIn from './pages/auth/SignIn'
import Welcome from './pages/auth/Welcome'
import StudioShell from './pages/studio/StudioShell'
import StudioOverview from './pages/studio/StudioOverview'
import Artworks from './pages/studio/Artworks'
import ArtworkNew from './pages/studio/ArtworkNew'
import Collections from './pages/studio/Collections'
import Sales from './pages/studio/Sales'
import StudioEmpty from './pages/studio/StudioEmpty'
import Ops from './pages/wall-staff/Ops'
import PerkCounter from './pages/wall-staff/PerkCounter'
import AdminShell from './pages/wall-admin/AdminShell'
import AdminOverview from './pages/wall-admin/AdminOverview'
import AdminGrid from './pages/wall-admin/AdminGrid'
import AdminCalendar from './pages/wall-admin/AdminCalendar'
import AdminBookings from './pages/wall-admin/AdminBookings'
import AdminQueue from './pages/wall-admin/AdminQueue'
import AdminCatalogs from './pages/wall-admin/AdminCatalogs'
import AdminLedger from './pages/wall-admin/AdminLedger'
import './index.css'

function StudioPlaceholder({ name }: { name: string }) {
  return (
    <StudioEmpty
      icon="◻"
      title={`${name} coming soon.`}
      body={`The ${name.toLowerCase()} section is being built. Check back soon.`}
      ctaLabel="Back to overview"
      ctaHref="/studio"
    />
  )
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />} />
        <Route path="/sign-up" element={<SignUp />} />
        <Route path="/sign-in" element={<SignIn />} />
        <Route path="/physical-wall/welcome" element={<Welcome />} />
        <Route path="/physical-wall/ops" element={<Ops />} />
        <Route path="/physical-wall/ops/perk/:token" element={<PerkCounter />} />
        <Route path="/physical-wall/admin" element={<AdminShell />}>
          <Route index element={<AdminOverview />} />
          <Route path="grid" element={<AdminGrid />} />
          <Route path="calendar" element={<AdminCalendar />} />
          <Route path="bookings" element={<AdminBookings />} />
          <Route path="queue" element={<AdminQueue />} />
          <Route path="catalogs" element={<AdminCatalogs />} />
          <Route path="ledger" element={<AdminLedger />} />
        </Route>
        <Route path="/studio" element={<StudioShell />}>
          <Route index element={<StudioOverview />} />
          <Route path="artworks" element={<Artworks />} />
          <Route path="artworks/new" element={<ArtworkNew />} />
          <Route path="collections" element={<Collections />} />
          <Route path="sales" element={<Sales />} />
          <Route path="series" element={<StudioPlaceholder name="Series" />} />
          <Route path="exhibitions" element={<StudioPlaceholder name="Exhibitions" />} />
          <Route path="rooms" element={<StudioPlaceholder name="Rooms" />} />
          <Route path="locations" element={<StudioPlaceholder name="Locations" />} />
          <Route path="calendar" element={<StudioPlaceholder name="Calendar" />} />
          <Route path="tasks" element={<StudioPlaceholder name="Tasks" />} />
          <Route path="contacts" element={<StudioPlaceholder name="Contacts" />} />
          <Route path="invoices" element={<StudioPlaceholder name="Invoices" />} />
          <Route path="payments" element={<StudioPlaceholder name="Payments" />} />
          <Route path="documents" element={<StudioPlaceholder name="Documents" />} />
          <Route path="certificates" element={<StudioPlaceholder name="Certificates" />} />
          <Route path="provenance" element={<StudioPlaceholder name="Provenance" />} />
          <Route path="insights" element={<StudioPlaceholder name="Insights" />} />
          <Route path="reports" element={<StudioPlaceholder name="Reports" />} />
          <Route path="settings" element={<StudioPlaceholder name="Settings" />} />
        </Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>,
)
