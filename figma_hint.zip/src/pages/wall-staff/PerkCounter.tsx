import { useState } from 'react'
import { t } from '../../components/tokens'

type CounterState = 'eligible' | 'ineligible' | 'redeemed'

export default function PerkCounter() {
  const [state, setState] = useState<CounterState>('eligible')
  const [billInput, setBillInput] = useState('')
  const [confirmed, setConfirmed] = useState(false)

  const bill = parseFloat(billInput) || 0
  const discount = Math.round(bill * 0.1)
  const customerPays = bill - discount

  function handleRedeem() {
    setConfirmed(true)
  }

  const tabStyle = (active: boolean): React.CSSProperties => ({
    padding: '8px 16px',
    fontFamily: 'var(--font-sans)',
    fontSize: 12,
    fontWeight: 600,
    cursor: 'pointer',
    border: 'none',
    borderRadius: 4,
    background: active ? t.ink : 'transparent',
    color: active ? t.wallPaper : t.inkMuted,
    transition: 'background 0.15s',
  })

  return (
    <div style={{
      minHeight: '100vh',
      background: t.wallPaper,
      fontFamily: 'var(--font-sans)',
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* Demo state selector */}
      <div style={{
        background: t.band,
        borderBottom: `1px solid ${t.hairline}`,
        padding: '10px 16px',
        display: 'flex',
        gap: 4,
        alignItems: 'center',
      }}>
        <span style={{ fontSize: 11, color: t.inkMuted, marginRight: 8, letterSpacing: '0.04em', textTransform: 'uppercase' }}>
          Demo state:
        </span>
        <button style={tabStyle(state === 'eligible')} onClick={() => { setState('eligible'); setConfirmed(false); setBillInput('') }}>
          Eligible
        </button>
        <button style={tabStyle(state === 'ineligible')} onClick={() => setState('ineligible')}>
          Ineligible
        </button>
        <button style={tabStyle(state === 'redeemed')} onClick={() => setState('redeemed')}>
          Already redeemed
        </button>
      </div>

      {/* Main content */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '40px 24px', maxWidth: 480, width: '100%', margin: '0 auto', boxSizing: 'border-box' }}>

        {/* ── ELIGIBLE ── */}
        {state === 'eligible' && !confirmed && (
          <div>
            <div style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(36px, 8vw, 52px)',
              fontWeight: 600,
              color: '#166534',
              letterSpacing: '-0.03em',
              lineHeight: 1.1,
              marginBottom: 4,
            }}>
              Coupon valid
            </div>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, marginBottom: 32 }}>
              Visitor: Rahul Sharma
            </div>

            <label style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 10 }}>
              Enter bill total:
            </label>
            <div style={{ display: 'flex', alignItems: 'center', gap: 0, marginBottom: 24 }}>
              <span style={{
                padding: '14px 16px',
                background: t.band,
                border: `1px solid ${t.hairline}`,
                borderRight: 'none',
                borderRadius: '4px 0 0 4px',
                fontFamily: 'var(--font-heading)',
                fontSize: 28,
                color: t.ink,
              }}>₹</span>
              <input
                type="number"
                inputMode="numeric"
                value={billInput}
                onChange={e => setBillInput(e.target.value)}
                placeholder="0"
                style={{
                  flex: 1,
                  padding: '14px 16px',
                  fontFamily: 'var(--font-heading)',
                  fontSize: 32,
                  fontWeight: 500,
                  color: t.ink,
                  background: t.band,
                  border: `1px solid ${t.hairline}`,
                  borderRadius: '0 4px 4px 0',
                  outline: 'none',
                  letterSpacing: '-0.02em',
                }}
              />
            </div>

            {bill > 0 && (
              <div style={{
                background: t.band,
                border: `1px solid ${t.hairline}`,
                borderRadius: 4,
                padding: '20px 24px',
                marginBottom: 28,
                display: 'flex',
                flexDirection: 'column',
                gap: 16,
              }}>
                <div>
                  <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginBottom: 4 }}>Discount (10%)</div>
                  <div style={{ fontFamily: 'var(--font-heading)', fontSize: 36, fontWeight: 500, color: '#166534', letterSpacing: '-0.03em' }}>
                    ₹{discount.toLocaleString('en-IN')}
                  </div>
                </div>
                <div style={{ height: 1, background: t.hairline }} />
                <div>
                  <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginBottom: 4 }}>Customer pays</div>
                  <div style={{ fontFamily: 'var(--font-heading)', fontSize: 44, fontWeight: 600, color: t.ink, letterSpacing: '-0.04em' }}>
                    ₹{customerPays.toLocaleString('en-IN')}
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={handleRedeem}
              disabled={bill <= 0}
              style={{
                width: '100%',
                minHeight: 56,
                background: bill > 0 ? t.ink : t.hairline,
                color: bill > 0 ? t.wallPaper : t.inkMuted,
                border: 'none',
                borderRadius: 4,
                fontFamily: 'var(--font-sans)',
                fontSize: 17,
                fontWeight: 700,
                cursor: bill > 0 ? 'pointer' : 'not-allowed',
                letterSpacing: '-0.01em',
                transition: 'background 0.2s',
              }}
            >
              Mark as redeemed
            </button>
          </div>
        )}

        {/* ── ELIGIBLE confirmed ── */}
        {state === 'eligible' && confirmed && (
          <div style={{ textAlign: 'center' }}>
            <div style={{
              width: 80, height: 80, borderRadius: '50%',
              background: '#dcfce7',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              margin: '0 auto 24px',
              fontSize: 36,
            }}>✓</div>
            <div style={{ fontFamily: 'var(--font-heading)', fontSize: 40, fontWeight: 600, color: '#166534', letterSpacing: '-0.03em', marginBottom: 8 }}>
              Redeemed
            </div>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: 15, color: t.inkMuted, marginBottom: 32 }}>
              Discount of ₹{discount.toLocaleString('en-IN')} applied
            </div>
            <button
              onClick={() => { setConfirmed(false); setBillInput('') }}
              style={{
                padding: '14px 32px',
                background: t.ink,
                color: t.wallPaper,
                border: 'none',
                borderRadius: 4,
                fontFamily: 'var(--font-sans)',
                fontSize: 15,
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              Done
            </button>
          </div>
        )}

        {/* ── INELIGIBLE ── */}
        {state === 'ineligible' && (
          <div>
            <div style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(28px, 7vw, 44px)',
              fontWeight: 600,
              color: t.destructive,
              letterSpacing: '-0.03em',
              lineHeight: 1.2,
              marginBottom: 20,
            }}>
              Coupon not valid for this visit
            </div>
            <div style={{
              background: '#fee2e2',
              borderRadius: 4,
              padding: '20px 20px',
              marginBottom: 32,
            }}>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 15, color: '#991b1b', lineHeight: 1.6 }}>
                This coupon is for art wall visitors only. The customer must have scanned a QR code at the wall.
              </div>
            </div>
            <button
              style={{
                width: '100%',
                minHeight: 52,
                background: t.ink,
                color: t.wallPaper,
                border: 'none',
                borderRadius: 4,
                fontFamily: 'var(--font-sans)',
                fontSize: 16,
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              OK
            </button>
          </div>
        )}

        {/* ── ALREADY REDEEMED ── */}
        {state === 'redeemed' && (
          <div>
            <div style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(28px, 7vw, 44px)',
              fontWeight: 600,
              color: t.ink,
              letterSpacing: '-0.03em',
              lineHeight: 1.2,
              marginBottom: 20,
            }}>
              Coupon already used
            </div>
            <div style={{
              background: t.band,
              border: `1px solid ${t.hairline}`,
              borderRadius: 4,
              padding: '20px 20px',
              marginBottom: 32,
            }}>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 4 }}>Redeemed at</div>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500, color: t.ink, letterSpacing: '-0.02em' }}>
                2:34 PM today
              </div>
            </div>
            <button
              style={{
                width: '100%',
                minHeight: 52,
                background: t.ink,
                color: t.wallPaper,
                border: 'none',
                borderRadius: 4,
                fontFamily: 'var(--font-sans)',
                fontSize: 16,
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              OK
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
