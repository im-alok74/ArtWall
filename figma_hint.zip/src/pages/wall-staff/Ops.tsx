import { useState } from 'react'
import { t } from '../../components/tokens'
import { Badge, Btn } from '../../components/ui'

// ─── Types ────────────────────────────────────────────────────────────────────

type OpsStatus = 'Received' | 'Checklist' | 'Ready to go live'

interface CheckItem {
  id: string
  label: string
  why: string
}

interface Booking {
  ref: string
  artist: string
  artwork: string
  slot: string
  status: OpsStatus
  checked: Record<string, boolean>
  liveConfirmed: boolean
  manualCode: string
}

// ─── Constants ────────────────────────────────────────────────────────────────

const CHECKLIST: CheckItem[] = [
  { id: 'match', label: 'Artwork matches booking', why: 'Artist may have substituted a different piece' },
  { id: 'damage', label: 'No damage on arrival', why: 'Insurance claim needs pre-hang record' },
  { id: 'dims', label: 'Dimensions correct for slot', why: 'Slot B2 fits max 80 cm wide' },
  { id: 'label', label: 'Artist label attached', why: 'QR must be affixed before hanging' },
  { id: 'payment', label: 'Payment confirmed', why: 'Artwork goes up only after payment clears' },
]

const INITIAL_BOOKINGS: Booking[] = [
  {
    ref: 'AWL-2025-0841',
    artist: 'Meera Iyer',
    artwork: "Monsoon Light III",
    slot: 'A3',
    status: 'Received',
    checked: {},
    liveConfirmed: false,
    manualCode: '',
  },
  {
    ref: 'AWL-2025-0839',
    artist: 'Rohan Das',
    artwork: "City at Rest",
    slot: 'B2',
    status: 'Checklist',
    checked: { match: true, damage: true, dims: false, label: false, payment: true },
    liveConfirmed: false,
    manualCode: '',
  },
  {
    ref: 'AWL-2025-0836',
    artist: 'Priya Mehta',
    artwork: "Still — Garden Series #4",
    slot: 'C1',
    status: 'Ready to go live',
    checked: { match: true, damage: true, dims: true, label: true, payment: true },
    liveConfirmed: false,
    manualCode: '',
  },
]

// ─── Status badge mapping ──────────────────────────────────────────────────────

function statusBadge(s: OpsStatus) {
  if (s === 'Ready to go live') return <Badge label="Ready to go live" color="live" />
  if (s === 'Checklist') return <Badge label="Checklist" color="held" />
  return <Badge label="Received" color="default" />
}

// ─── Receive step ─────────────────────────────────────────────────────────────

function ReceiveStep({ onConfirm }: { onConfirm: () => void }) {
  return (
    <div style={{ marginTop: 16 }}>
      <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, marginBottom: 16 }}>
        Tap the button once the artwork is physically in your hands.
      </p>
      <button
        onClick={onConfirm}
        style={{
          width: '100%', minHeight: 52, background: t.ink, color: t.wallPaper,
          border: 'none', borderRadius: 4, fontFamily: 'var(--font-sans)',
          fontSize: 16, fontWeight: 600, cursor: 'pointer', letterSpacing: '-0.01em',
        }}
      >
        Mark as received
      </button>
    </div>
  )
}

// ─── Checklist step ───────────────────────────────────────────────────────────

function ChecklistStep({
  checked,
  onToggle,
  onReady,
}: {
  checked: Record<string, boolean>
  onToggle: (id: string) => void
  onReady: () => void
}) {
  const allDone = CHECKLIST.every(c => checked[c.id])
  return (
    <div style={{ marginTop: 16 }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
        {CHECKLIST.map((item, i) => (
          <label
            key={item.id}
            style={{
              display: 'flex', gap: 14, alignItems: 'flex-start',
              padding: '14px 0',
              borderBottom: i < CHECKLIST.length - 1 ? `1px solid ${t.hairline}` : 'none',
              cursor: 'pointer',
            }}
          >
            <input
              type="checkbox"
              checked={!!checked[item.id]}
              onChange={() => onToggle(item.id)}
              style={{ width: 22, height: 22, marginTop: 2, accentColor: t.ink, flexShrink: 0 }}
            />
            <div>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 15, fontWeight: 500, color: t.ink, lineHeight: 1.4 }}>
                {item.label}
              </div>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginTop: 2, lineHeight: 1.5 }}>
                {item.why}
              </div>
            </div>
          </label>
        ))}
      </div>
      <button
        onClick={onReady}
        disabled={!allDone}
        style={{
          width: '100%', minHeight: 52, marginTop: 20,
          background: allDone ? t.ink : t.hairline,
          color: allDone ? t.wallPaper : t.inkMuted,
          border: 'none', borderRadius: 4, fontFamily: 'var(--font-sans)',
          fontSize: 16, fontWeight: 600, cursor: allDone ? 'pointer' : 'not-allowed',
          letterSpacing: '-0.01em', transition: 'background 0.2s',
        }}
      >
        Mark ready
      </button>
    </div>
  )
}

// ─── Go-live step ─────────────────────────────────────────────────────────────

function GoLiveStep({
  manualCode,
  onCodeChange,
  liveConfirmed,
  onActivate,
}: {
  manualCode: string
  onCodeChange: (v: string) => void
  liveConfirmed: boolean
  onActivate: () => void
}) {
  if (liveConfirmed) {
    return (
      <div style={{
        marginTop: 16, background: '#dcfce7', borderRadius: 4,
        padding: 32, textAlign: 'center',
      }}>
        <div style={{
          fontFamily: 'var(--font-heading)', fontSize: 56, fontWeight: 600,
          color: '#166534', letterSpacing: '-0.04em', lineHeight: 1,
        }}>
          LIVE
        </div>
        <div style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: '#166534', marginTop: 8 }}>
          Artwork is now active on the wall
        </div>
      </div>
    )
  }

  return (
    <div style={{ marginTop: 16 }}>
      {/* QR placeholder */}
      <div style={{
        width: '100%', aspectRatio: '1', maxWidth: 260, margin: '0 auto',
        background: t.band, border: `2px dashed ${t.hairline}`,
        borderRadius: 4, display: 'flex', alignItems: 'center',
        justifyContent: 'center', flexDirection: 'column', gap: 10,
      }}>
        <div style={{ fontSize: 56 }}>⬛</div>
        <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, textAlign: 'center' }}>
          Point camera at<br />slot QR code
        </div>
      </div>

      {/* Manual fallback */}
      <div style={{ marginTop: 24 }}>
        <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginBottom: 8 }}>
          Enter code manually
        </div>
        <input
          type="text"
          value={manualCode}
          onChange={e => onCodeChange(e.target.value)}
          placeholder="e.g. AWL-A3-0836"
          inputMode="text"
          style={{
            width: '100%', padding: '12px 14px', fontFamily: 'var(--font-sans)',
            fontSize: 18, color: t.ink, background: t.band,
            border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none',
            boxSizing: 'border-box',
          }}
        />
        <button
          onClick={onActivate}
          disabled={!manualCode.trim()}
          style={{
            width: '100%', minHeight: 52, marginTop: 12,
            background: manualCode.trim() ? t.signal : t.hairline,
            color: manualCode.trim() ? t.wallPaper : t.inkMuted,
            border: 'none', borderRadius: 4, fontFamily: 'var(--font-sans)',
            fontSize: 16, fontWeight: 600, cursor: manualCode.trim() ? 'pointer' : 'not-allowed',
            letterSpacing: '-0.01em', transition: 'background 0.2s',
          }}
        >
          Activate
        </button>
      </div>
    </div>
  )
}

// ─── Booking card ──────────────────────────────────────────────────────────────

function BookingCard({
  booking,
  onReceive,
  onToggleCheck,
  onMarkReady,
  onActivate,
  onCodeChange,
}: {
  booking: Booking
  onReceive: () => void
  onToggleCheck: (id: string) => void
  onMarkReady: () => void
  onActivate: () => void
  onCodeChange: (v: string) => void
}) {
  return (
    <div style={{
      background: t.wallPaper, border: `1px solid ${t.hairline}`,
      borderRadius: 4, padding: 20, marginBottom: 16,
    }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 }}>
        <div>
          <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted, letterSpacing: '0.04em', textTransform: 'uppercase' }}>
            {booking.ref}
          </div>
          <div style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 500, color: t.ink, letterSpacing: '-0.02em', lineHeight: 1.2, marginTop: 2 }}>
            {booking.artist}
          </div>
        </div>
        {statusBadge(booking.status)}
      </div>
      <div style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, marginBottom: 4 }}>
        {booking.artwork}
      </div>
      <div style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        background: t.band, borderRadius: 4, padding: '4px 10px',
        fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 600, color: t.ink,
        marginBottom: 4,
      }}>
        Slot {booking.slot}
      </div>

      {/* Step content */}
      {booking.status === 'Received' && <ReceiveStep onConfirm={onReceive} />}
      {booking.status === 'Checklist' && (
        <ChecklistStep
          checked={booking.checked}
          onToggle={onToggleCheck}
          onReady={onMarkReady}
        />
      )}
      {booking.status === 'Ready to go live' && (
        <GoLiveStep
          manualCode={booking.manualCode}
          onCodeChange={onCodeChange}
          liveConfirmed={booking.liveConfirmed}
          onActivate={onActivate}
        />
      )}
    </div>
  )
}

// ─── Page ──────────────────────────────────────────────────────────────────────

export default function Ops() {
  const [bookings, setBookings] = useState<Booking[]>(INITIAL_BOOKINGS)

  function update(ref: string, patch: Partial<Booking>) {
    setBookings(bs => bs.map(b => b.ref === ref ? { ...b, ...patch } : b))
  }

  return (
    <div style={{
      minHeight: '100vh', background: t.band,
      fontFamily: 'var(--font-sans)',
    }}>
      {/* Top bar */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 50,
        background: t.ink, color: t.wallPaper,
        padding: '14px 20px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div>
          <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: 'rgba(255,255,255,0.5)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            ArtWall Labs
          </div>
          <div style={{ fontFamily: 'var(--font-heading)', fontSize: 18, fontWeight: 500, letterSpacing: '-0.02em' }}>
            Install Queue
          </div>
        </div>
        <div style={{
          background: 'rgba(255,255,255,0.12)', borderRadius: 4,
          padding: '4px 10px', fontSize: 12, fontWeight: 600,
        }}>
          {bookings.length} pending
        </div>
      </div>

      {/* Queue */}
      <div style={{ padding: '20px 16px', maxWidth: 520, margin: '0 auto' }}>
        {bookings.map(b => (
          <BookingCard
            key={b.ref}
            booking={b}
            onReceive={() => update(b.ref, { status: 'Checklist', checked: {} })}
            onToggleCheck={id => update(b.ref, {
              checked: { ...b.checked, [id]: !b.checked[id] }
            })}
            onMarkReady={() => update(b.ref, { status: 'Ready to go live' })}
            onActivate={() => update(b.ref, { liveConfirmed: true })}
            onCodeChange={v => update(b.ref, { manualCode: v })}
          />
        ))}
      </div>
    </div>
  )
}
