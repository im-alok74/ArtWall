import { t } from '../components/tokens'
import { Eyebrow, Hairline, PageShell } from '../components/ui'

interface Field {
  field: string
  description: string
}

interface System {
  num: string
  name: string
  heading: string
  lead: string
  fields: Field[]
}

const systems: System[] = [
  {
    num: '01',
    name: 'Catalogue',
    heading: 'Artwork Catalogue',
    lead: "Every artwork in the ArtWall ecosystem begins as a catalogue record. The Catalogue system is the canonical store for all artwork metadata — from creation details to market status — and acts as the source of truth for every downstream system.",
    fields: [
      { field: 'catalogue_id', description: 'Unique identifier assigned at upload (UUID v4)' },
      { field: 'title', description: 'Artwork title as provided by the artist' },
      { field: 'medium', description: 'e.g. Oil on canvas, Watercolour, Digital print' },
      { field: 'dimensions', description: 'Height × Width × Depth in centimetres' },
      { field: 'year', description: 'Year of creation or completion' },
      { field: 'edition', description: 'Edition number and total run (e.g. 3/10), or "Unique"' },
      { field: 'asking_price', description: 'Listed price in INR; set by the artist' },
      { field: 'status', description: '"available", "reserved", or "sold"' },
      { field: 'provenance_id', description: 'Foreign key to the Provenance certificate record' },
    ],
  },
  {
    num: '02',
    name: 'Physical Wall',
    heading: 'Physical Wall Bookings',
    lead: "The Physical Wall system manages ArtWall's network of curated venue spaces. Artists browse available slots, reserve wall time, and install their work. The system tracks each venue's inventory, tier pricing, and artwork-slot configuration.",
    fields: [
      { field: 'wall_id', description: 'Unique identifier for each bookable wall panel' },
      { field: 'venue_name', description: 'Name of the partner venue (café, hotel, gallery)' },
      { field: 'city', description: 'One of: Jaipur, Mumbai, Delhi, Bengaluru' },
      { field: 'booking_date', description: 'ISO 8601 date the booking period starts' },
      { field: 'duration_days', description: '7, 14, or 28 days' },
      { field: 'artwork_slots', description: 'Number of panel positions available on this wall' },
      { field: 'fee_structure', description: 'Tier label (Standard / Premium / Flagship) and fee in INR' },
      { field: 'status', description: '"open", "booked", or "completed"' },
    ],
  },
  {
    num: '03',
    name: 'Provenance',
    heading: 'Provenance Certificates',
    lead: "Provenance is ArtWall's integrity layer. Every artwork carries a cryptographically signed certificate that records its origin, ownership chain, and any subsequent transfers. QR codes on physical panels link directly to the live provenance page.",
    fields: [
      { field: 'certificate_id', description: 'Unique certificate identifier (UUID v4)' },
      { field: 'artwork_id', description: 'Foreign key to the Catalogue record' },
      { field: 'artist_id', description: 'Foreign key to the artist profile' },
      { field: 'issued_at', description: 'ISO 8601 timestamp of certificate issuance' },
      { field: 'sha256_hash', description: 'Hash of the canonical artwork metadata at time of issue' },
      { field: 'transfer_log', description: 'Ordered array of ownership transfer events (buyer, date, price)' },
      { field: 'qr_scans', description: 'Total lifetime scan count for the physical QR panel' },
    ],
  },
  {
    num: '04',
    name: 'Sales',
    heading: 'Sales Ledger',
    lead: "The Sales system records every completed and in-progress transaction on the platform. It enforces ArtWall's fee structure, calculates artist payouts, and maintains an auditable ledger for both collectors and artists.",
    fields: [
      { field: 'transaction_id', description: 'Unique transaction identifier' },
      { field: 'artwork_id', description: 'Foreign key to the Catalogue record being sold' },
      { field: 'buyer_type', description: '"collector", "institution", or "gallery"' },
      { field: 'gross_amount', description: 'Total transaction value in INR' },
      { field: 'platform_fee_pct', description: 'ArtWall platform fee (8% of gross)' },
      { field: 'artist_royalty', description: 'Amount remitted to artist (92% on primary; 5% on resale)' },
      { field: 'status', description: '"pending", "completed", or "refunded"' },
      { field: 'payout_date', description: 'Date of NEFT/UPI payout to the artist (1st of month)' },
    ],
  },
  {
    num: '05',
    name: 'Studio',
    heading: 'Studio Dashboard',
    lead: "Studio is the artist-facing command centre. It surfaces real-time metrics on catalogue performance, wall bookings, visitor engagement, and revenue — giving artists the data they need to grow their practice on and off the platform.",
    fields: [
      { field: 'artist_id', description: 'Foreign key to the artist profile' },
      { field: 'draft_count', description: 'Artworks saved as drafts, not yet published' },
      { field: 'published_count', description: 'Artworks live in the catalogue' },
      { field: 'wall_bookings_active', description: 'Number of currently active wall bookings' },
      { field: 'qr_scans_30d', description: 'Total QR panel scans in the last 30 days' },
      { field: 'enquiries_pending', description: 'Open buyer enquiries awaiting artist response' },
      { field: 'revenue_ytd', description: 'Year-to-date net revenue in INR after platform fees' },
    ],
  },
  {
    num: '06',
    name: 'Community',
    heading: 'Community Layer',
    lead: "The Community system models the social fabric of the ArtWall artist network. It tracks cohort membership, trust signals, and collaborative activity — enabling ArtWall to surface opportunities, match collaborators, and reward engaged members.",
    fields: [
      { field: 'cohort_id', description: 'The intake cohort the artist joined (e.g. "2024-Q2")' },
      { field: 'archetype', description: '"Emerging", "Mid-career", or "Established"' },
      { field: 'trust_score', description: 'Composite score (0–100) based on sales, scans, and tenure' },
      { field: 'referrals_sent', description: 'Number of successful artist referrals to the platform' },
      { field: 'collaborations', description: 'Count of joint-wall or co-catalogue collaborations completed' },
      { field: 'wall_shares', description: 'Times the artist has shared a wall slot with another artist' },
    ],
  },
]

function DataTable({ fields }: { fields: Field[] }) {
  return (
    <div style={{ border: `1px solid ${t.hairline}`, borderRadius: 4, overflow: 'hidden', marginTop: 28 }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: 'var(--font-sans)', fontSize: 13 }}>
        <thead>
          <tr style={{ background: t.ink }}>
            <th style={{ textAlign: 'left', padding: '10px 14px', color: t.wallPaper, fontWeight: 500, width: '30%', letterSpacing: '-0.01em' }}>Field</th>
            <th style={{ textAlign: 'left', padding: '10px 14px', color: t.wallPaper, fontWeight: 500, letterSpacing: '-0.01em' }}>Description</th>
          </tr>
        </thead>
        <tbody>
          {fields.map((row, i) => (
            <tr key={row.field} style={{ background: i % 2 === 0 ? t.wallPaper : t.band }}>
              <td style={{ padding: '10px 14px', color: t.signal, fontWeight: 500, borderTop: `1px solid ${t.hairline}` }}>
                <code style={{ fontFamily: 'monospace', fontSize: 12 }}>{row.field}</code>
              </td>
              <td style={{ padding: '10px 14px', color: t.inkMuted, borderTop: `1px solid ${t.hairline}`, lineHeight: 1.6 }}>{row.description}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default function Platform() {
  return (
    <PageShell>
      <div style={{ marginBottom: 16 }}>
        <Eyebrow chapter="03" label="Platform" />
      </div>
      <h1 style={{
        fontFamily: 'var(--font-heading)',
        fontSize: 'clamp(36px, 5vw, 48px)',
        fontWeight: 500,
        letterSpacing: '-0.03em',
        lineHeight: 1.15,
        color: t.ink,
        marginBottom: 80,
      }}>
        The Six Systems
      </h1>

      {systems.map((sys, i) => (
        <div key={sys.num}>
          {i > 0 && <Hairline />}
          <section style={{ padding: '64px 0' }}>
            <div style={{ marginBottom: 16 }}>
              <Eyebrow chapter={sys.num} label={sys.name} />
            </div>
            <h2 style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 32,
              fontWeight: 500,
              letterSpacing: '-0.025em',
              lineHeight: 1.25,
              color: t.ink,
              marginTop: 20,
              marginBottom: 16,
            }}>
              {sys.heading}
            </h2>
            <p style={{
              fontFamily: 'var(--font-sans)',
              fontSize: 15,
              color: t.inkMuted,
              lineHeight: 1.7,
              maxWidth: 600,
              margin: 0,
            }}>
              {sys.lead}
            </p>
            <DataTable fields={sys.fields} />
          </section>
        </div>
      ))}
    </PageShell>
  )
}
