import { useState } from 'react'
import { t } from '../components/tokens'
import { Eyebrow, Hairline, PageShell, Btn } from '../components/ui'

const steps = [
  {
    question: "What drives your practice?",
    options: [
      "Documenting place and memory — my work is rooted in a specific geography",
      "Formal experimentation — I push medium and material to their limits",
      "The market relationship — I want to build a sustainable income from my art",
      "Community and dialogue — I make work to spark conversation",
    ],
  },
  {
    question: "How do you currently sell?",
    options: [
      "Through personal networks and word of mouth",
      "Via gallery representation or art fairs",
      "I rarely sell — most work stays in my studio",
      "Online, through Instagram or direct DMs",
    ],
  },
  {
    question: "What is your biggest obstacle?",
    options: [
      "Nobody knows my work exists",
      "I know people like it but won't pay for it",
      "The logistics of showing and shipping feel impossible",
      "I don't know how to price my work",
    ],
  },
  {
    question: "What would change everything?",
    options: [
      "A permanent, visible home for my catalogue",
      "One institutional sale that legitimises my practice",
      "Recurring income so I can stop teaching part-time",
      "A community of peers who understand the struggle",
    ],
  },
]

const archetypes: Record<string, { name: string; description: string; next: string }> = {
  A: {
    name: "The Documenter",
    description: "Your practice is an archive. You work methodically, building a body of evidence about a place, a community, or a moment in time. ArtWall's Catalogue and Provenance systems were built with you in mind — every scan of your QR code extends the documentary chain.",
    next: "Start cataloguing your works and request your first provenance certificate.",
  },
  B: {
    name: "The Formalist",
    description: "You push against the limits of your medium. Collectors who seek you out are serious, and they stay loyal. ArtWall's Studio analytics will show you exactly who is spending time with your work and where they are in their buying journey.",
    next: "Set up your Studio dashboard and connect your first wall booking.",
  },
  C: {
    name: "The Market Builder",
    description: "You understand that sustaining a practice requires income, and you're not ashamed of it. ArtWall's Sales system, with its 8% flat fee and automatic royalty protocol, is engineered to maximise what stays in your pocket.",
    next: "Review your pricing against comparable works and activate your sales profile.",
  },
  D: {
    name: "The Connector",
    description: "Your practice is inseparable from your community. You thrive when ideas and people collide. ArtWall's Community cohort system, peer introductions, and artist evening programme are where you will find your people.",
    next: "Join your nearest artist cohort and RSVP to an upcoming evening.",
  },
}

function computeResult(answers: Record<number, number>): string {
  const letters = ['A', 'B', 'C', 'D']
  const counts: Record<string, number> = { A: 0, B: 0, C: 0, D: 0 }
  for (const idx of Object.keys(answers)) {
    const letter = letters[answers[Number(idx)]]
    if (letter) counts[letter]++
  }
  let best = 'A'
  let bestCount = -1
  for (const l of letters) {
    if (counts[l] > bestCount) {
      bestCount = counts[l]
      best = l
    }
  }
  return best
}

export default function Community() {
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<Record<number, number>>({})
  const [result, setResult] = useState<string | null>(null)

  const totalSteps = steps.length
  const allAnswered = Object.keys(answers).length === totalSteps

  function selectOption(optionIndex: number) {
    setAnswers(prev => ({ ...prev, [currentStep]: optionIndex }))
    if (currentStep < totalSteps - 1) {
      setCurrentStep(prev => prev + 1)
    }
  }

  function handleSeeArchetype() {
    setResult(computeResult(answers))
  }

  function retake() {
    setCurrentStep(0)
    setAnswers({})
    setResult(null)
  }

  const progressPct = allAnswered ? 100 : (currentStep / totalSteps) * 100

  const archetype = result ? archetypes[result] : null

  return (
    <PageShell>
      {/* Top section */}
      <section style={{ marginBottom: 80 }}>
        <div style={{ marginBottom: 24 }}>
          <Eyebrow chapter="05" label="Community" />
        </div>
        <h1 style={{
          fontFamily: 'var(--font-heading)',
          fontSize: 'clamp(36px, 5vw, 60px)',
          fontWeight: 500,
          letterSpacing: '-0.03em',
          lineHeight: 1.1,
          color: t.ink,
          marginBottom: 24,
        }}>
          Find your cohort.
        </h1>
        <p style={{
          fontFamily: 'var(--font-sans)',
          fontSize: 18,
          lineHeight: 1.75,
          color: t.inkMuted,
          maxWidth: 560,
        }}>
          ArtWall artists self-organise around four archetypes. Take the quiz to discover where you
          fit and what resources we have built for you.
        </p>
      </section>

      <Hairline />

      {/* Quiz */}
      <section style={{ marginTop: 64, maxWidth: 640 }}>
        {!result ? (
          <>
            {/* Progress bar */}
            <div style={{
              width: '100%',
              height: 4,
              background: t.hairline,
              borderRadius: 4,
              marginBottom: 48,
              overflow: 'hidden',
            }}>
              <div style={{
                width: `${progressPct}%`,
                height: '100%',
                background: t.signal,
                borderRadius: 4,
                transition: 'width 0.3s ease',
              }} />
            </div>

            {/* Step indicator */}
            <div style={{
              fontFamily: 'var(--font-sans)',
              fontSize: 12,
              color: t.inkMuted,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              marginBottom: 20,
            }}>
              Question {currentStep + 1} of {totalSteps}
            </div>

            {/* Question */}
            <h2 style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(22px, 2.5vw, 30px)',
              fontWeight: 500,
              letterSpacing: '-0.02em',
              lineHeight: 1.3,
              color: t.ink,
              marginBottom: 36,
            }}>
              {steps[currentStep].question}
            </h2>

            {/* Options */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {steps[currentStep].options.map((option, i) => {
                const isSelected = answers[currentStep] === i
                return (
                  <button
                    key={i}
                    onClick={() => selectOption(i)}
                    style={{
                      width: '100%',
                      textAlign: 'left',
                      padding: '16px 20px',
                      fontFamily: 'var(--font-sans)',
                      fontSize: 14,
                      lineHeight: 1.6,
                      color: isSelected ? t.signal : t.ink,
                      background: isSelected ? `${t.signal}0d` : t.wallPaper,
                      border: `1px solid ${isSelected ? t.signal : t.hairline}`,
                      borderRadius: 4,
                      cursor: 'pointer',
                      transition: 'border-color 0.15s, color 0.15s, background 0.15s',
                    }}
                  >
                    <span style={{
                      fontFamily: 'var(--font-sans)',
                      fontSize: 11,
                      fontWeight: 600,
                      letterSpacing: '0.08em',
                      color: isSelected ? t.signal : t.inkMuted,
                      marginRight: 12,
                    }}>
                      {['A', 'B', 'C', 'D'][i]}
                    </span>
                    {option}
                  </button>
                )
              })}
            </div>

            {/* Navigation */}
            <div style={{ display: 'flex', gap: 12, marginTop: 36, alignItems: 'center' }}>
              {currentStep > 0 && (
                <Btn variant="quiet" onClick={() => setCurrentStep(prev => prev - 1)}>
                  ← Back
                </Btn>
              )}
              {allAnswered && (
                <Btn variant="primary" onClick={handleSeeArchetype}>
                  See your archetype
                </Btn>
              )}
            </div>
          </>
        ) : (
          /* Result card */
          archetype && (
            <div style={{
              background: t.band,
              border: `1px solid ${t.hairline}`,
              borderRadius: 4,
              padding: 32,
            }}>
              <div style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 11,
                fontWeight: 600,
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                color: t.signal,
                marginBottom: 16,
              }}>
                Your Archetype
              </div>

              <h2 style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 28,
                fontWeight: 500,
                letterSpacing: '-0.02em',
                lineHeight: 1.2,
                color: t.ink,
                marginBottom: 20,
              }}>
                {archetype.name}
              </h2>

              <p style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 14,
                lineHeight: 1.75,
                color: t.inkMuted,
                marginBottom: 28,
              }}>
                {archetype.description}
              </p>

              <Hairline />

              <div style={{ marginTop: 24, marginBottom: 28 }}>
                <span style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 12,
                  fontWeight: 600,
                  letterSpacing: '0.06em',
                  textTransform: 'uppercase',
                  color: t.signal,
                  display: 'block',
                  marginBottom: 8,
                }}>
                  Recommended next step
                </span>
                <span style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 14,
                  lineHeight: 1.65,
                  color: t.ink,
                }}>
                  {archetype.next}
                </span>
              </div>

              <Btn variant="quiet" onClick={retake}>
                Retake quiz
              </Btn>
            </div>
          )
        )}
      </section>
    </PageShell>
  )
}
