import { useState, useRef, useEffect } from 'react'

// ─── Design tokens ──────────────────────────────────────────────────────────
const ink = '#0c0f1d'
const inkMuted = '#64748b'
const hairline = '#e2e8f0'
const signal = '#0e7490'
const band = '#f7f9fb'
const footer = '#1c2e38'
const wallPaper = '#ffffff'

// ─── Helpers ─────────────────────────────────────────────────────────────────
function Eyebrow({ chapter, label }: { chapter: string; label: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="eyebrow" style={{ color: signal }}>{chapter}</span>
      <span style={{ width: 24, height: 1, background: signal, display: 'inline-block' }} />
      <span className="eyebrow" style={{ color: signal }}>{label}</span>
    </div>
  )
}

function Hairline() {
  return <div style={{ width: '100%', height: 1, background: hairline }} />
}

// ─── Navigation ──────────────────────────────────────────────────────────────
function Nav() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 32)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        background: scrolled ? 'rgba(255,255,255,0.97)' : wallPaper,
        borderBottom: scrolled ? `1px solid ${hairline}` : '1px solid transparent',
        transition: 'border-color 0.2s, background 0.2s',
      }}
    >
      <div
        style={{
          maxWidth: 1240,
          margin: '0 auto',
          padding: '0 32px',
          height: 64,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        {/* Wordmark */}
        <a href="#" style={{ textDecoration: 'none', display: 'flex', flexDirection: 'column', gap: 1 }}>
          <span
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 18,
              fontWeight: 500,
              color: ink,
              letterSpacing: '-0.02em',
              lineHeight: 1,
            }}
          >
            ArtWall
          </span>
          <span
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: 10,
              fontWeight: 400,
              color: inkMuted,
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              lineHeight: 1,
            }}
          >
            Labs
          </span>
        </a>

        {/* Desktop nav */}
        <nav
          className="hidden"
          style={{ display: 'flex', gap: 32, alignItems: 'center' }}
        >
          {['Platform', 'Journey', 'Community', 'Artists', 'About'].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 14,
                fontWeight: 400,
                color: inkMuted,
                textDecoration: 'none',
                letterSpacing: '-0.01em',
                transition: 'color 0.15s',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.color = ink)}
              onMouseLeave={(e) => (e.currentTarget.style.color = inkMuted)}
            >
              {item}
            </a>
          ))}
          <a
            href="#join"
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: 13,
              fontWeight: 500,
              color: wallPaper,
              background: ink,
              textDecoration: 'none',
              padding: '9px 18px',
              borderRadius: 4,
              letterSpacing: '-0.01em',
              transition: 'background 0.15s',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.background = '#2b3245')}
            onMouseLeave={(e) => (e.currentTarget.style.background = ink)}
          >
            Join Founding Cohort
          </a>
        </nav>

        {/* Mobile menu button */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: 8,
            display: 'none',
          }}
        >
          <div style={{ width: 20, height: 1, background: ink, marginBottom: 5 }} />
          <div style={{ width: 14, height: 1, background: ink }} />
        </button>
      </div>

      {menuOpen && (
        <div
          style={{
            background: wallPaper,
            borderTop: `1px solid ${hairline}`,
            padding: '24px 32px',
            display: 'flex',
            flexDirection: 'column',
            gap: 20,
          }}
        >
          {['Platform', 'Journey', 'Community', 'Artists', 'About', 'Join'].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              onClick={() => setMenuOpen(false)}
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 16,
                color: ink,
                textDecoration: 'none',
              }}
            >
              {item}
            </a>
          ))}
        </div>
      )}
    </header>
  )
}

// ─── Chapter 00: Hero ────────────────────────────────────────────────────────
function Hero() {
  return (
    <section
      style={{
        paddingTop: 128,
        paddingBottom: 96,
        maxWidth: 1240,
        margin: '0 auto',
        padding: '128px 64px 96px',
      }}
    >
      <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 48, alignItems: 'end' }}>
        <div style={{ maxWidth: 720 }}>
          <div style={{ marginBottom: 32 }}>
            <Eyebrow chapter="ArtWall Labs" label="Jaipur · India" />
          </div>
          <h1
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(40px, 5vw, 72px)',
              fontWeight: 500,
              letterSpacing: '-0.03em',
              lineHeight: 1.05,
              color: ink,
              marginBottom: 32,
            }}
          >
            Infrastructure for
            <br />
            India's 42 million
            <br />
            <em style={{ fontStyle: 'italic', color: inkMuted }}>artists.</em>
          </h1>
          <p
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: 'clamp(17px, 1.8vw, 19px)',
              fontWeight: 400,
              lineHeight: 1.65,
              color: inkMuted,
              maxWidth: 560,
              marginBottom: 40,
            }}
          >
            A ₹30,000 crore market where up to 85% of a sale is absorbed before
            the maker is paid. ArtWall gives artists the catalogue, provenance,
            sales, and wall space they need to keep the rest.
          </p>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <a
              href="#join"
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 14,
                fontWeight: 500,
                color: wallPaper,
                background: ink,
                textDecoration: 'none',
                padding: '13px 24px',
                borderRadius: 4,
                letterSpacing: '-0.01em',
                display: 'inline-block',
                transition: 'background 0.15s',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = '#2b3245')}
              onMouseLeave={(e) => (e.currentTarget.style.background = ink)}
            >
              Join the founding cohort
            </a>
            <a
              href="#platform"
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 14,
                fontWeight: 400,
                color: ink,
                textDecoration: 'none',
                padding: '13px 24px',
                borderRadius: 4,
                border: `1px solid ${hairline}`,
                letterSpacing: '-0.01em',
                display: 'inline-block',
                transition: 'border-color 0.15s',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.borderColor = '#cbd5e1')}
              onMouseLeave={(e) => (e.currentTarget.style.borderColor = hairline)}
            >
              See the platform
            </a>
          </div>
        </div>

        {/* Chapter numeral */}
        <div style={{ textAlign: 'right', paddingBottom: 8 }}>
          <span
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(80px, 12vw, 144px)',
              fontWeight: 500,
              color: '#f1f5f9',
              letterSpacing: '-0.04em',
              lineHeight: 0.8,
              display: 'block',
              userSelect: 'none',
            }}
          >
            01
          </span>
        </div>
      </div>

      {/* Hero artwork strip */}
      <div style={{ marginTop: 72, display: 'grid', gridTemplateColumns: '2fr 1fr 1.5fr', gap: 2 }}>
        {[
          { id: 'photo-1578926288207-32f2d6fa7c7e', h: 400, artist: 'Priya Mehta', city: 'Jaipur' },
          { id: 'photo-1549490349-8643362247b5', h: 400, artist: 'Arjun Rao', city: 'Bangalore' },
          { id: 'photo-1541961017774-22349e4a1262', h: 400, artist: 'Kavya Singh', city: 'Mumbai' },
        ].map(({ id, h, artist, city }) => (
          <div key={id} style={{ position: 'relative', overflow: 'hidden', borderRadius: 4, background: band }}>
            <img
              src={`https://images.unsplash.com/${id}?w=600&h=${h}&fit=crop&auto=format`}
              alt={`Artwork by ${artist} from ${city}`}
              style={{ width: '100%', height: h, objectFit: 'cover', display: 'block' }}
            />
            <div
              style={{
                position: 'absolute',
                bottom: 0,
                left: 0,
                right: 0,
                padding: '12px 16px',
                background: 'rgba(12,15,29,0.72)',
                backdropFilter: 'blur(4px)',
              }}
            >
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: 'rgba(255,255,255,0.9)', letterSpacing: '-0.01em' }}>{artist}</div>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 2 }}>{city}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

// ─── Stats bar ───────────────────────────────────────────────────────────────
function StatsBar() {
  const stats = [
    { num: '42M', label: 'Artists in India' },
    { num: '₹30K Cr', label: 'Market size' },
    { num: '85%', label: 'Absorbed before maker is paid' },
    { num: '46', label: 'Art cities on the map' },
    { num: '3', label: 'Products, one codebase' },
  ]

  return (
    <div style={{ background: band, borderTop: `1px solid ${hairline}`, borderBottom: `1px solid ${hairline}` }}>
      <div
        style={{
          maxWidth: 1240,
          margin: '0 auto',
          padding: '0 64px',
          display: 'grid',
          gridTemplateColumns: 'repeat(5, 1fr)',
        }}
      >
        {stats.map((s, i) => (
          <div
            key={s.num}
            style={{
              padding: '28px 0',
              borderLeft: i > 0 ? `1px solid ${hairline}` : 'none',
              paddingLeft: i > 0 ? 32 : 0,
              paddingRight: 32,
            }}
          >
            <div
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 'clamp(24px, 2.5vw, 36px)',
                fontWeight: 500,
                letterSpacing: '-0.025em',
                lineHeight: 1.1,
                color: ink,
              }}
            >
              {s.num}
            </div>
            <div
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 13,
                color: inkMuted,
                lineHeight: 1.4,
                marginTop: 6,
              }}
            >
              {s.label}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Chapter 01: Six Systems ─────────────────────────────────────────────────
const systems = [
  {
    num: '01',
    title: 'Catalogue',
    desc: 'A permanent, provenance-backed record of every work. Medium, dimensions, year, series, edition — all in one place, never lost when a gallery relationship ends.',
    icon: '◻',
  },
  {
    num: '02',
    title: 'Physical Wall',
    desc: 'A curated wall inside Ric Platter restaurant, Jaipur. Artists book slots, QR codes track visitor attention, and the restaurant revenue the art drives comes back with data.',
    icon: '⊞',
  },
  {
    num: '03',
    title: 'Provenance',
    desc: 'Cryptographically signed certificates of authenticity. Every sale, every transfer, every exhibition — a chain of custody that belongs to the artist, not to the auction house.',
    icon: '⌗',
  },
  {
    num: '04',
    title: 'Sales',
    desc: 'Invoices, price tracking, and a clean record of what sold, to whom, and for how much — with GST handled correctly and royalties calculated automatically.',
    icon: '₹',
  },
  {
    num: '05',
    title: 'Studio',
    desc: 'A private workspace for every artist. Collections, series, exhibitions, contacts, documents — everything an artist needs to run their practice without a middleman.',
    icon: '⬜',
  },
  {
    num: '06',
    title: 'Community',
    desc: "A directory of artists by city, medium, and practice. A living map of where Indian art is made. Founding members, archetypes, and the argument that India's artists deserve better.",
    icon: '◉',
  },
]

function SixSystems() {
  const [active, setActive] = useState<string | null>(null)

  return (
    <section id="platform" style={{ maxWidth: 1240, margin: '0 auto', padding: '96px 64px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 32, alignItems: 'end', marginBottom: 64 }}>
        <div>
          <div style={{ marginBottom: 20 }}>
            <Eyebrow chapter="02" label="Services" />
          </div>
          <h2
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(28px, 3.5vw, 44px)',
              fontWeight: 500,
              letterSpacing: '-0.025em',
              lineHeight: 1.2,
              color: ink,
              maxWidth: 540,
            }}
          >
            Six systems that make an artist's practice whole.
          </h2>
        </div>
        <span
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 'clamp(60px, 8vw, 96px)',
            fontWeight: 500,
            color: '#f1f5f9',
            letterSpacing: '-0.04em',
            lineHeight: 0.8,
            userSelect: 'none',
          }}
        >
          02
        </span>
      </div>

      <Hairline />

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)' }}>
        {systems.map((s, i) => (
          <div
            key={s.num}
            style={{
              borderLeft: i % 3 !== 0 ? `1px solid ${hairline}` : 'none',
              borderBottom: i < 3 ? `1px solid ${hairline}` : 'none',
              padding: '40px 36px',
              cursor: 'default',
              background: active === s.num ? band : wallPaper,
              transition: 'background 0.15s',
            }}
            onMouseEnter={() => setActive(s.num)}
            onMouseLeave={() => setActive(null)}
          >
            <div
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 22,
                color: active === s.num ? ink : '#cbd5e1',
                marginBottom: 20,
                transition: 'color 0.15s',
                lineHeight: 1,
              }}
            >
              {s.icon}
            </div>
            <div
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 11,
                fontWeight: 500,
                letterSpacing: '0.12em',
                textTransform: 'uppercase',
                color: inkMuted,
                marginBottom: 12,
              }}
            >
              {s.num}
            </div>
            <h3
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 22,
                fontWeight: 500,
                letterSpacing: '-0.015em',
                lineHeight: 1.3,
                color: ink,
                marginBottom: 16,
              }}
            >
              {s.title}
            </h3>
            <p
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 14,
                lineHeight: 1.7,
                color: inkMuted,
              }}
            >
              {s.desc}
            </p>
          </div>
        ))}
      </div>
    </section>
  )
}

// ─── Chapter 02: The 24 Failures ─────────────────────────────────────────────
const failures = [
  'No permanent catalogue',
  'Provenance lost at sale',
  'Gallery takes 40–50%',
  'No GST compliance',
  'Royalties never paid',
  'No resale rights',
  'Price history invisible',
  'No contract standard',
  'Storage costs ignored',
  'Insurance gaps',
  'No invoice template',
  'Digital work unsellable',
  'No edition control',
  'Collectors vanish',
  'No grievance path',
  'Exhibition records lost',
  'No data portability',
  'Platform lock-in',
  'No artist ID standard',
  'Discovery is gatekept',
  'No audience data',
  "Coupons don't convert",
  'Revenue unattributed',
  'Artist has no leverage',
]

function WhySection() {
  return (
    <section style={{ background: band, borderTop: `1px solid ${hairline}`, borderBottom: `1px solid ${hairline}` }}>
      <div style={{ maxWidth: 1240, margin: '0 auto', padding: '96px 64px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 32, alignItems: 'end', marginBottom: 64 }}>
          <div>
            <div style={{ marginBottom: 20 }}>
              <Eyebrow chapter="03" label="The problem" />
            </div>
            <h2
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 'clamp(28px, 3.5vw, 44px)',
                fontWeight: 500,
                letterSpacing: '-0.025em',
                lineHeight: 1.2,
                color: ink,
                maxWidth: 560,
              }}
            >
              Twenty-four ways the system fails an artist before breakfast.
            </h2>
          </div>
          <span
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(60px, 8vw, 96px)',
              fontWeight: 500,
              color: '#e2e8f0',
              letterSpacing: '-0.04em',
              lineHeight: 0.8,
              userSelect: 'none',
            }}
          >
            03
          </span>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, 1fr)',
            gap: 0,
            background: wallPaper,
            border: `1px solid ${hairline}`,
            borderRadius: 4,
            overflow: 'hidden',
          }}
        >
          {failures.map((f, i) => (
            <div
              key={f}
              style={{
                padding: '20px 24px',
                borderRight: (i + 1) % 4 !== 0 ? `1px solid ${hairline}` : 'none',
                borderBottom: i < failures.length - 4 ? `1px solid ${hairline}` : 'none',
                display: 'flex',
                alignItems: 'flex-start',
                gap: 12,
              }}
            >
              <span
                style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 11,
                  fontWeight: 500,
                  color: signal,
                  letterSpacing: '0.08em',
                  minWidth: 24,
                  marginTop: 2,
                  lineHeight: 1,
                }}
              >
                {String(i + 1).padStart(2, '0')}
              </span>
              <span
                style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 13,
                  color: ink,
                  lineHeight: 1.5,
                }}
              >
                {f}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Chapter 03: Three Audiences ─────────────────────────────────────────────
const audiences = [
  {
    role: 'For artists',
    headline: 'Your practice, finally whole.',
    desc: 'Catalogue your work, issue provenance certificates, manage sales and invoices, and put your work on a physical wall — all without a gallery taking half.',
    cta: 'See the Studio',
    img: 'photo-1574169208507-84376144848b',
  },
  {
    role: 'For visitors',
    headline: 'Scan. Discover. Own.',
    desc: 'Every artwork on the wall has a QR code. Scan it to learn about the work, the artist, and where it comes from. Buy directly. No middleman, no mystery.',
    cta: 'Visit the Wall',
    img: 'photo-1558618666-fcd25c85cd64',
  },
  {
    role: 'For the restaurant',
    headline: 'Art that pays its rent.',
    desc: 'Ric Platter hosts the wall. Every visitor who comes for the art and stays for a meal is tracked — by the coupon QR at the counter, not by guesswork.',
    cta: 'See how it works',
    img: 'photo-1414235077428-338989a2e8c0',
  },
]

function ForSection() {
  return (
    <section style={{ maxWidth: 1240, margin: '0 auto', padding: '96px 64px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 32, alignItems: 'end', marginBottom: 64 }}>
        <div>
          <div style={{ marginBottom: 20 }}>
            <Eyebrow chapter="04" label="Audiences" />
          </div>
          <h2
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(28px, 3.5vw, 44px)',
              fontWeight: 500,
              letterSpacing: '-0.025em',
              lineHeight: 1.2,
              color: ink,
            }}
          >
            One wall. Three people it serves.
          </h2>
        </div>
        <span
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 'clamp(60px, 8vw, 96px)',
            fontWeight: 500,
            color: '#f1f5f9',
            letterSpacing: '-0.04em',
            lineHeight: 0.8,
            userSelect: 'none',
          }}
        >
          04
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 2 }}>
        {audiences.map((a) => (
          <div
            key={a.role}
            style={{
              display: 'flex',
              flexDirection: 'column',
              border: `1px solid ${hairline}`,
              borderRadius: 4,
              overflow: 'hidden',
            }}
          >
            <div style={{ position: 'relative', background: band }}>
              <img
                src={`https://images.unsplash.com/${a.img}?w=500&h=300&fit=crop&auto=format`}
                alt={a.role}
                style={{ width: '100%', height: 220, objectFit: 'cover', display: 'block' }}
              />
            </div>
            <div style={{ padding: '28px 28px 32px', flex: 1, display: 'flex', flexDirection: 'column' }}>
              <div className="eyebrow" style={{ marginBottom: 16 }}>{a.role}</div>
              <h3
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 22,
                  fontWeight: 500,
                  letterSpacing: '-0.015em',
                  lineHeight: 1.35,
                  color: ink,
                  marginBottom: 12,
                }}
              >
                {a.headline}
              </h3>
              <p
                style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 14,
                  lineHeight: 1.7,
                  color: inkMuted,
                  flex: 1,
                  marginBottom: 24,
                }}
              >
                {a.desc}
              </p>
              <a
                href="#"
                style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 13,
                  fontWeight: 500,
                  color: ink,
                  textDecoration: 'none',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 6,
                  borderBottom: `1px solid ${ink}`,
                  paddingBottom: 2,
                  width: 'fit-content',
                }}
              >
                {a.cta} →
              </a>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

// ─── Chapter 04: Living Map ───────────────────────────────────────────────────
const artCities = [
  { name: 'Mumbai', x: 22, y: 55, artists: 4820, works: 312, founding: 89 },
  { name: 'Delhi', x: 38, y: 24, artists: 6140, works: 401, founding: 124 },
  { name: 'Bangalore', x: 33, y: 70, artists: 3910, works: 218, founding: 67 },
  { name: 'Kolkata', x: 64, y: 38, artists: 2890, works: 176, founding: 45 },
  { name: 'Chennai', x: 38, y: 76, artists: 2140, works: 134, founding: 38 },
  { name: 'Jaipur', x: 33, y: 30, artists: 1820, works: 96, founding: 31 },
  { name: 'Ahmedabad', x: 22, y: 42, artists: 1540, works: 88, founding: 27 },
  { name: 'Hyderabad', x: 38, y: 62, artists: 1980, works: 118, founding: 42 },
  { name: 'Pune', x: 26, y: 58, artists: 1420, works: 82, founding: 24 },
  { name: 'Varanasi', x: 50, y: 34, artists: 890, works: 54, founding: 18 },
  { name: 'Udaipur', x: 28, y: 36, artists: 640, works: 42, founding: 14 },
  { name: 'Mysore', x: 31, y: 72, artists: 580, works: 34, founding: 11 },
  { name: 'Kochi', x: 28, y: 80, artists: 760, works: 46, founding: 16 },
  { name: 'Chandigarh', x: 36, y: 18, artists: 520, works: 32, founding: 9 },
  { name: 'Bhopal', x: 40, y: 44, artists: 480, works: 28, founding: 8 },
]

function LivingMap() {
  const [selected, setSelected] = useState<typeof artCities[0] | null>(artCities[0])
  const [region, setRegion] = useState<string>('All')
  const regions = ['All', 'North', 'South', 'West', 'East']

  const totalArtists = artCities.reduce((a, c) => a + c.artists, 0)
  const totalWorks = artCities.reduce((a, c) => a + c.works, 0)
  const totalFounding = artCities.reduce((a, c) => a + c.founding, 0)

  return (
    <section style={{ background: band, borderTop: `1px solid ${hairline}`, borderBottom: `1px solid ${hairline}` }}>
      <div style={{ maxWidth: 1240, margin: '0 auto', padding: '96px 64px' }}>
        {/* Header */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 32, alignItems: 'end', marginBottom: 48 }}>
          <div>
            <div style={{ marginBottom: 20 }}>
              <Eyebrow chapter="05" label="Living Map" />
            </div>
            <h2
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 'clamp(28px, 3.5vw, 44px)',
                fontWeight: 500,
                letterSpacing: '-0.025em',
                lineHeight: 1.2,
                color: ink,
              }}
            >
              India's art, mapped by those who make it.
            </h2>
          </div>
          <span
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(60px, 8vw, 96px)',
              fontWeight: 500,
              color: '#e2e8f0',
              letterSpacing: '-0.04em',
              lineHeight: 0.8,
              userSelect: 'none',
            }}
          >
            05
          </span>
        </div>

        {/* Stats row */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            background: wallPaper,
            border: `1px solid ${hairline}`,
            borderRadius: 4,
            overflow: 'hidden',
            marginBottom: 32,
          }}
        >
          {[
            { n: artCities.length, l: 'Cities lit' },
            { n: totalArtists.toLocaleString('en-IN'), l: 'Artists joined' },
            { n: totalFounding, l: 'Founding members' },
          ].map((s, i) => (
            <div
              key={s.l}
              style={{
                padding: '20px 28px',
                borderLeft: i > 0 ? `1px solid ${hairline}` : 'none',
              }}
            >
              <div
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 28,
                  fontWeight: 500,
                  letterSpacing: '-0.025em',
                  color: ink,
                  lineHeight: 1,
                }}
              >
                {s.n}
              </div>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: inkMuted, marginTop: 6 }}>
                {s.l}
              </div>
            </div>
          ))}
        </div>

        {/* Region chips + search */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            marginBottom: 32,
            flexWrap: 'wrap',
          }}
        >
          {regions.map((r) => (
            <button
              key={r}
              onClick={() => setRegion(r)}
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 12,
                fontWeight: region === r ? 500 : 400,
                color: region === r ? wallPaper : ink,
                background: region === r ? ink : wallPaper,
                border: `1px solid ${region === r ? ink : hairline}`,
                borderRadius: 4,
                padding: '6px 14px',
                cursor: 'pointer',
                transition: 'all 0.15s',
              }}
            >
              {r}
            </button>
          ))}
          <div
            style={{
              marginLeft: 'auto',
              border: `1px solid ${hairline}`,
              borderRadius: 4,
              overflow: 'hidden',
              display: 'flex',
              alignItems: 'center',
              background: wallPaper,
            }}
          >
            <span style={{ padding: '0 12px', color: inkMuted, fontSize: 13 }}>⌕</span>
            <input
              type="text"
              placeholder="Search cities…"
              style={{
                border: 'none',
                outline: 'none',
                fontFamily: 'var(--font-sans)',
                fontSize: 13,
                color: ink,
                padding: '8px 12px 8px 0',
                width: 180,
                background: 'transparent',
              }}
            />
          </div>
        </div>

        {/* Map + detail panel */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 320px',
            gap: 2,
            background: wallPaper,
            border: `1px solid ${hairline}`,
            borderRadius: 4,
            overflow: 'hidden',
            minHeight: 480,
          }}
        >
          {/* Map */}
          <div style={{ position: 'relative', padding: 32 }}>
            <svg
              viewBox="0 0 100 100"
              style={{ width: '100%', height: '100%', minHeight: 420 }}
              aria-label="Map of India showing artist locations"
            >
              {/* Simplified India outline — a loose polygon approximation */}
              <path
                d="M36,8 L42,8 L48,10 L54,9 L60,12 L66,14 L70,18 L72,24 L74,30 L72,36
                   L68,40 L64,42 L66,48 L70,54 L68,60 L64,66 L60,72 L56,78 L50,84
                   L46,88 L42,84 L38,80 L34,74 L30,68 L26,62 L22,56 L20,50 L20,44
                   L22,38 L24,32 L26,26 L28,20 L32,14 Z"
                fill="none"
                stroke={hairline}
                strokeWidth="0.5"
              />

              {/* City dots */}
              {artCities.map((city) => {
                const r = Math.sqrt(city.artists / 6140) * 2.8
                const isSelected = selected?.name === city.name
                return (
                  <g
                    key={city.name}
                    style={{ cursor: 'pointer' }}
                    onClick={() => setSelected(city)}
                  >
                    {isSelected && (
                      <circle
                        cx={city.x}
                        cy={city.y}
                        r={r + 2.5}
                        fill="none"
                        stroke={signal}
                        strokeWidth="0.4"
                        opacity="0.5"
                      />
                    )}
                    <circle
                      cx={city.x}
                      cy={city.y}
                      r={r}
                      fill={isSelected ? signal : ink}
                      opacity={isSelected ? 1 : 0.55}
                    />
                    {r > 1.8 && (
                      <text
                        x={city.x + r + 1.2}
                        y={city.y + 0.5}
                        fontSize="2.2"
                        fill={inkMuted}
                        fontFamily="Inter, sans-serif"
                        dominantBaseline="middle"
                      >
                        {city.name}
                      </text>
                    )}
                  </g>
                )
              })}
            </svg>

            {/* Legend */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: ink, opacity: 0.55 }} />
                <span style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: inkMuted }}>City</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ width: 10, height: 10, borderRadius: '50%', background: ink, opacity: 0.55 }} />
                <span style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: inkMuted }}>More artists</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: signal }} />
                <span style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: inkMuted }}>Selected</span>
              </div>
            </div>
          </div>

          {/* Detail panel */}
          <div
            style={{
              borderLeft: `1px solid ${hairline}`,
              padding: '32px 28px',
              display: 'flex',
              flexDirection: 'column',
              background: band,
            }}
          >
            {selected ? (
              <>
                <div className="eyebrow" style={{ marginBottom: 16 }}>
                  {selected.name}
                </div>
                <div style={{ marginBottom: 24 }}>
                  <div
                    style={{
                      fontFamily: 'var(--font-heading)',
                      fontSize: 36,
                      fontWeight: 500,
                      letterSpacing: '-0.03em',
                      color: ink,
                      lineHeight: 1,
                    }}
                  >
                    {selected.artists.toLocaleString('en-IN')}
                  </div>
                  <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: inkMuted, marginTop: 4 }}>
                    artists from {selected.name}
                  </div>
                </div>

                <Hairline />

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 20, marginBottom: 24 }}>
                  {[
                    { n: selected.works, l: 'Works on wall' },
                    { n: selected.founding, l: 'Founding members' },
                  ].map((s) => (
                    <div key={s.l}>
                      <div
                        style={{
                          fontFamily: 'var(--font-heading)',
                          fontSize: 22,
                          fontWeight: 500,
                          letterSpacing: '-0.02em',
                          color: ink,
                          lineHeight: 1,
                        }}
                      >
                        {s.n}
                      </div>
                      <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: inkMuted, marginTop: 4 }}>
                        {s.l}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Practice breakdown */}
                <div style={{ marginBottom: 24 }}>
                  <div
                    style={{
                      fontFamily: 'var(--font-sans)',
                      fontSize: 11,
                      fontWeight: 500,
                      letterSpacing: '0.1em',
                      textTransform: 'uppercase',
                      color: inkMuted,
                      marginBottom: 12,
                    }}
                  >
                    Practices
                  </div>
                  {[
                    { label: 'Painting', pct: 42 },
                    { label: 'Sculpture', pct: 18 },
                    { label: 'Photography', pct: 22 },
                    { label: 'Mixed media', pct: 18 },
                  ].map((p) => (
                    <div key={p.label} style={{ marginBottom: 8 }}>
                      <div
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          fontFamily: 'var(--font-sans)',
                          fontSize: 12,
                          color: inkMuted,
                          marginBottom: 4,
                        }}
                      >
                        <span>{p.label}</span>
                        <span>{p.pct}%</span>
                      </div>
                      <div style={{ height: 2, background: hairline, borderRadius: 1 }}>
                        <div
                          style={{
                            height: '100%',
                            width: `${p.pct}%`,
                            background: ink,
                            borderRadius: 1,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <a
                  href="#"
                  style={{
                    fontFamily: 'var(--font-sans)',
                    fontSize: 13,
                    fontWeight: 500,
                    color: ink,
                    textDecoration: 'none',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 6,
                    borderBottom: `1px solid ${ink}`,
                    paddingBottom: 2,
                    width: 'fit-content',
                    marginTop: 'auto',
                  }}
                >
                  Browse {selected.name} artists →
                </a>
              </>
            ) : (
              <div
                style={{
                  flex: 1,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  textAlign: 'center',
                  gap: 12,
                }}
              >
                <div style={{ fontFamily: 'var(--font-heading)', fontSize: 32, color: hairline }}>◉</div>
                <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: inkMuted, lineHeight: 1.6 }}>
                  Select a city on the map to see its artists and works.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Chapter 05: Testimonials ─────────────────────────────────────────────────
const testimonials = [
  {
    quote: "For the first time, I know exactly where every piece I've ever sold has gone. That's not a luxury — it's a right I didn't know I could have.",
    name: 'Priya Mehta',
    city: 'Jaipur',
    medium: 'Watercolour',
    img: 'photo-1494790108377-be9c29b29330',
  },
  {
    quote: "The wall at Ric Platter generated more genuine interest in my work in three weeks than an Instagram account I've run for four years.",
    name: 'Arjun Rao',
    city: 'Bangalore',
    medium: 'Oil on canvas',
    img: 'photo-1506794778202-cad84cf45f1d',
  },
  {
    quote: 'I used to think certificates of authenticity were for dead artists. Now every piece I sell comes with one, and buyers notice.',
    name: 'Kavya Singh',
    city: 'Mumbai',
    medium: 'Mixed media',
    img: 'photo-1438761681033-6461ffad8d80',
  },
]

function Testimonials() {
  return (
    <section style={{ maxWidth: 1240, margin: '0 auto', padding: '96px 64px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 32, alignItems: 'end', marginBottom: 64 }}>
        <div>
          <div style={{ marginBottom: 20 }}>
            <Eyebrow chapter="06" label="From the artists" />
          </div>
          <h2
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(28px, 3.5vw, 44px)',
              fontWeight: 500,
              letterSpacing: '-0.025em',
              lineHeight: 1.2,
              color: ink,
            }}
          >
            What changes when the infrastructure works.
          </h2>
        </div>
        <span
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 'clamp(60px, 8vw, 96px)',
            fontWeight: 500,
            color: '#f1f5f9',
            letterSpacing: '-0.04em',
            lineHeight: 0.8,
            userSelect: 'none',
          }}
        >
          06
        </span>
      </div>

      <Hairline />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)' }}>
        {testimonials.map((t, i) => (
          <div
            key={t.name}
            style={{
              borderLeft: i > 0 ? `1px solid ${hairline}` : 'none',
              padding: '40px 36px',
              display: 'flex',
              flexDirection: 'column',
              gap: 24,
            }}
          >
            <blockquote
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 18,
                fontWeight: 400,
                fontStyle: 'italic',
                letterSpacing: '-0.01em',
                lineHeight: 1.55,
                color: ink,
                flex: 1,
                margin: 0,
              }}
            >
              "{t.quote}"
            </blockquote>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <img
                src={`https://images.unsplash.com/${t.img}?w=80&h=80&fit=crop&auto=format`}
                alt={t.name}
                style={{ width: 36, height: 36, borderRadius: '50%', objectFit: 'cover', flexShrink: 0 }}
              />
              <div>
                <div
                  style={{
                    fontFamily: 'var(--font-sans)',
                    fontSize: 13,
                    fontWeight: 500,
                    color: ink,
                    lineHeight: 1.3,
                  }}
                >
                  {t.name}
                </div>
                <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: inkMuted }}>
                  {t.medium} · {t.city}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

// ─── Chapter 06: Join ─────────────────────────────────────────────────────────
function JoinSection() {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const [medium, setMedium] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) setSubmitted(true)
  }

  return (
    <section
      id="join"
      style={{
        background: '#f7f9fb',
        borderTop: `1px solid ${hairline}`,
      }}
    >
      <div
        style={{
          maxWidth: 1240,
          margin: '0 auto',
          padding: '96px 64px',
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 80,
          alignItems: 'start',
        }}
      >
        {/* Left */}
        <div>
          <div style={{ marginBottom: 20 }}>
            <Eyebrow chapter="07" label="Founding cohort" />
          </div>
          <h2
            style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(28px, 3.5vw, 44px)',
              fontWeight: 500,
              letterSpacing: '-0.025em',
              lineHeight: 1.2,
              color: ink,
              marginBottom: 24,
            }}
          >
            Be part of what India's art ecosystem becomes.
          </h2>
          <p
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: 16,
              lineHeight: 1.75,
              color: inkMuted,
              marginBottom: 40,
              maxWidth: 440,
            }}
          >
            The founding cohort is a numbered, permanent set. Your artist
            number is part of your provenance record. It stays on every
            certificate you ever issue. There is no waitlist for a later
            round — this is the round.
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {[
              'Permanent founding member number on all certificates',
              'Full Studio access, free for the first year',
              'Priority access to Physical Wall booking slots',
              'Your works in the inaugural community exhibition',
              'Direct input into product direction',
            ].map((benefit) => (
              <div key={benefit} style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                <div
                  style={{
                    width: 16,
                    height: 16,
                    borderRadius: '50%',
                    border: `1.5px solid ${signal}`,
                    flexShrink: 0,
                    marginTop: 2,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <div style={{ width: 6, height: 6, borderRadius: '50%', background: signal }} />
                </div>
                <span style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: ink, lineHeight: 1.6 }}>
                  {benefit}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right — form */}
        <div
          style={{
            background: wallPaper,
            border: `1px solid ${hairline}`,
            borderRadius: 4,
            padding: '40px 36px',
          }}
        >
          {submitted ? (
            <div style={{ textAlign: 'center', padding: '32px 0' }}>
              <div
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: '50%',
                  border: `1.5px solid ${signal}`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 20px',
                  color: signal,
                  fontSize: 20,
                }}
              >
                ✓
              </div>
              <h3
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 24,
                  fontWeight: 500,
                  letterSpacing: '-0.015em',
                  color: ink,
                  marginBottom: 12,
                }}
              >
                You're on the list.
              </h3>
              <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: inkMuted, lineHeight: 1.65 }}>
                We'll send your founding number and next steps to <strong>{email}</strong> within 48 hours.
              </p>
            </div>
          ) : (
            <>
              <h3
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 22,
                  fontWeight: 500,
                  letterSpacing: '-0.015em',
                  color: ink,
                  marginBottom: 6,
                }}
              >
                Join the founding cohort
              </h3>
              <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: inkMuted, marginBottom: 28, lineHeight: 1.6 }}>
                Open to artists based in India. No fee to register.
              </p>

              <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {[
                  { label: 'Full name', type: 'text', placeholder: 'Priya Mehta' },
                  { label: 'Email address', type: 'email', placeholder: 'priya@example.com' },
                  { label: 'City', type: 'text', placeholder: 'Jaipur' },
                ].map((field) => (
                  <div key={field.label}>
                    <label
                      style={{
                        fontFamily: 'var(--font-sans)',
                        fontSize: 12,
                        fontWeight: 500,
                        color: ink,
                        display: 'block',
                        marginBottom: 6,
                        letterSpacing: '-0.01em',
                      }}
                    >
                      {field.label}
                    </label>
                    <input
                      type={field.type}
                      placeholder={field.placeholder}
                      value={field.type === 'email' ? email : undefined}
                      onChange={field.type === 'email' ? (e) => setEmail(e.target.value) : undefined}
                      required={field.type === 'email'}
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        fontFamily: 'var(--font-sans)',
                        fontSize: 14,
                        color: ink,
                        background: band,
                        border: `1px solid #cbd5e1`,
                        borderRadius: 4,
                        outline: 'none',
                        transition: 'border-color 0.15s',
                      }}
                      onFocus={(e) => (e.currentTarget.style.borderColor = ink)}
                      onBlur={(e) => (e.currentTarget.style.borderColor = '#cbd5e1')}
                    />
                  </div>
                ))}

                <div>
                  <label
                    style={{
                      fontFamily: 'var(--font-sans)',
                      fontSize: 12,
                      fontWeight: 500,
                      color: ink,
                      display: 'block',
                      marginBottom: 6,
                    }}
                  >
                    Primary medium
                  </label>
                  <select
                    value={medium}
                    onChange={(e) => setMedium(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      fontFamily: 'var(--font-sans)',
                      fontSize: 14,
                      color: medium ? ink : inkMuted,
                      background: band,
                      border: `1px solid #cbd5e1`,
                      borderRadius: 4,
                      outline: 'none',
                      appearance: 'none',
                      cursor: 'pointer',
                    }}
                  >
                    <option value="" disabled>Select a medium</option>
                    {['Painting', 'Sculpture', 'Photography', 'Mixed media', 'Printmaking', 'Drawing', 'Digital', 'Textile', 'Other'].map((m) => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>

                {/* Consent */}
                <div
                  style={{
                    borderTop: `1px solid ${hairline}`,
                    paddingTop: 16,
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 12,
                  }}
                >
                  <label
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: 10,
                      cursor: 'pointer',
                    }}
                  >
                    <input
                      type="checkbox"
                      required
                      style={{ marginTop: 2, accentColor: ink, width: 14, height: 14, flexShrink: 0 }}
                    />
                    <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: inkMuted, lineHeight: 1.55 }}>
                      I consent to ArtWall Labs storing my registration information to process my application. I can withdraw this at any time.{' '}
                      <a href="#" style={{ color: ink, textDecoration: 'underline' }}>Privacy notice</a>
                    </span>
                  </label>
                  <label
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: 10,
                      cursor: 'pointer',
                    }}
                  >
                    <input
                      type="checkbox"
                      style={{ marginTop: 2, accentColor: ink, width: 14, height: 14, flexShrink: 0 }}
                    />
                    <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: inkMuted, lineHeight: 1.55 }}>
                      I'd like to receive updates about the platform and community events. (Optional — not required to join.)
                    </span>
                  </label>
                </div>

                <button
                  type="submit"
                  style={{
                    fontFamily: 'var(--font-sans)',
                    fontSize: 14,
                    fontWeight: 500,
                    color: wallPaper,
                    background: ink,
                    border: 'none',
                    borderRadius: 4,
                    padding: '13px 24px',
                    cursor: 'pointer',
                    letterSpacing: '-0.01em',
                    transition: 'background 0.15s',
                    marginTop: 4,
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = '#2b3245')}
                  onMouseLeave={(e) => (e.currentTarget.style.background = ink)}
                >
                  Request founding membership
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </section>
  )
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer style={{ background: footer }}>
      <div style={{ maxWidth: 1240, margin: '0 auto', padding: '64px 64px 40px' }}>
        {/* Top row */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr 1fr 1fr',
            gap: 48,
            paddingBottom: 48,
            borderBottom: '1px solid rgba(255,255,255,0.1)',
          }}
        >
          {/* Brand */}
          <div style={{ gridColumn: 'span 1' }}>
            <div
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 20,
                fontWeight: 500,
                color: 'rgba(255,255,255,0.9)',
                letterSpacing: '-0.02em',
                marginBottom: 4,
              }}
            >
              ArtWall
            </div>
            <div
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 10,
                color: 'rgba(255,255,255,0.45)',
                letterSpacing: '0.12em',
                textTransform: 'uppercase',
                marginBottom: 20,
              }}
            >
              Labs
            </div>
            <p
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 13,
                color: 'rgba(255,255,255,0.55)',
                lineHeight: 1.65,
                maxWidth: 220,
              }}
            >
              Infrastructure for India's artists. Based in Jaipur.
            </p>
          </div>

          {/* Nav columns */}
          {[
            {
              heading: 'Platform',
              links: ['Catalogue', 'Provenance', 'Sales', 'Studio', 'Physical Wall'],
            },
            {
              heading: 'Company',
              links: ['About', 'Journey', 'Community', 'Artists', 'Contact'],
            },
            {
              heading: 'Legal',
              links: ['Privacy notice', 'Terms', 'Data rights', 'Grievance', 'DPDP compliance'],
            },
          ].map((col) => (
            <div key={col.heading}>
              <div
                style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 11,
                  fontWeight: 500,
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  color: 'rgba(255,255,255,0.4)',
                  marginBottom: 16,
                }}
              >
                {col.heading}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {col.links.map((link) => (
                  <a
                    key={link}
                    href="#"
                    style={{
                      fontFamily: 'var(--font-sans)',
                      fontSize: 13,
                      color: 'rgba(255,255,255,0.65)',
                      textDecoration: 'none',
                      transition: 'color 0.15s',
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.color = 'rgba(255,255,255,0.9)')}
                    onMouseLeave={(e) => (e.currentTarget.style.color = 'rgba(255,255,255,0.65)')}
                  >
                    {link}
                  </a>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Bottom row */}
        <div
          style={{
            paddingTop: 28,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 16,
          }}
        >
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: 'rgba(255,255,255,0.35)' }}>
            © 2025 ArtWall Labs. Registered in India.
          </p>
          <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: signal }} />
            <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: 'rgba(255,255,255,0.35)' }}>
              Wall live · Jaipur
            </span>
          </div>
        </div>
      </div>
    </footer>
  )
}

// ─── Home page (Nav + Footer come from Root layout) ──────────────────────────
export default function Home() {
  return (
    <div style={{ background: wallPaper, minHeight: '100vh' }}>
      <Hero />
      <StatsBar />
      <SixSystems />
      <WhySection />
      <ForSection />
      <LivingMap />
      <Testimonials />
      <JoinSection />
    </div>
  )
}
