import { useState } from 'react'
import { Link } from 'react-router'
import { t } from '../components/tokens'
import { Eyebrow, Hairline, Badge, PageShell } from '../components/ui'

const ARTISTS = [
  { name: "Priya Mehta", handle: "priya-mehta", city: "Jaipur", medium: "Painting", artworks: 23, founding: true, photo: "1486413869840-a99ac0a4c031" },
  { name: "Arjun Nair", handle: "arjun-nair", city: "Kochi", medium: "Photography", artworks: 41, founding: true, photo: "1614244139209-53c071a4737d" },
  { name: "Sunita Rao", handle: "sunita-rao", city: "Bengaluru", medium: "Sculpture", artworks: 9, founding: false, photo: "1613353948391-9822c7407534" },
  { name: "Dev Kapoor", handle: "dev-kapoor", city: "Delhi", medium: "Painting", artworks: 17, founding: true, photo: "1627890458144-4c0c481bf4b8" },
  { name: "Meera Krishnan", handle: "meera-krishnan", city: "Chennai", medium: "Mixed Media", artworks: 12, founding: false, photo: "1615065137920-bef75ea862b7" },
  { name: "Ravi Sharma", handle: "ravi-sharma", city: "Jaipur", medium: "Painting", artworks: 31, founding: true, photo: "1741805190547-6da79a18b41a" },
  { name: "Lakshmi Patel", handle: "lakshmi-patel", city: "Ahmedabad", medium: "Photography", artworks: 27, founding: false, photo: "1773944449123-0089f239a4b3" },
  { name: "Vikram Das", handle: "vikram-das", city: "Kolkata", medium: "Painting", artworks: 19, founding: true, photo: "1775567978439-7d94381a9847" },
  { name: "Ananya Singh", handle: "ananya-singh", city: "Mumbai", medium: "Sculpture", artworks: 7, founding: false, photo: "1750319157047-8d6523f9c53a" },
  { name: "Kabir Malhotra", handle: "kabir-malhotra", city: "Pune", medium: "Mixed Media", artworks: 14, founding: false, photo: "1758267928035-6716c00ff3c1" },
  { name: "Divya Iyer", handle: "divya-iyer", city: "Hyderabad", medium: "Painting", artworks: 8, founding: false, photo: "1774689305776-a4d005b42a2a" },
  { name: "Sanjay Gupta", handle: "sanjay-gupta", city: "Jaipur", medium: "Photography", artworks: 22, founding: true, photo: "1676742663664-2da16ddcad7a" },
]

const FILTERS = ["All", "Painting", "Sculpture", "Photography", "Mixed Media"]

export default function Artists() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeFilter, setActiveFilter] = useState("All")

  const filtered = ARTISTS.filter((a) => {
    const matchesMedium = activeFilter === "All" || a.medium === activeFilter
    const q = searchQuery.toLowerCase()
    const matchesSearch = !q || a.name.toLowerCase().includes(q) || a.city.toLowerCase().includes(q)
    return matchesMedium && matchesSearch
  })

  return (
    <PageShell>
      {/* Page header */}
      <div style={{ marginBottom: 16 }}>
        <Eyebrow chapter="04" label="Artists" />
      </div>
      <h1 style={{
        fontFamily: "var(--font-heading)",
        fontSize: "clamp(36px, 5vw, 48px)",
        fontWeight: 500,
        letterSpacing: "-0.03em",
        lineHeight: 1.1,
        color: t.ink,
        margin: "20px 0 16px",
      }}>
        Artist Directory
      </h1>
      <p style={{
        fontFamily: "var(--font-sans)",
        fontSize: 16,
        lineHeight: 1.65,
        color: t.inkMuted,
        maxWidth: 580,
        margin: "0 0 48px",
      }}>
        Independent artists building their practice through ArtWall. Browse the catalogue, read their stories, and connect directly.
      </p>

      <Hairline />

      {/* Search */}
      <div style={{ margin: "32px 0 20px" }}>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search artists by name or city…"
          style={{
            width: "100%",
            padding: "10px 14px",
            border: `1px solid ${t.hairline}`,
            borderRadius: 4,
            fontFamily: "var(--font-sans)",
            fontSize: 14,
            color: t.ink,
            background: t.wallPaper,
            outline: "none",
            boxSizing: "border-box",
          }}
        />
      </div>

      {/* Filter chips */}
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 32 }}>
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setActiveFilter(f)}
            style={{
              fontFamily: "var(--font-sans)",
              fontSize: 12,
              fontWeight: 500,
              padding: "6px 14px",
              borderRadius: 4,
              border: `1px solid ${t.hairline}`,
              cursor: "pointer",
              background: activeFilter === f ? t.ink : t.band,
              color: activeFilter === f ? t.wallPaper : t.ink,
              transition: "background 0.15s, color 0.15s",
            }}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Count */}
      <p style={{ fontFamily: "var(--font-sans)", fontSize: 13, color: t.inkMuted, marginBottom: 24 }}>
        Showing {filtered.length} of 12 artists
      </p>

      {/* Grid */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
        gap: 24,
        marginBottom: 96,
      }}>
        {filtered.map((a) => (
          <div
            key={a.handle}
            style={{
              border: `1px solid ${t.hairline}`,
              borderRadius: 4,
              overflow: "hidden",
              background: t.wallPaper,
            }}
          >
            <img
              src={`https://images.unsplash.com/photo-${a.photo}?w=400&h=300&fit=crop&auto=format`}
              alt={a.name}
              style={{ width: "100%", height: 220, objectFit: "cover", display: "block" }}
            />
            <div style={{ padding: 16 }}>
              <div style={{ marginBottom: 4 }}>
                <span style={{
                  fontFamily: "var(--font-heading)",
                  fontSize: 18,
                  fontWeight: 500,
                  color: t.ink,
                  letterSpacing: "-0.02em",
                }}>
                  {a.name}
                </span>
              </div>
              <div style={{
                fontFamily: "var(--font-sans)",
                fontSize: 12,
                color: t.inkMuted,
                marginBottom: 4,
              }}>
                {a.city} · {a.medium}
              </div>
              <div style={{
                fontFamily: "var(--font-sans)",
                fontSize: 12,
                color: t.inkMuted,
                marginBottom: a.founding ? 12 : 16,
              }}>
                {a.artworks} works
              </div>
              {a.founding && (
                <div style={{ marginBottom: 16 }}>
                  <Badge label="Founding Member" />
                </div>
              )}
              <Link
                to={`/artist/${a.handle}`}
                style={{
                  fontFamily: "var(--font-sans)",
                  fontSize: 13,
                  fontWeight: 500,
                  padding: "8px 16px",
                  borderRadius: 4,
                  border: `1px solid ${t.hairline}`,
                  color: t.ink,
                  background: "transparent",
                  textDecoration: "none",
                  display: "inline-block",
                  letterSpacing: "-0.01em",
                }}
              >
                View Profile
              </Link>
            </div>
          </div>
        ))}
      </div>
    </PageShell>
  )
}
