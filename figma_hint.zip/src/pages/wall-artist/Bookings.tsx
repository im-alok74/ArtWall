import { useState } from 'react'
import { t } from '../../components/tokens'
import { Eyebrow, Hairline, Btn, Badge } from '../../components/ui'

function QRPlaceholder({ size = 80 }: { size?: number }) {
  return (
    <div style={{
      width: size, height: size, display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)',
      gap: 1.5, padding: 8, background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4,
    }}>
      {Array.from({ length: 64 }).map((_, i) => (
        <div key={i} style={{ background: [1,2,3,5,8,13,21,34].includes(i % 17) ? t.ink : 'transparent', borderRadius: 0.5 }} />
      ))}
    </div>
  )
}

function StarRating({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  const [hover, setHover] = useState(0)
  return (
    <div style={{ display: 'flex', gap: 4 }}>
      {[1,2,3,4,5].map(n => (
        <button key={n}
          onMouseEnter={() => setHover(n)} onMouseLeave={() => setHover(0)}
          onClick={() => onChange(n)}
          style={{
            background: 'none', border: 'none', cursor: 'pointer',
            fontSize: 20, color: (hover || value) >= n ? '#f59e0b' : t.hairline,
            padding: '2px 4px',
          }}
        >★</button>
      ))}
    </div>
  )
}

export default function Bookings() {
  const [signPanelOpen, setSignPanelOpen] = useState(false)
  const [feedbackRating, setFeedbackRating] = useState(0)
  const [feedbackOpen, setFeedbackOpen] = useState(false)

  const bookings = [
    {
      id: 'AWL-2025-0801',
      slot: 'B2',
      artwork: 'Urban Geometry',
      dates: '20 Feb – 20 Mar',
      state: 'held',
      badge: <Badge label="Payment due" color="held" />,
      note: 'Payment due by 5 Jan',
      amount: 4500,
    },
    {
      id: 'AWL-2025-0814',
      slot: 'A5',
      artwork: 'Monsoon Memory',
      dates: '1 Mar – 28 Mar',
      state: 'pending-agreement',
      badge: <Badge label="Pending agreement" />,
      note: 'Sign agreement to confirm your slot',
    },
    {
      id: 'AWL-2025-0821',
      slot: 'C5',
      artwork: 'Blue Interval',
      dates: '14 Jan – 11 Feb',
      state: 'install',
      badge: <Badge label="Install window" color="live" />,
      note: 'Install by 14 Jan',
    },
    {
      id: 'AWL-2025-0776',
      slot: 'D3',
      artwork: 'Terra Fragment',
      dates: '1 Dec – 28 Dec',
      state: 'ended',
      badge: <Badge label="Ended" color="ended" />,
      note: 'Exhibition ended 28 Jan',
    },
  ]

  return (
    <div style={{ background: t.wallPaper, minHeight: '100vh', paddingTop: 96 }}>
      <div style={{ maxWidth: 800, margin: '0 auto', padding: '48px 32px' }}>
        <div style={{ marginBottom: 40 }}>
          <div style={{ marginBottom: 12 }}><Eyebrow chapter="Artist" label="My bookings" /></div>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 32, fontWeight: 500, letterSpacing: '-0.025em', color: t.ink }}>
            Bookings
          </h1>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {bookings.map(booking => (
            <div key={booking.id} style={{ border: `1px solid ${t.hairline}`, borderRadius: 4, overflow: 'hidden' }}>
              <div style={{ padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
                  <div>
                    <div style={{ fontFamily: 'var(--font-heading)', fontSize: 18, fontWeight: 500, color: t.ink, marginBottom: 4 }}>
                      {booking.artwork}
                    </div>
                    <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted }}>
                      Slot {booking.slot} · {booking.dates} · {booking.id}
                    </div>
                  </div>
                  {booking.badge}
                </div>

                <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink }}>
                  {booking.note}
                </div>

                {/* State-specific UI */}
                {booking.state === 'held' && (
                  <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
                    <Btn variant="primary">Pay ₹{booking.amount?.toLocaleString('en-IN')}</Btn>
                  </div>
                )}

                {booking.state === 'pending-agreement' && (
                  <div>
                    <Btn variant="primary" onClick={() => setSignPanelOpen(o => !o)}>Sign agreement</Btn>
                    {signPanelOpen && (
                      <div style={{
                        marginTop: 16, padding: '20px 24px',
                        background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4,
                      }}>
                        <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 600, color: t.ink, marginBottom: 12 }}>
                          Sign to confirm your slot
                        </div>
                        <input type="text" placeholder="Type your full name"
                          style={{ width: '100%', maxWidth: 300, padding: '10px 12px', fontFamily: 'var(--font-heading)', fontSize: 16, color: t.ink, background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box', marginBottom: 12 }}
                        />
                        <div style={{ display: 'flex', gap: 10 }}>
                          <Btn variant="primary" onClick={() => setSignPanelOpen(false)}>Confirm signature</Btn>
                          <Btn variant="ghost" onClick={() => setSignPanelOpen(false)}>Cancel</Btn>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {booking.state === 'install' && (
                  <div style={{ display: 'flex', gap: 20, alignItems: 'center', flexWrap: 'wrap' }}>
                    <QRPlaceholder size={72} />
                    <div>
                      <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginBottom: 8 }}>
                        Your installation QR code
                      </div>
                      <a href="#" style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.signal, textDecoration: 'none' }}>
                        Download QR poster →
                      </a>
                    </div>
                  </div>
                )}

                {booking.state === 'ended' && (
                  <div>
                    <Btn variant="quiet" onClick={() => setFeedbackOpen(o => !o)}>Leave feedback</Btn>
                    {feedbackOpen && (
                      <div style={{ marginTop: 16, padding: '20px 24px', background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4 }}>
                        <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 600, color: t.ink, marginBottom: 12 }}>
                          How was your exhibition?
                        </div>
                        <StarRating value={feedbackRating} onChange={setFeedbackRating} />
                        {feedbackRating > 0 && (
                          <div style={{ marginTop: 12 }}>
                            <Btn variant="primary" onClick={() => { setFeedbackOpen(false); setFeedbackRating(0) }}>Submit rating</Btn>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
