import { useState } from 'react'
import { t } from '../../components/tokens'
import { Eyebrow, Hairline, Btn } from '../../components/ui'

type WaitlistState = 'join' | 'queue' | 'held'

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

export default function Waitlist() {
  const [view, setView] = useState<WaitlistState>('join')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [slotSize, setSlotSize] = useState('')
  const [preferredMonths, setPreferredMonths] = useState<string[]>([])

  function toggleMonth(m: string) {
    setPreferredMonths(prev => prev.includes(m) ? prev.filter(x => x !== m) : [...prev, m])
  }

  const tabs: { key: WaitlistState; label: string }[] = [
    { key: 'join', label: 'Join form' },
    { key: 'queue', label: 'In queue' },
    { key: 'held', label: 'Slot held' },
  ]

  return (
    <div style={{ background: t.wallPaper, minHeight: '100vh', paddingTop: 96 }}>
      <div style={{ maxWidth: 560, margin: '0 auto', padding: '48px 24px' }}>
        <div style={{ marginBottom: 32 }}>
          <div style={{ marginBottom: 12 }}><Eyebrow chapter="Artist" label="Waitlist" /></div>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 32, fontWeight: 500, letterSpacing: '-0.025em', color: t.ink }}>
            Physical Wall Waitlist
          </h1>
        </div>

        {/* Demo tabs */}
        <div style={{ display: 'flex', gap: 0, borderBottom: `1px solid ${t.hairline}`, marginBottom: 40 }}>
          {tabs.map(tab => (
            <button key={tab.key} onClick={() => setView(tab.key)} style={{
              fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500,
              padding: '8px 16px', background: 'none', border: 'none',
              borderBottom: view === tab.key ? `2px solid ${t.ink}` : '2px solid transparent',
              color: view === tab.key ? t.ink : t.inkMuted,
              cursor: 'pointer', marginBottom: -1,
            }}>{tab.label}</button>
          ))}
        </div>

        {/* Join form */}
        {view === 'join' && (
          <form onSubmit={e => { e.preventDefault(); setView('queue') }} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <div>
              <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>Name <span style={{ color: t.signal }}>*</span></label>
              <input required type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Your name"
                style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <div>
              <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>Email <span style={{ color: t.signal }}>*</span></label>
              <input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com"
                style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <div>
              <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 8 }}>Preferred slot size</label>
              <div style={{ display: 'flex', gap: 8 }}>
                {['Small', 'Medium', 'Large'].map(s => (
                  <button key={s} type="button" onClick={() => setSlotSize(s)} style={{
                    fontFamily: 'var(--font-sans)', fontSize: 13, padding: '8px 16px', borderRadius: 4,
                    background: slotSize === s ? t.ink : 'transparent',
                    color: slotSize === s ? t.wallPaper : t.inkMuted,
                    border: `1px solid ${slotSize === s ? t.ink : t.hairline}`,
                    cursor: 'pointer',
                  }}>{s}</button>
                ))}
              </div>
            </div>
            <div>
              <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 10 }}>Preferred months</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {MONTHS.map(m => (
                  <label key={m} style={{
                    display: 'flex', alignItems: 'center', gap: 6,
                    fontFamily: 'var(--font-sans)', fontSize: 12, color: t.ink, cursor: 'pointer',
                    padding: '5px 10px', border: `1px solid ${preferredMonths.includes(m) ? t.ink : t.hairline}`,
                    borderRadius: 4, background: preferredMonths.includes(m) ? t.band : 'transparent',
                  }}>
                    <input type="checkbox" checked={preferredMonths.includes(m)} onChange={() => toggleMonth(m)} style={{ accentColor: t.ink }} />
                    {m.slice(0, 3)}
                  </label>
                ))}
              </div>
            </div>
            <div style={{ paddingTop: 8 }}>
              <Btn type="submit" variant="primary">Join the waitlist</Btn>
            </div>
          </form>
        )}

        {/* In queue */}
        {view === 'queue' && (
          <div style={{ textAlign: 'center' }}>
            <div style={{ marginBottom: 32 }}>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: 96, fontWeight: 500, color: t.ink, lineHeight: 1, letterSpacing: '-0.04em' }}>
                4
              </div>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 15, color: t.inkMuted, marginTop: 8 }}>
                of 12 in queue
              </div>
            </div>
            <div style={{ padding: '20px 24px', border: `1px solid ${t.hairline}`, borderRadius: 4, marginBottom: 32, textAlign: 'left' }}>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginBottom: 4 }}>Estimated wait</div>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 500, color: t.ink }}>6–8 weeks</div>
            </div>
            <div style={{ display: 'flex', gap: 16, justifyContent: 'center' }}>
              <a href="#" style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.signal, textDecoration: 'none' }}>Update preferences</a>
              <span style={{ color: t.hairline }}>·</span>
              <button onClick={() => setView('join')} style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, background: 'none', border: 'none', cursor: 'pointer', textDecoration: 'underline' }}>
                Leave queue
              </button>
            </div>
          </div>
        )}

        {/* Slot held */}
        {view === 'held' && (
          <div>
            <div style={{ marginBottom: 24, padding: '20px 24px', background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 4 }}>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: '#166534', fontWeight: 600, marginBottom: 4, letterSpacing: '0.04em', textTransform: 'uppercase' }}>
                Slot available
              </div>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 500, color: t.ink }}>
                A slot is being held for you!
              </div>
            </div>

            <div style={{ padding: '24px', border: `1px solid ${t.hairline}`, borderRadius: 4, marginBottom: 24 }}>
              {[
                ['Slot', 'A5'],
                ['Size', '60 × 80 cm'],
                ['Price', '₹4,500 / week'],
              ].map(([label, value]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
                  <span style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted }}>{label}</span>
                  <span style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, fontWeight: 500 }}>{value}</span>
                </div>
              ))}
              <Hairline />
              <div style={{ marginTop: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: '#dc2626', fontWeight: 500 }}>Hold expires in 48 hours</span>
              </div>
            </div>

            <Btn variant="primary" href="/physical-wall/book">Book this slot →</Btn>
          </div>
        )}
      </div>
    </div>
  )
}
