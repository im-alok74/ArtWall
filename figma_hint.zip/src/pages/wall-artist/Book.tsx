import { useState } from 'react'
import { t } from '../../components/tokens'
import { Eyebrow, Hairline, Btn, Badge } from '../../components/ui'

type SlotState = 'available' | 'booked' | 'live' | 'maintenance'
const ROWS = ['A', 'B', 'C', 'D']
const COLS = [1, 2, 3, 4, 5, 6]
const SLOT_STATES: Record<string, SlotState> = {
  A1: 'live', A2: 'booked', A3: 'live', A4: 'available', A5: 'available', A6: 'live',
  B1: 'live', B2: 'available', B3: 'booked', B4: 'booked', B5: 'live', B6: 'available',
  C1: 'available', C2: 'live', C3: 'maintenance', C4: 'live', C5: 'available', C6: 'booked',
  D1: 'booked', D2: 'live', D3: 'available', D4: 'available', D5: 'live', D6: 'maintenance',
}
const SLOT_INFO: Record<string, { size: string; price: number }> = {
  A4: { size: 'Small', price: 2500 }, A5: { size: 'Medium', price: 4500 },
  B2: { size: 'Large', price: 6500 }, B6: { size: 'Small', price: 2500 },
  C1: { size: 'Medium', price: 4500 }, C5: { size: 'Large', price: 6500 },
  D3: { size: 'Small', price: 2500 }, D4: { size: 'Medium', price: 4500 },
}
const ARTWORKS = [
  { id: 1, photo: '1579783902614-a72e7b3e2b08', title: 'Monsoon Memory', medium: 'Oil on canvas' },
  { id: 2, photo: '1618005182384-a83a8bd57fbe', title: 'Urban Geometry', medium: 'Acrylic' },
  { id: 3, photo: '1508193638397-1c4234db14d8', title: 'Still Life No. 7', medium: 'Watercolour' },
  { id: 4, photo: '1549887534-1541e9ab5df7', title: 'Terra Fragment', medium: 'Terracotta sculpture' },
  { id: 5, photo: '1572947650440-e8a97ef053b2', title: 'Blue Interval', medium: 'Photography' },
  { id: 6, photo: '1558618666-fcd25c85cd64', title: 'Market, Dusk', medium: 'Photography' },
]
const ADDONS = [
  { id: 'install', label: 'Professional installation', price: 500, note: 'Recommended' },
  { id: 'cert', label: 'Certificate of display', price: 200 },
  { id: 'insurance', label: 'Extended insurance', price: 300, note: '₹300/week' },
  { id: 'framing', label: 'Framing service', price: 1200 },
]
const STEPS = ['Slots', 'Dates', 'Artwork', 'Add-ons', 'Agreement']

const TERMS = [
  "Slot Usage: The artist is granted exclusive use of the selected wall slot for the agreed period. The slot may only display the artwork submitted during booking. Any changes to displayed work must be approved in writing by ArtWall Labs at least 48 hours in advance.",
  "Removal Policy: ArtWall Labs reserves the right to remove any artwork that violates community standards, is reported as damaged, or presents a safety concern. Artists will be notified within 24 hours of removal. No refund is issued for removal due to policy violation.",
  "Revenue Share: ArtWall Labs does not take a commission on artwork sales made via the platform enquiry form. However, a 5% facilitation fee applies to sales completed through ArtWall-introduced buyers. This fee is payable within 30 days of sale completion.",
  "Liability: ArtWall Labs maintains basic property insurance covering the physical premises. Artists are strongly advised to maintain their own insurance for artwork value. ArtWall Labs is not liable for damage caused by visitors, natural events, or circumstances beyond reasonable control.",
  "Data Use: ArtWall Labs will store your booking data, artwork images, and visitor interaction data (scan counts, reactions) in accordance with our Privacy Policy and the Digital Personal Data Protection Act, 2023. You may request deletion of your data at any time via the Account page.",
]

export default function Book() {
  const [step, setStep] = useState(0)
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null)
  const [fromDate, setFromDate] = useState('')
  const [untilDate, setUntilDate] = useState('')
  const [selectedArtwork, setSelectedArtwork] = useState<number | null>(null)
  const [selectedAddons, setSelectedAddons] = useState<string[]>(['install'])
  const [signatureName, setSignatureName] = useState('')
  const [agreed, setAgreed] = useState(false)
  const [confirmed, setConfirmed] = useState(false)

  const slotInfo = selectedSlot ? SLOT_INFO[selectedSlot] : null

  function durationWeeks() {
    if (!fromDate || !untilDate) return 0
    const d = (new Date(untilDate).getTime() - new Date(fromDate).getTime()) / (1000 * 60 * 60 * 24 * 7)
    return Math.max(0, Math.round(d))
  }

  function addonTotal() {
    return selectedAddons.reduce((sum, id) => {
      const a = ADDONS.find(x => x.id === id)
      if (!a) return sum
      if (id === 'insurance') return sum + a.price * durationWeeks()
      return sum + a.price
    }, 0)
  }

  const slotCostPerWeek = slotInfo?.price ?? 0
  const weeks = durationWeeks()
  const subtotal = slotCostPerWeek * weeks + addonTotal()
  const gst = Math.round(subtotal * 0.18)
  const total = subtotal + gst
  const artwork = ARTWORKS.find(a => a.id === selectedArtwork)

  function slotStyle(state: SlotState, key: string): React.CSSProperties {
    const isSelected = selectedSlot === key
    if (isSelected) return { background: t.ink, color: t.wallPaper, border: `2px solid ${t.ink}` }
    if (state === 'available') return { background: t.wallPaper, color: t.inkMuted, border: `1px solid ${t.hairline}`, cursor: 'pointer' }
    if (state === 'booked') return { background: t.band, color: t.inkMuted, border: `1px solid ${t.hairline}`, cursor: 'not-allowed', opacity: 0.5 }
    if (state === 'live') return { background: t.band, color: t.inkMuted, border: `1px solid ${t.hairline}`, cursor: 'not-allowed', opacity: 0.5 }
    return { background: t.band, color: t.inkMuted, border: `1px solid ${t.hairline}`, cursor: 'not-allowed', opacity: 0.5 }
  }

  if (confirmed) {
    return (
      <div style={{ background: t.wallPaper, minHeight: '100vh', paddingTop: 96, display: 'flex', justifyContent: 'center' }}>
        <div style={{ maxWidth: 560, width: '100%', padding: '48px 24px' }}>
          <div style={{ marginBottom: 24 }}><Eyebrow chapter="Booking" label="Confirmed" /></div>
          <div style={{
            border: `1px solid ${t.hairline}`, borderRadius: 4, overflow: 'hidden',
          }}>
            <div style={{ background: t.ink, padding: '28px 32px' }}>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: 'rgba(255,255,255,0.5)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8 }}>Booking reference</div>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500, color: t.wallPaper }}>AWL-2025-0847</div>
            </div>
            <div style={{ padding: 32, display: 'flex', flexDirection: 'column', gap: 16 }}>
              {[
                ['Slot', selectedSlot ?? '—'],
                ['Dates', fromDate && untilDate ? `${fromDate} – ${untilDate}` : '—'],
                ['Artwork', artwork?.title ?? '—'],
                ['Total paid', total ? `₹${total.toLocaleString('en-IN')} (incl. GST)` : '—'],
              ].map(([label, value]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted }}>{label}</span>
                  <span style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, fontWeight: 500 }}>{value}</span>
                </div>
              ))}
              <Hairline />
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <a href="#" style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.signal, textDecoration: 'none' }}>+ Add to calendar</a>
                <a href="/physical-wall/bookings" style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.signal, textDecoration: 'none' }}>View my bookings →</a>
                <a href="#" style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.signal, textDecoration: 'none' }}>Download confirmation PDF</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{ background: t.wallPaper, minHeight: '100vh', paddingTop: 96 }}>
      <div style={{ maxWidth: 1240, margin: '0 auto', padding: '48px 32px' }}>
        <div style={{ marginBottom: 40 }}>
          <div style={{ marginBottom: 20 }}><Eyebrow chapter="Artist" label="Book a slot" /></div>
          {/* Stepper */}
          <div style={{ display: 'flex', gap: 0, borderBottom: `1px solid ${t.hairline}` }}>
            {STEPS.map((s, i) => (
              <button key={s} onClick={() => i < step && setStep(i)} style={{
                fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500,
                padding: '10px 20px', background: 'none', border: 'none',
                borderBottom: step === i ? `2px solid ${t.ink}` : '2px solid transparent',
                color: step === i ? t.ink : i < step ? t.inkMuted : t.hairline,
                cursor: i < step ? 'pointer' : 'default',
                marginBottom: -1, letterSpacing: '-0.01em',
              }}>
                {i + 1}. {s}
              </button>
            ))}
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 48, alignItems: 'start' }}>
          {/* Main content */}
          <div>
            {/* Step 1: Slots */}
            {step === 0 && (
              <div>
                <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 500, color: t.ink, marginBottom: 8 }}>Choose a slot</h2>
                <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 32 }}>Available slots are shown in white. Click to select.</p>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 64px)', gap: 8, marginBottom: 24 }}>
                  {ROWS.flatMap(row => COLS.map(col => {
                    const key = `${row}${col}`
                    const state = SLOT_STATES[key]
                    const isAvail = state === 'available'
                    return (
                      <div key={key}
                        onClick={isAvail ? () => setSelectedSlot(key) : undefined}
                        style={{ ...slotStyle(state, key), borderRadius: 4, padding: '14px 4px', textAlign: 'center' }}
                      >
                        <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 600 }}>{key}</div>
                        {isAvail && SLOT_INFO[key] && (
                          <div style={{ fontFamily: 'var(--font-sans)', fontSize: 9, marginTop: 2 }}>
                            {SLOT_INFO[key].size}
                          </div>
                        )}
                      </div>
                    )
                  }))}
                </div>
                <Btn variant="primary" disabled={!selectedSlot} onClick={() => setStep(1)}>
                  Continue to dates →
                </Btn>
              </div>
            )}

            {/* Step 2: Dates */}
            {step === 1 && (
              <div>
                <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 500, color: t.ink, marginBottom: 8 }}>Choose dates</h2>
                <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 8 }}>Minimum 14 days · Maximum 90 days</p>
                <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginBottom: 32, padding: '10px 14px', background: t.band, borderRadius: 4, border: `1px solid ${t.hairline}` }}>
                  Already booked: Jan 14–28 · Feb 10–24
                </div>
                <div style={{ display: 'flex', gap: 16, marginBottom: 24, flexWrap: 'wrap' }}>
                  <div style={{ flex: 1, minWidth: 160 }}>
                    <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>From</label>
                    <input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)}
                      style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box' }}
                    />
                  </div>
                  <div style={{ flex: 1, minWidth: 160 }}>
                    <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>Until</label>
                    <input type="date" value={untilDate} onChange={e => setUntilDate(e.target.value)}
                      style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box' }}
                    />
                  </div>
                </div>
                {weeks > 0 && (
                  <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 24 }}>
                    Duration: {weeks} weeks · Slot cost: ₹{(slotCostPerWeek * weeks).toLocaleString('en-IN')}
                  </div>
                )}
                <div style={{ display: 'flex', gap: 12 }}>
                  <Btn variant="quiet" onClick={() => setStep(0)}>← Back</Btn>
                  <Btn variant="primary" disabled={!fromDate || !untilDate} onClick={() => setStep(2)}>Continue to artwork →</Btn>
                </div>
              </div>
            )}

            {/* Step 3: Artwork */}
            {step === 2 && (
              <div>
                <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 500, color: t.ink, marginBottom: 8 }}>Select artwork</h2>
                <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 32 }}>Choose from your catalogue or upload a new work.</p>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
                  {ARTWORKS.map(art => (
                    <div key={art.id} onClick={() => setSelectedArtwork(art.id)} style={{
                      border: selectedArtwork === art.id ? `2px solid ${t.ink}` : `1px solid ${t.hairline}`,
                      borderRadius: 4, overflow: 'hidden', cursor: 'pointer',
                    }}>
                      <img src={`https://images.unsplash.com/photo-${art.photo}?w=300&h=200&fit=crop&auto=format`}
                        alt={art.title} style={{ width: '100%', height: 120, objectFit: 'cover', display: 'block' }} />
                      <div style={{ padding: '10px 12px' }}>
                        <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 600, color: t.ink }}>{art.title}</div>
                        <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted }}>{art.medium}</div>
                      </div>
                    </div>
                  ))}
                  <div style={{
                    border: `1px dashed ${t.hairline}`, borderRadius: 4, cursor: 'pointer',
                    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                    padding: 24, gap: 8, minHeight: 160,
                  }}>
                    <div style={{ fontFamily: 'var(--font-sans)', fontSize: 20, color: t.hairline }}>+</div>
                    <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted, textAlign: 'center' }}>Upload a new artwork</div>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 12 }}>
                  <Btn variant="quiet" onClick={() => setStep(1)}>← Back</Btn>
                  <Btn variant="primary" disabled={!selectedArtwork} onClick={() => setStep(3)}>Continue to add-ons →</Btn>
                </div>
              </div>
            )}

            {/* Step 4: Add-ons */}
            {step === 3 && (
              <div>
                <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 500, color: t.ink, marginBottom: 8 }}>Optional add-ons</h2>
                <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 32 }}>Enhance your exhibition with these services.</p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 32 }}>
                  {ADDONS.map(addon => (
                    <label key={addon.id} style={{
                      display: 'flex', gap: 16, alignItems: 'center',
                      padding: '16px 20px', border: `1px solid ${selectedAddons.includes(addon.id) ? t.ink : t.hairline}`,
                      borderRadius: 4, cursor: 'pointer', background: t.wallPaper,
                    }}>
                      <input type="checkbox" checked={selectedAddons.includes(addon.id)}
                        onChange={e => setSelectedAddons(prev => e.target.checked ? [...prev, addon.id] : prev.filter(x => x !== addon.id))}
                        style={{ accentColor: t.ink, flexShrink: 0 }}
                      />
                      <div style={{ flex: 1 }}>
                        <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 500, color: t.ink }}>
                          {addon.label}
                          {addon.note && <span style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: t.signal, marginLeft: 8 }}>{addon.note}</span>}
                        </div>
                      </div>
                      <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, flexShrink: 0 }}>₹{addon.price.toLocaleString('en-IN')}</div>
                    </label>
                  ))}
                </div>
                <div style={{ display: 'flex', gap: 12 }}>
                  <Btn variant="quiet" onClick={() => setStep(2)}>← Back</Btn>
                  <Btn variant="primary" onClick={() => setStep(4)}>Continue to agreement →</Btn>
                </div>
              </div>
            )}

            {/* Step 5: Agreement */}
            {step === 4 && (
              <div>
                <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 500, color: t.ink, marginBottom: 8 }}>Booking agreement</h2>
                <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 24 }}>Read and sign to confirm your booking.</p>
                <div style={{
                  maxHeight: 280, overflowY: 'auto', padding: '20px 24px',
                  border: `1px solid ${t.hairline}`, borderRadius: 4, marginBottom: 28,
                  display: 'flex', flexDirection: 'column', gap: 16,
                }}>
                  {TERMS.map((para, i) => (
                    <p key={i} style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, lineHeight: 1.75, margin: 0 }}>
                      <strong style={{ fontWeight: 600 }}>{para.split(':')[0]}:</strong>{para.slice(para.indexOf(':') + 1)}
                    </p>
                  ))}
                </div>
                <div style={{ marginBottom: 20 }}>
                  <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>
                    Type your full name to sign
                  </label>
                  <input type="text" placeholder="Your name" value={signatureName} onChange={e => setSignatureName(e.target.value)}
                    style={{ width: '100%', maxWidth: 320, padding: '10px 12px', fontFamily: 'var(--font-heading)', fontSize: 18, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box' }}
                  />
                </div>
                <label style={{ display: 'flex', gap: 12, alignItems: 'flex-start', marginBottom: 28, cursor: 'pointer' }}>
                  <input type="checkbox" checked={agreed} onChange={e => setAgreed(e.target.checked)} style={{ marginTop: 2, accentColor: t.ink, flexShrink: 0 }} />
                  <span style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, lineHeight: 1.6 }}>
                    I agree to these terms and confirm that the information I have provided is accurate.
                  </span>
                </label>
                <div style={{ display: 'flex', gap: 12 }}>
                  <Btn variant="quiet" onClick={() => setStep(3)}>← Back</Btn>
                  <Btn variant="primary" disabled={!agreed || !signatureName} onClick={() => setConfirmed(true)}>
                    Confirm booking
                  </Btn>
                </div>
              </div>
            )}
          </div>

          {/* Sticky summary */}
          <div style={{ position: 'sticky', top: 112, border: `1px solid ${t.hairline}`, borderRadius: 4, overflow: 'hidden' }}>
            <div style={{ background: t.band, padding: '14px 20px', borderBottom: `1px solid ${t.hairline}` }}>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 600, color: t.ink, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Booking summary</div>
            </div>
            <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: 12 }}>
              {[
                ['Slot', selectedSlot ?? '—'],
                ['Size', slotInfo?.size ?? '—'],
                ['Dates', fromDate && untilDate ? `${fromDate} to ${untilDate}` : '—'],
                ['Duration', weeks ? `${weeks} weeks` : '—'],
                ['Artwork', artwork?.title ?? '—'],
              ].map(([label, value]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>{label}</span>
                  <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.ink, fontWeight: 500, textAlign: 'right', maxWidth: 160 }}>{value}</span>
                </div>
              ))}
              {selectedAddons.length > 0 && (
                <div>
                  <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginBottom: 6 }}>Add-ons</div>
                  {selectedAddons.map(id => {
                    const a = ADDONS.find(x => x.id === id)
                    return a ? (
                      <div key={id} style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.ink, paddingLeft: 8, marginBottom: 2 }}>· {a.label}</div>
                    ) : null
                  })}
                </div>
              )}
              <Hairline />
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>Subtotal</span>
                <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.ink }}>₹{subtotal.toLocaleString('en-IN')}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>GST (18%)</span>
                <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.ink }}>₹{gst.toLocaleString('en-IN')}</span>
              </div>
              <Hairline />
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontFamily: 'var(--font-sans)', fontSize: 14, fontWeight: 600, color: t.ink }}>Total</span>
                <span style={{ fontFamily: 'var(--font-sans)', fontSize: 14, fontWeight: 600, color: t.ink }}>₹{total.toLocaleString('en-IN')}</span>
              </div>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 10, color: t.inkMuted }}>GST included</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
