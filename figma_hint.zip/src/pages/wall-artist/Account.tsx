import { useState } from 'react'
import { t } from '../../components/tokens'
import { Eyebrow, Hairline, Btn } from '../../components/ui'

type ConsentKey = 'account' | 'profile' | 'marketing' | 'analytics' | 'founding'

const CONSENTS: { key: ConsentKey; label: string; description: string; required?: boolean; initial: boolean }[] = [
  {
    key: 'account',
    label: 'Account operation',
    description: "Required to operate your account, process bookings, and issue certificates. Cannot be disabled.",
    required: true,
    initial: true,
  },
  {
    key: 'profile',
    label: 'Profile publication',
    description: "Allows your artist profile, name, and artworks to be displayed publicly on the ArtWall platform.",
    initial: true,
  },
  {
    key: 'marketing',
    label: 'Marketing communications',
    description: "Receive email updates about new exhibitions, booking opportunities, and ArtWall news.",
    initial: false,
  },
  {
    key: 'analytics',
    label: 'Analytics and improvement',
    description: "Help us improve the platform by sharing anonymised usage data such as page visits and feature use.",
    initial: true,
  },
  {
    key: 'founding',
    label: 'Founding member listing',
    description: "Be listed as a founding member artist on the ArtWall about page.",
    initial: false,
  },
]

function Toggle({ on, locked, onChange }: { on: boolean; locked?: boolean; onChange?: (v: boolean) => void }) {
  return (
    <button
      onClick={locked ? undefined : () => onChange?.(!on)}
      style={{
        width: 44, height: 24, borderRadius: 12,
        background: on ? t.ink : t.hairline,
        border: 'none', cursor: locked ? 'not-allowed' : 'pointer',
        position: 'relative', flexShrink: 0, transition: 'background 0.2s',
        opacity: locked ? 0.6 : 1,
      }}
    >
      <span style={{
        position: 'absolute', top: 3, left: on ? 23 : 3,
        width: 18, height: 18, borderRadius: '50%',
        background: t.wallPaper,
        transition: 'left 0.2s',
        display: 'block',
      }} />
    </button>
  )
}

export default function Account() {
  const [consents, setConsents] = useState<Record<ConsentKey, boolean>>(
    Object.fromEntries(CONSENTS.map(c => [c.key, c.initial])) as Record<ConsentKey, boolean>
  )
  const [lastChanged] = useState<Record<ConsentKey, string>>({
    account: '—',
    profile: '10 Jan 2025',
    marketing: '5 Dec 2024',
    analytics: '10 Jan 2025',
    founding: '8 Nov 2024',
  })
  const [deleteMode, setDeleteMode] = useState(false)
  const [deleteConfirm, setDeleteConfirm] = useState('')

  return (
    <div style={{ background: t.wallPaper, minHeight: '100vh', paddingTop: 96 }}>
      <div style={{ maxWidth: 720, margin: '0 auto', padding: '48px 32px' }}>
        <div style={{ marginBottom: 48 }}>
          <div style={{ marginBottom: 12 }}><Eyebrow chapter="Artist" label="Account settings" /></div>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 32, fontWeight: 500, letterSpacing: '-0.025em', color: t.ink }}>
            Data rights centre
          </h1>
        </div>

        {/* 1. Consent toggles */}
        <section style={{ marginBottom: 48 }}>
          <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 20, fontWeight: 500, color: t.ink, marginBottom: 4 }}>Consent</h2>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 24 }}>Control how your data is used. Changes take effect immediately.</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {CONSENTS.map((c, i) => (
              <div key={c.key}>
                {i > 0 && <Hairline />}
                <div style={{ display: 'flex', gap: 20, alignItems: 'center', padding: '20px 0' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <span style={{ fontFamily: 'var(--font-sans)', fontSize: 14, fontWeight: 600, color: t.ink }}>{c.label}</span>
                      {c.required && <span style={{ fontFamily: 'var(--font-sans)', fontSize: 10, color: t.inkMuted, background: t.band, padding: '2px 6px', borderRadius: 3, letterSpacing: '0.04em', textTransform: 'uppercase' }}>Required</span>}
                    </div>
                    <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, margin: 0, lineHeight: 1.6 }}>{c.description}</p>
                    <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: t.hairline, marginTop: 6 }}>Last changed: {lastChanged[c.key]}</div>
                  </div>
                  <Toggle
                    on={consents[c.key]}
                    locked={c.required}
                    onChange={v => setConsents(prev => ({ ...prev, [c.key]: v }))}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        <Hairline />

        {/* 2. Your data */}
        <section style={{ padding: '40px 0' }}>
          <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 20, fontWeight: 500, color: t.ink, marginBottom: 4 }}>Your data</h2>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 20 }}>
            Request a copy of all data we hold about you. You will receive an email within 48 hours.
          </p>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            <Btn variant="quiet">Request a copy of your data</Btn>
            <a href="#" style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.signal, textDecoration: 'none', display: 'flex', alignItems: 'center' }}>Correct your information →</a>
          </div>
        </section>

        <Hairline />

        {/* 3. Nominee */}
        <section style={{ padding: '40px 0' }}>
          <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 20, fontWeight: 500, color: t.ink, marginBottom: 4 }}>Nominee</h2>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 24 }}>
            Who should manage your account if you are unreachable?
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 400 }}>
            {[
              { label: 'Name', type: 'text', placeholder: "Nominee's full name" },
              { label: 'Relationship', type: 'text', placeholder: 'e.g. Spouse, Sibling, Friend' },
              { label: 'Contact', type: 'tel', placeholder: 'Phone or email' },
            ].map(f => (
              <div key={f.label}>
                <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>{f.label}</label>
                <input type={f.type} placeholder={f.placeholder}
                  style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box' }} />
              </div>
            ))}
            <div><Btn variant="quiet">Save nominee</Btn></div>
          </div>
        </section>

        <Hairline />

        {/* 4. Grievance */}
        <section style={{ padding: '40px 0' }}>
          <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 20, fontWeight: 500, color: t.ink, marginBottom: 4 }}>Grievance</h2>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 24 }}>
            We will respond within 30 days as required by the Digital Personal Data Protection Act, 2023.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 480 }}>
            <div>
              <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>Name</label>
              <input type="text" placeholder="Your name"
                style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <div>
              <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>Description of issue</label>
              <input type="text" placeholder="Brief description"
                style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <div>
              <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>Details</label>
              <textarea rows={5} placeholder="Please describe the issue in detail"
                style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box', resize: 'vertical' }} />
            </div>
            <div><Btn variant="quiet">Submit grievance</Btn></div>
          </div>
        </section>

        <Hairline />

        {/* 5. Account deletion */}
        <section style={{ padding: '40px 0' }}>
          <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 20, fontWeight: 500, color: t.ink, marginBottom: 4 }}>Account deletion</h2>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 20 }}>
            Permanently remove your account and all associated data. Your certificates remain valid.
          </p>
          {!deleteMode ? (
            <Btn variant="danger" onClick={() => setDeleteMode(true)}>Delete my account</Btn>
          ) : (
            <div style={{ padding: '24px', background: '#fff5f5', border: '1px solid #fecaca', borderRadius: 4, maxWidth: 400 }}>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: '#991b1b', marginBottom: 16, lineHeight: 1.6 }}>
                This will remove all your data. Your certificates remain valid and will continue to be accessible via their unique links.
              </div>
              <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>
                Type DELETE to confirm
              </label>
              <input type="text" value={deleteConfirm} onChange={e => setDeleteConfirm(e.target.value)} placeholder="DELETE"
                style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, background: t.wallPaper, border: '1px solid #fca5a5', borderRadius: 4, outline: 'none', boxSizing: 'border-box', marginBottom: 16 }} />
              <div style={{ display: 'flex', gap: 10 }}>
                <Btn variant="danger" disabled={deleteConfirm !== 'DELETE'}>Permanently delete</Btn>
                <Btn variant="ghost" onClick={() => { setDeleteMode(false); setDeleteConfirm('') }}>Cancel</Btn>
              </div>
            </div>
          )}
        </section>
      </div>
    </div>
  )
}
