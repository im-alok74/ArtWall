import { useState, useRef } from 'react'
import { useParams } from 'react-router'
import { t } from '../../components/tokens'
import { Eyebrow, Btn } from '../../components/ui'

function StarRating({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  const [hover, setHover] = useState(0)
  return (
    <div style={{ display: 'flex', gap: 6 }}>
      {[1, 2, 3, 4, 5].map(n => (
        <button key={n}
          type="button"
          onMouseEnter={() => setHover(n)} onMouseLeave={() => setHover(0)}
          onClick={() => onChange(n)}
          style={{
            background: 'none', border: 'none', cursor: 'pointer',
            fontSize: 32, color: (hover || value) >= n ? '#f59e0b' : t.hairline,
            padding: '2px 4px', lineHeight: 1, transition: 'color 0.1s',
          }}
        >&#9733;</button>
      ))}
    </div>
  )
}

function NPSScale({ value, onChange }: { value: number | null; onChange: (v: number) => void }) {
  return (
    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
      {Array.from({ length: 11 }, (_, i) => i).map(n => (
        <button key={n} type="button" onClick={() => onChange(n)} style={{
          width: 40, height: 40, borderRadius: 4,
          background: value === n ? t.ink : 'transparent',
          color: value === n ? t.wallPaper : t.inkMuted,
          border: `1px solid ${value === n ? t.ink : t.hairline}`,
          fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 500,
          cursor: 'pointer',
        }}>{n}</button>
      ))}
    </div>
  )
}

export default function Feedback() {
  const { id } = useParams()
  const [rating, setRating] = useState(0)
  const [nps, setNps] = useState<number | null>(null)
  const [wentWell, setWentWell] = useState('')
  const [improve, setImprove] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const [fileNames, setFileNames] = useState<string[]>([])
  const [dragging, setDragging] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div style={{ background: t.wallPaper, minHeight: '100vh', paddingTop: 96, display: 'flex', justifyContent: 'center' }}>
        <div style={{ maxWidth: 560, width: '100%', padding: '80px 24px', textAlign: 'center' }}>
          <div style={{ marginBottom: 20 }}>
            <Eyebrow chapter="Feedback" label="Submitted" />
          </div>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 32, fontWeight: 500, letterSpacing: '-0.025em', color: t.ink, marginBottom: 16 }}>
            Thank you.
          </h1>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 15, color: t.inkMuted, lineHeight: 1.7, marginBottom: 32 }}>
            Your feedback helps us improve the ArtWall experience for every artist.
          </p>
          <a href="/physical-wall/a/1" style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.signal, textDecoration: 'none' }}>
            View your archived exhibition &#8594;
          </a>
        </div>
      </div>
    )
  }

  return (
    <div style={{ background: t.wallPaper, minHeight: '100vh', paddingTop: 96 }}>
      <div style={{ maxWidth: 560, margin: '0 auto', padding: '48px 24px' }}>
        <div style={{ marginBottom: 32 }}>
          <div style={{ marginBottom: 12 }}><Eyebrow chapter="Post-exhibition" label="Feedback" /></div>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 32, fontWeight: 500, letterSpacing: '-0.025em', color: t.ink, marginBottom: 6 }}>
            How was your exhibition?
          </h1>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted }}>Slot A3 · 14 Jan – 28 Jan</p>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 36 }}>
          <div>
            <label style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: t.ink, display: 'block', marginBottom: 12 }}>
              Overall experience
            </label>
            <StarRating value={rating} onChange={setRating} />
          </div>

          <div>
            <label style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: t.ink, display: 'block', marginBottom: 4 }}>
              How likely are you to recommend ArtWall to another artist?
            </label>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted, marginBottom: 12 }}>0 = not at all · 10 = definitely</div>
            <NPSScale value={nps} onChange={setNps} />
          </div>

          <div>
            <label style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: t.ink, display: 'block', marginBottom: 8 }}>
              What went well?
            </label>
            <textarea
              rows={4} value={wentWell} onChange={e => setWentWell(e.target.value)}
              placeholder="The installation process, the visibility of my work, visitor engagement..."
              style={{ width: '100%', padding: '12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box', resize: 'vertical' }}
            />
          </div>

          <div>
            <label style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: t.ink, display: 'block', marginBottom: 8 }}>
              What could be better?
            </label>
            <textarea
              rows={4} value={improve} onChange={e => setImprove(e.target.value)}
              placeholder="Lighting, signage, communication..."
              style={{ width: '100%', padding: '12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box', resize: 'vertical' }}
            />
          </div>

          <div>
            <label style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: t.ink, display: 'block', marginBottom: 8 }}>
              Would you like to share any photos from the installation or exhibition?
            </label>
            <div
              onDragOver={e => { e.preventDefault(); setDragging(true) }}
              onDragLeave={() => setDragging(false)}
              onDrop={e => {
                e.preventDefault(); setDragging(false)
                const files = Array.from(e.dataTransfer.files)
                setFileNames(files.map(f => f.name))
              }}
              onClick={() => fileRef.current?.click()}
              style={{
                border: `2px dashed ${dragging ? t.ink : t.hairline}`,
                borderRadius: 4, padding: '40px 24px', textAlign: 'center',
                cursor: 'pointer', background: dragging ? t.band : 'transparent',
                transition: 'all 0.15s',
              }}
            >
              <input ref={fileRef} type="file" multiple accept="image/*"
                onChange={e => setFileNames(Array.from(e.target.files ?? []).map(f => f.name))}
                style={{ display: 'none' }}
              />
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted }}>
                Drop photos here or click to browse
              </div>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: t.hairline, marginTop: 4 }}>
                JPG, PNG · up to 10 files
              </div>
            </div>
            {fileNames.length > 0 && (
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 4 }}>
                {fileNames.map(n => (
                  <div key={n} style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>· {n}</div>
                ))}
              </div>
            )}
          </div>

          <div>
            <Btn type="submit" variant="primary">Submit feedback</Btn>
          </div>
        </form>
      </div>
    </div>
  )
}
