import { useState } from 'react'
import { t } from '../components/tokens'
import { Eyebrow, Hairline, SectionHeader, PageShell } from '../components/ui'

const faqs = [
  {
    q: "Is ArtWall Labs only for established artists?",
    a: "No. We welcome artists at all career stages, from recent graduates to mid-career practitioners. The minimum requirement is an active practice and at least five finished works available for cataloguing. We review each application within seven business days.",
  },
  {
    q: "What does it cost to list on ArtWall?",
    a: "Listing your catalogue is free. Physical wall bookings cost ₹800–₹3,200 depending on venue tier and duration (7, 14, or 28 days). ArtWall takes an 8% platform fee only when a sale is recorded through the platform — we earn when you earn.",
  },
  {
    q: "Which cities have physical wall venues?",
    a: "We currently operate in Jaipur (4 venues), Mumbai (3 venues), Delhi (2 venues), and Bengaluru (2 venues). New cities are added quarterly — Pune, Hyderabad, and Ahmedabad are scheduled for Q3 2025.",
  },
  {
    q: "How does provenance certification work?",
    a: "Every artwork receives a certificate with a unique SHA-256 hash linking the work to your identity, its dimensions, medium, and edition. When the work is sold, the certificate transfers to the buyer. On resale, your 5% royalty is automatically triggered. The certificate chain is publicly verifiable.",
  },
  {
    q: "Can I set my own prices?",
    a: "Yes, completely. ArtWall does not impose price floors or ceilings. We provide market data from comparable works to help you price confidently, but all final decisions are yours.",
  },
  {
    q: "What happens to my data if I leave?",
    a: "Your catalogue data, provenance records, and sales history are always exportable as CSV or JSON. Provenance certificates remain permanently on record even if you deactivate your account, because they belong to the artwork, not the platform account.",
  },
  {
    q: "Do I need to attend physical wall openings?",
    a: "No. Walls operate without your presence — QR codes do the storytelling. Many artists find that buyers actually prefer the intimacy of discovering a work independently. That said, we encourage periodic visits, and some venues host artist evenings.",
  },
  {
    q: "How are royalties paid?",
    a: "Resale royalties are tracked automatically when a resale is processed on-platform. Payouts are made on the 1st of each month via NEFT or UPI to your registered bank account. Minimum payout threshold is ₹500.",
  },
  {
    q: "Is photography eligible for the physical wall?",
    a: "Yes. We accept paintings, prints, photography, sculpture documentation, and mixed media. Works must be physical originals or limited editions (maximum 10 prints per edition). Digital-only works are listed in the catalogue but are not eligible for wall booking.",
  },
  {
    q: "How do I join the founding cohort?",
    a: "The founding cohort closed at 200 members in March 2025. If you missed it, you can apply to the general programme — founding cohort status may reopen in limited tranches for exceptional applicants. Join the waitlist and we will notify you.",
  },
]

export default function About() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  function toggleFaq(i: number) {
    setOpenIndex(prev => (prev === i ? null : i))
  }

  return (
    <PageShell>
      {/* Hero / Mission */}
      <section style={{ marginBottom: 96 }}>
        <div style={{ marginBottom: 24 }}>
          <Eyebrow chapter="02" label="About" />
        </div>
        <h1 style={{
          fontFamily: 'var(--font-heading)',
          fontSize: 'clamp(36px, 5vw, 64px)',
          fontWeight: 500,
          letterSpacing: '-0.03em',
          lineHeight: 1.1,
          color: t.ink,
          maxWidth: 720,
          marginBottom: 32,
        }}>
          Art belongs on walls, not in storage.
        </h1>
        <p style={{
          fontFamily: 'var(--font-sans)',
          fontSize: 18,
          lineHeight: 1.75,
          color: t.inkMuted,
          maxWidth: 640,
        }}>
          ArtWall Labs was founded on one observation: India has hundreds of thousands of practising
          artists, yet 85% of original works never find a buyer. Not because the art is inadequate
          — because the market has no infrastructure for discovery.
        </p>
      </section>

      <Hairline />

      {/* The Mark */}
      <section style={{ marginTop: 96, marginBottom: 96 }}>
        <SectionHeader chapter="—" eyebrow="Identity" title="The Mark" />

        <div style={{
          border: `1px solid ${t.hairline}`,
          borderRadius: 4,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: 48,
          marginBottom: 48,
        }}>
          <span style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 72,
            fontWeight: 500,
            letterSpacing: '-0.04em',
            lineHeight: 1,
            color: t.ink,
            display: 'block',
          }}>
            ArtWall
          </span>
          <span style={{
            fontFamily: 'var(--font-sans)',
            fontSize: 14,
            letterSpacing: '0.2em',
            textTransform: 'uppercase',
            color: t.inkMuted,
            display: 'block',
            marginTop: 8,
          }}>
            Labs
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48 }}>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, lineHeight: 1.7 }}>
            Founded 2024, Jaipur, Rajasthan.
          </p>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, lineHeight: 1.7 }}>
            Infrastructure for India's independent art market.
          </p>
        </div>
      </section>

      <Hairline />

      {/* Founding Story */}
      <section style={{ marginTop: 96, marginBottom: 96 }}>
        <SectionHeader chapter="—" eyebrow="Origin" title="Founding Story" />

        <div style={{ maxWidth: 680 }}>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 16, lineHeight: 1.8, color: t.ink, marginBottom: 28 }}>
            In 2024, the founders were visiting a chai stall near Jawahar Kala Kendra in Jaipur when
            a painting by local artist Ric Platter caught their eye — a 90cm × 120cm oil of Amber Fort
            at dawn, priced at ₹12,000, rolled in a plastic tube under the counter because there was
            nowhere to show it. That work had sat unsold for three years.
          </p>

          <blockquote style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 24,
            fontStyle: 'italic',
            fontWeight: 400,
            lineHeight: 1.45,
            color: t.signal,
            borderLeft: `3px solid ${t.signal}`,
            paddingLeft: 24,
            margin: '40px 0',
          }}>
            "The work was exceptional. The market was invisible."
          </blockquote>

          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 16, lineHeight: 1.8, color: t.ink }}>
            We built ArtWall to fix that — starting with physical walls in real venues, then a
            provenance layer that follows every work through its entire life.
          </p>
        </div>
      </section>

      <Hairline />

      {/* FAQ Accordion */}
      <section style={{ marginTop: 96 }}>
        <SectionHeader chapter="—" eyebrow="Questions" title="Frequently Asked" />

        <div style={{ maxWidth: 720 }}>
          {faqs.map((faq, i) => (
            <div key={i} style={{ borderBottom: `1px solid ${t.hairline}` }}>
              <button
                onClick={() => toggleFaq(i)}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '18px 0',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  textAlign: 'left',
                  gap: 16,
                }}
              >
                <span style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 14,
                  fontWeight: 600,
                  color: t.ink,
                  lineHeight: 1.5,
                }}>
                  {faq.q}
                </span>
                <span style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 12,
                  color: t.inkMuted,
                  flexShrink: 0,
                  transition: 'transform 0.2s',
                }}>
                  {openIndex === i ? '▲' : '▼'}
                </span>
              </button>
              {openIndex === i && (
                <div style={{ paddingBottom: 20 }}>
                  <p style={{
                    fontFamily: 'var(--font-sans)',
                    fontSize: 13,
                    lineHeight: 1.7,
                    color: t.inkMuted,
                    margin: 0,
                  }}>
                    {faq.a}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>
    </PageShell>
  )
}
