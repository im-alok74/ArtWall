import { Link } from 'react-router'
import { t } from '../components/tokens'
import { Btn } from '../components/ui'

export default function NotFound() {
  return (
    <div style={{ paddingTop: 160, textAlign: 'center' }}>
      <div
        style={{
          fontFamily: 'var(--font-heading)',
          fontSize: 'clamp(80px, 15vw, 180px)',
          fontWeight: 500,
          letterSpacing: '-0.04em',
          color: t.wallCharcoal,
          lineHeight: 1,
        }}
      >
        404
      </div>

      <p
        style={{
          fontFamily: 'var(--font-heading)',
          fontSize: 24,
          fontWeight: 500,
          color: t.ink,
          marginTop: 24,
          marginBottom: 0,
        }}
      >
        This page has left the building.
      </p>

      <p
        style={{
          fontFamily: 'var(--font-sans)',
          fontSize: 14,
          color: t.inkMuted,
          lineHeight: 1.7,
          maxWidth: 360,
          margin: '12px auto',
        }}
      >
        The work you are looking for may have been moved or is no longer available.
      </p>

      <div style={{ marginTop: 28 }}>
        <Link to="/">
          <Btn>Return to Home</Btn>
        </Link>
      </div>
    </div>
  )
}
