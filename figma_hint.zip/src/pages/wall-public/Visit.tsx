import { useState } from 'react'
import { t } from '../../components/tokens'
import { Eyebrow, Hairline, Btn, Field } from '../../components/ui'

function QRPlaceholder() {
  const cells = Array.from({ length: 100 })
  return (
    <div style={{
      width: 160, height: 160, display: 'grid', gridTemplateColumns: 'repeat(10, 1fr)',
      gap: 2, padding: 12, background: t.wallPaper, border: `1px solid ${t.hairline}`,
      borderRadius: 4, margin: '0 auto',
    }}>
      {cells.map((_, i) => (
        <div key={i} style={{
          background: Math.random() > 0.5 ? t.ink : 'transparent',
          borderRadius: 1,
        }} />
      ))}
    </div>
  )
}

export default function Visit() {
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [consentStore, setConsentStore] = useState(false)
  const [consentMarketing, setConsentMarketing] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!consentStore) return
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div style={{ background: t.wallPaper, minHeight: '100vh', paddingTop: 96, display: 'flex', alignItems: 'flex-start', justifyContent: 'center' }}>
        <div style={{ maxWidth: 480, width: '100%', padding: '48px 24px' }}>
          <div style={{ marginBottom: 24 }}>
            <Eyebrow chapter="Visit" label="Ric Platter" />
          </div>
          {/* Coupon card */}
          <div style={{
            border: `1px solid ${t.hairline}`, borderRadius: 4, overflow: 'hidden',
          }}>
            <div style={{ background: t.ink, padding: '24px 32px', textAlign: 'center' }}>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: 'rgba(255,255,255,0.5)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8 }}>
                Your coupon
              </div>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500, color: t.wallPaper, marginBottom: 4 }}>
                {name || 'Visitor'}
              </div>
            </div>
            <div style={{ background: t.wallPaper, padding: '32px', textAlign: 'center' }}>
              <QRPlaceholder />
              <div style={{ marginTop: 24, fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 500, color: t.ink, marginBottom: 8 }}>
                10% off your bill today at Ric Platter
              </div>
              <div style={{
                fontFamily: 'var(--font-sans)', fontSize: 18, fontWeight: 700,
                letterSpacing: '0.12em', color: t.ink, marginBottom: 8,
                background: t.band, padding: '8px 16px', borderRadius: 4, display: 'inline-block',
              }}>
                RIC-WALL-2847
              </div>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginBottom: 16 }}>
                Valid until midnight tonight
              </div>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted }}>
                Show this to staff at the counter.
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{ background: t.wallPaper, minHeight: '100vh', paddingTop: 96, display: 'flex', alignItems: 'flex-start', justifyContent: 'center' }}>
      <div style={{ maxWidth: 480, width: '100%', padding: '48px 24px' }}>
        <div style={{ marginBottom: 24 }}>
          <Eyebrow chapter="Visit" label="Ric Platter, Jaipur" />
        </div>
        <h1 style={{
          fontFamily: 'var(--font-heading)', fontSize: 'clamp(26px, 4vw, 36px)',
          fontWeight: 500, letterSpacing: '-0.025em', color: t.ink, marginBottom: 12,
        }}>
          Welcome to the ArtWall at Ric Platter
        </h1>
        <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, lineHeight: 1.7, marginBottom: 40 }}>
          Register to get your visitor coupon — redeemable at the counter for 10% off your bill.
        </p>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <div>
            <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>
              Name <span style={{ color: t.signal }}>*</span>
            </label>
            <input
              type="text" required value={name} onChange={e => setName(e.target.value)}
              placeholder="Your name"
              style={{
                width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14,
                color: t.ink, background: t.band, border: `1px solid ${t.hairline}`,
                borderRadius: 4, outline: 'none', boxSizing: 'border-box',
              }}
            />
          </div>
          <div>
            <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>
              Phone number <span style={{ color: t.signal }}>*</span>
            </label>
            <input
              type="tel" required value={phone} onChange={e => setPhone(e.target.value)}
              placeholder="+91 98765 43210"
              style={{
                width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14,
                color: t.ink, background: t.band, border: `1px solid ${t.hairline}`,
                borderRadius: 4, outline: 'none', boxSizing: 'border-box',
              }}
            />
          </div>

          <Hairline />

          <label style={{ display: 'flex', gap: 12, alignItems: 'flex-start', cursor: 'pointer' }}>
            <input
              type="checkbox" required checked={consentStore} onChange={e => setConsentStore(e.target.checked)}
              style={{ marginTop: 2, flexShrink: 0, accentColor: t.ink }}
            />
            <span style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, lineHeight: 1.6 }}>
              I consent to ArtWall Labs storing my visit data to issue my coupon. <span style={{ color: t.signal }}>*</span>
            </span>
          </label>

          <label style={{ display: 'flex', gap: 12, alignItems: 'flex-start', cursor: 'pointer' }}>
            <input
              type="checkbox" checked={consentMarketing} onChange={e => setConsentMarketing(e.target.checked)}
              style={{ marginTop: 2, flexShrink: 0, accentColor: t.ink }}
            />
            <span style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, lineHeight: 1.6 }}>
              I would like to receive updates about artists and exhibitions at ArtWall Labs. (Optional)
            </span>
          </label>

          <div style={{ paddingTop: 8 }}>
            <Btn type="submit" variant="primary" disabled={!consentStore}>Get my coupon</Btn>
          </div>
        </form>
      </div>
    </div>
  )
}
