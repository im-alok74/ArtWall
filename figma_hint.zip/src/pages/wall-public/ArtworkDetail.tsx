import { useState } from 'react'
import { Link, useParams } from 'react-router'
import { t } from '../../components/tokens'
import { Eyebrow, Hairline, Btn, Badge } from '../../components/ui'

const ARTWORK = {
  id: 'a1',
  photo: '1579783902614-a72e7b3e2b08',
  title: 'Monsoon Memory',
  artist: 'Priya Sharma',
  city: 'Jaipur',
  artistPhoto: '1580489944761-15a19d654956',
  medium: 'Oil on canvas',
  year: 2024,
  position: 'A3',
  dimensions: '60 × 80 cm',
  hangingSince: '14 Jan',
  until: '28 Jan',
  scanCount: 247,
  description: "Painted during the first week of monsoon in Jaipur, this work captures the particular quality of light that arrives just before heavy rain — diffuse, warm, and oddly still. Sharma worked in thin glazes over three weeks, allowing each layer to dry fully before the next. The result is a luminosity that shifts depending on the time of day you view it.",
  hearts: 43,
  saves: 28,
}

export default function ArtworkDetail() {
  const { id } = useParams()
  const [archived, setArchived] = useState(false)
  const [hearted, setHearted] = useState(false)
  const [saved, setSaved] = useState(false)

  return (
    <div style={{ background: t.wallPaper, minHeight: '100vh', paddingTop: 96 }}>
      {/* Dev toggle */}
      <div style={{ background: t.band, padding: '8px 16px', textAlign: 'center', borderBottom: `1px solid ${t.hairline}` }}>
        <button onClick={() => setArchived(a => !a)} style={{
          fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted,
          background: 'none', border: `1px solid ${t.hairline}`, borderRadius: 4,
          padding: '4px 12px', cursor: 'pointer',
        }}>Toggle: {archived ? 'Live view' : 'Archived view'}</button>
      </div>

      <div style={{ maxWidth: 720, margin: '0 auto', padding: '0 24px 80px' }}>
        {/* Image */}
        <div style={{ position: 'relative', marginBottom: 0 }}>
          <img
            src={`https://images.unsplash.com/photo-${ARTWORK.photo}?w=900&h=560&fit=crop&auto=format`}
            alt={ARTWORK.title}
            style={{
              width: '100%', aspectRatio: '16/10', objectFit: 'cover', display: 'block',
              filter: archived ? 'grayscale(100%)' : 'none',
              transition: 'filter 0.3s',
            }}
          />
          {archived && (
            <div style={{
              position: 'absolute', bottom: 0, left: 0, right: 0,
              background: 'rgba(12,15,29,0.85)',
              padding: '16px 24px',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <span style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.wallPaper, fontWeight: 500 }}>
                This work is no longer on the wall
              </span>
              <Badge label="Archived" />
            </div>
          )}
        </div>

        {archived && (
          <div style={{
            background: t.band, border: `1px solid ${t.hairline}`, borderTop: 'none',
            padding: '12px 20px', marginBottom: 32,
            fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted,
          }}>
            It was here from {ARTWORK.hangingSince} to {ARTWORK.until} ·{' '}
            <Link to={`/physical-wall/a/${id}`} style={{ color: t.signal, textDecoration: 'none' }}>View archived page</Link>
          </div>
        )}

        <div style={{ paddingTop: 36, paddingBottom: 36 }}>
          <div style={{ marginBottom: 8 }}>
            <Eyebrow chapter="Physical Wall" label={`Slot ${ARTWORK.position}`} />
          </div>
          <h1 style={{
            fontFamily: 'var(--font-heading)', fontSize: 'clamp(28px, 4vw, 44px)',
            fontWeight: 500, letterSpacing: '-0.025em', color: t.ink, marginBottom: 8,
          }}>{ARTWORK.title}</h1>
          <div style={{ fontFamily: 'var(--font-sans)', fontSize: 15, color: t.inkMuted, marginBottom: 32 }}>
            <Link to="/artist/priya-sharma" style={{ color: t.ink, fontWeight: 500, textDecoration: 'none' }}>{ARTWORK.artist}</Link>
            {' · '}{ARTWORK.medium}{' · '}{ARTWORK.year}
          </div>

          {/* Spec grid */}
          <div style={{
            display: 'grid', gridTemplateColumns: '1fr 1fr',
            gap: '1px', background: t.hairline, border: `1px solid ${t.hairline}`,
            borderRadius: 4, overflow: 'hidden', marginBottom: 32,
          }}>
            {[
              ['Position', `Slot ${ARTWORK.position}`],
              ['Medium', ARTWORK.medium],
              ['Year', String(ARTWORK.year)],
              ['Dimensions', ARTWORK.dimensions],
              ['Hanging since', ARTWORK.hangingSince],
              ['Until', ARTWORK.until],
              ['Scan count', String(ARTWORK.scanCount)],
              ['Category', 'Painting'],
            ].map(([label, value]) => (
              <div key={label} style={{ background: t.wallPaper, padding: '12px 16px' }}>
                <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted, marginBottom: 2, letterSpacing: '0.02em', textTransform: 'uppercase' }}>{label}</div>
                <div style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, fontWeight: 500 }}>{value}</div>
              </div>
            ))}
          </div>

          {/* Description */}
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 15, color: t.ink, lineHeight: 1.75, marginBottom: 36 }}>
            {ARTWORK.description}
          </p>

          {/* Reactions */}
          <div style={{ display: 'flex', gap: 12, marginBottom: 24 }}>
            <button onClick={() => setHearted(h => !h)} style={{
              display: 'flex', alignItems: 'center', gap: 6,
              fontFamily: 'var(--font-sans)', fontSize: 13,
              color: hearted ? '#dc2626' : t.inkMuted,
              background: 'none', border: `1px solid ${t.hairline}`,
              borderRadius: 4, padding: '8px 14px', cursor: 'pointer',
            }}>♥ {ARTWORK.hearts + (hearted ? 1 : 0)} Heart</button>
            <button onClick={() => setSaved(s => !s)} style={{
              display: 'flex', alignItems: 'center', gap: 6,
              fontFamily: 'var(--font-sans)', fontSize: 13,
              color: saved ? t.signal : t.inkMuted,
              background: 'none', border: `1px solid ${t.hairline}`,
              borderRadius: 4, padding: '8px 14px', cursor: 'pointer',
            }}>◎ {ARTWORK.saves + (saved ? 1 : 0)} Save</button>
            <button style={{
              display: 'flex', alignItems: 'center', gap: 6,
              fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted,
              background: 'none', border: `1px solid ${t.hairline}`,
              borderRadius: 4, padding: '8px 14px', cursor: 'pointer',
            }}>↗ Share</button>
          </div>

          <Btn variant="primary" href="/enquire">Enquire about this work</Btn>
        </div>

        <Hairline />

        {/* Artist card */}
        <div style={{ paddingTop: 32, display: 'flex', gap: 20, alignItems: 'center' }}>
          <img
            src={`https://images.unsplash.com/photo-${ARTWORK.artistPhoto}?w=120&h=120&fit=crop&auto=format`}
            alt={ARTWORK.artist}
            style={{ width: 64, height: 64, borderRadius: '50%', objectFit: 'cover', flexShrink: 0 }}
          />
          <div>
            <div style={{ fontFamily: 'var(--font-heading)', fontSize: 18, fontWeight: 500, color: t.ink, marginBottom: 2 }}>{ARTWORK.artist}</div>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 8 }}>{ARTWORK.city}</div>
            <Link to="/artist/priya-sharma" style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.signal, textDecoration: 'none', fontWeight: 500 }}>
              View profile →
            </Link>
          </div>
        </div>

        {/* Other works (archived state) */}
        {archived && (
          <div style={{ marginTop: 48 }}>
            <Hairline />
            <div style={{ marginTop: 40, marginBottom: 24 }}>
              <Eyebrow chapter="Discover" label="Other works you might like" />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              {[
                { photo: '1618005182384-a83a8bd57fbe', title: 'Urban Geometry', artist: 'Kiran Nair' },
                { photo: '1508193638397-1c4234db14d8', title: 'Still Life No. 7', artist: 'Anjali Mehta' },
              ].map(w => (
                <Link key={w.photo} to="/physical-wall/a/2" style={{ textDecoration: 'none' }}>
                  <img
                    src={`https://images.unsplash.com/photo-${w.photo}?w=400&h=280&fit=crop&auto=format`}
                    alt={w.title}
                    style={{ width: '100%', aspectRatio: '4/3', objectFit: 'cover', borderRadius: 4, display: 'block', marginBottom: 10 }}
                  />
                  <div style={{ fontFamily: 'var(--font-heading)', fontSize: 15, color: t.ink, fontWeight: 500 }}>{w.title}</div>
                  <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>{w.artist}</div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
