import { useState } from 'react'
import { Link, useParams } from 'react-router'
import { t } from '../../components/tokens'
import { Eyebrow, Btn } from '../../components/ui'

type FailState = 'invalid' | 'expired' | 'revoked'

const STATES: { key: FailState; eyebrow: string; heading: string; body: string }[] = [
  {
    key: 'invalid',
    eyebrow: 'Invalid code',
    heading: "This QR code isn't valid.",
    body: "The token may have been corrupted or this isn't an ArtWall code. Check the QR code you scanned and try again. If you scanned a code from an artwork card, contact the venue.",
  },
  {
    key: 'expired',
    eyebrow: 'Expired',
    heading: "This QR code has expired.",
    body: "The artwork associated with this code came down on 28 Jan 2025. The exhibition ended and the code is no longer active.",
  },
  {
    key: 'revoked',
    eyebrow: 'Revoked',
    heading: "This QR code has been revoked.",
    body: "This code has been deactivated by ArtWall Labs. If you believe this is an error, please contact us and we will look into it.",
  },
]

export default function QRFail() {
  const { token } = useParams()
  const [state, setState] = useState<FailState>('invalid')
  const current = STATES.find(s => s.key === state)!

  return (
    <div style={{ background: t.wallPaper, minHeight: '100vh', paddingTop: 96, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      {/* Dev toggle */}
      <div style={{ background: t.band, padding: '8px 16px', display: 'flex', gap: 8, borderBottom: `1px solid ${t.hairline}`, width: '100%', justifyContent: 'center' }}>
        {STATES.map(s => (
          <button key={s.key} onClick={() => setState(s.key)} style={{
            fontFamily: 'var(--font-sans)', fontSize: 11,
            background: state === s.key ? t.ink : 'none',
            color: state === s.key ? t.wallPaper : t.inkMuted,
            border: `1px solid ${t.hairline}`, borderRadius: 4,
            padding: '4px 12px', cursor: 'pointer',
          }}>{s.key}</button>
        ))}
      </div>

      <div style={{ maxWidth: 480, width: '100%', padding: '80px 24px', textAlign: 'center' }}>
        <div style={{ marginBottom: 24, display: 'flex', justifyContent: 'center' }}>
          <Eyebrow chapter="QR" label={current.eyebrow} />
        </div>

        {/* Large symbol */}
        <div style={{
          fontFamily: 'var(--font-heading)', fontSize: 80, fontWeight: 500,
          color: t.hairline, lineHeight: 1, marginBottom: 32,
        }}>
          {state === 'invalid' ? '?' : state === 'expired' ? '∅' : '⊘'}
        </div>

        <h1 style={{
          fontFamily: 'var(--font-heading)', fontSize: 'clamp(22px, 3vw, 32px)',
          fontWeight: 500, letterSpacing: '-0.02em', color: t.ink, marginBottom: 16,
        }}>
          {current.heading}
        </h1>

        <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, lineHeight: 1.75, marginBottom: 32 }}>
          {current.body}
        </p>

        {state === 'expired' && (
          <div style={{
            background: t.band, border: `1px solid ${t.hairline}`,
            borderRadius: 4, padding: '16px 20px', marginBottom: 32, textAlign: 'left',
          }}>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginBottom: 4 }}>Exhibition dates</div>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, fontWeight: 500 }}>14 Jan – 28 Jan 2025</div>
            <div style={{ marginTop: 12 }}>
              <Link to="/physical-wall/a/1" style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.signal, textDecoration: 'none' }}>
                View the archived artwork →
              </Link>
            </div>
          </div>
        )}

        {state === 'revoked' && (
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 24 }}>
            Contact ArtWall Labs at{' '}
            <a href="mailto:hello@artwallabs.in" style={{ color: t.signal, textDecoration: 'none' }}>hello@artwallabs.in</a>
            {' '}if you believe this is an error.
          </p>
        )}

        <div style={{ marginTop: 8 }}>
          <Link to="/physical-wall" style={{
            fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, textDecoration: 'none',
          }}>
            ← Go to the wall
          </Link>
        </div>

        {token && (
          <div style={{ marginTop: 40, fontFamily: 'var(--font-sans)', fontSize: 11, color: t.hairline }}>
            Token: {token}
          </div>
        )}
      </div>
    </div>
  )
}
