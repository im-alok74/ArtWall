import { useState } from 'react'
import { Link } from 'react-router'
import { t } from '../../components/tokens'
import { Eyebrow, Hairline, Btn, Badge } from '../../components/ui'

const ARTWORKS = [
  { id: 1, photo: '1579783902614-a72e7b3e2b08', title: 'Monsoon Memory', artist: 'Priya Sharma', medium: 'Oil on canvas', slot: 'A3', until: '28 Jan', category: 'Painting' },
  { id: 2, photo: '1618005182384-a83a8bd57fbe', title: 'Urban Geometry', artist: 'Kiran Nair', medium: 'Acrylic', slot: 'B1', until: '14 Feb', category: 'Painting' },
  { id: 3, photo: '1508193638397-1c4234db14d8', title: 'Still Life No. 7', artist: 'Anjali Mehta', medium: 'Watercolour', slot: 'C4', until: '20 Jan', category: 'Painting' },
  { id: 4, photo: '1549887534-1541e9ab5df7', title: 'Terra Fragment', artist: 'Ravi Gopal', medium: 'Terracotta sculpture', slot: 'D2', until: '5 Feb', category: 'Sculpture' },
  { id: 5, photo: '1572947650440-e8a97ef053b2', title: 'Blue Interval', artist: 'Sunita Rao', medium: 'Photography', slot: 'A6', until: '12 Feb', category: 'Photography' },
  { id: 6, photo: '1558618666-fcd25c85cd64', title: 'Market, Dusk', artist: 'Deepak Singh', medium: 'Photography', slot: 'B5', until: '19 Jan', category: 'Photography' },
  { id: 7, photo: '1531913764164-f85c52e6e654', title: 'Vessel III', artist: 'Meena Iyer', medium: 'Ceramic', slot: 'C2', until: '3 Feb', category: 'Sculpture' },
  { id: 8, photo: '1541961017774-22349e4a1262', title: 'Garden Sequence', artist: 'Aarav Patel', medium: 'Oil on linen', slot: 'D5', until: '25 Jan', category: 'Painting' },
]

type SlotState = 'available' | 'booked' | 'live' | 'maintenance'
const ROWS = ['A', 'B', 'C', 'D']
const COLS = [1, 2, 3, 4, 5, 6]
const SLOT_STATES: Record<string, SlotState> = {
  A1: 'live', A2: 'booked', A3: 'live', A4: 'available', A5: 'available', A6: 'live',
  B1: 'live', B2: 'available', B3: 'booked', B4: 'booked', B5: 'live', B6: 'available',
  C1: 'available', C2: 'live', C3: 'maintenance', C4: 'live', C5: 'available', C6: 'booked',
  D1: 'booked', D2: 'live', D3: 'available', D4: 'available', D5: 'live', D6: 'maintenance',
}

const FILTERS = ['All', 'Painting', 'Sculpture', 'Photography']

export default function PhysicalWall() {
  const [activeFilter, setActiveFilter] = useState('All')

  const filtered = activeFilter === 'All' ? ARTWORKS : ARTWORKS.filter(a => a.category === activeFilter)

  function slotStyle(state: SlotState): React.CSSProperties {
    if (state === 'booked') return { background: t.ink, color: t.wallPaper, border: `1px solid ${t.ink}` }
    if (state === 'live') return { background: t.wallPaper, color: t.ink, border: `1px solid ${t.hairline}` }
    if (state === 'maintenance') return { background: t.band, color: t.inkMuted, border: `1px solid ${t.hairline}` }
    return { background: t.wallPaper, color: t.inkMuted, border: `1px solid ${t.hairline}` }
  }

  return (
    <div style={{ background: t.wallPaper, minHeight: '100vh' }}>
      {/* Hero */}
      <div style={{ paddingTop: 96, padding: '96px 32px 80px', maxWidth: 1240, margin: '0 auto' }}>
        <div style={{ marginBottom: 24 }}>
          <Eyebrow chapter="Physical Wall" label="Ric Platter, Jaipur" />
        </div>
        <h1 style={{
          fontFamily: 'var(--font-heading)', fontSize: 'clamp(40px, 6vw, 80px)',
          fontWeight: 500, letterSpacing: '-0.03em', lineHeight: 1.05, color: t.ink,
          maxWidth: 640, marginBottom: 32,
        }}>
          Art you can stand in front of.
        </h1>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 40 }}>
          <span style={{
            width: 8, height: 8, borderRadius: '50%', background: '#22c55e',
            display: 'inline-block',
            boxShadow: '0 0 0 3px rgba(34,197,94,0.25)',
          }} />
          <span style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted }}>
            12 works hanging now
          </span>
        </div>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <Btn variant="primary" href="#hanging-now">See what&apos;s on the wall</Btn>
          <Btn variant="quiet" href="/physical-wall/book">Book a slot</Btn>
        </div>
      </div>

      <Hairline />

      {/* Hanging Now Rail */}
      <div id="hanging-now" style={{ padding: '64px 32px', maxWidth: 1240, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 32, flexWrap: 'wrap', gap: 16 }}>
          <div>
            <div style={{ marginBottom: 12 }}><Eyebrow chapter="Gallery" label="Hanging now" /></div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500, letterSpacing: '-0.02em', color: t.ink }}>
              On the wall today
            </h2>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {FILTERS.map(f => (
              <button key={f} onClick={() => setActiveFilter(f)} style={{
                fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500,
                padding: '6px 14px', borderRadius: 4,
                background: activeFilter === f ? t.ink : 'transparent',
                color: activeFilter === f ? t.wallPaper : t.inkMuted,
                border: `1px solid ${activeFilter === f ? t.ink : t.hairline}`,
                cursor: 'pointer', letterSpacing: '-0.01em',
              }}>{f}</button>
            ))}
          </div>
        </div>

        <div style={{
          display: 'flex', gap: 24, overflowX: 'auto', scrollSnapType: 'x mandatory',
          paddingBottom: 16,
        }}>
          {filtered.map(art => (
            <Link key={art.id} to={`/physical-wall/a/${art.id}`} style={{
              textDecoration: 'none', flexShrink: 0, width: 320,
              scrollSnapAlign: 'start', border: `1px solid ${t.hairline}`,
              borderRadius: 4, overflow: 'hidden', background: t.wallPaper,
            }}>
              <img
                src={`https://images.unsplash.com/photo-${art.photo}?w=600&h=400&fit=crop&auto=format`}
                alt={art.title}
                style={{ width: '100%', height: 200, objectFit: 'cover', display: 'block' }}
              />
              <div style={{ padding: 20 }}>
                <div style={{ fontFamily: 'var(--font-heading)', fontSize: 18, fontWeight: 500, color: t.ink, marginBottom: 4, letterSpacing: '-0.015em' }}>{art.title}</div>
                <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 12 }}>{art.artist} · {art.medium}</div>
                <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: t.signal, marginBottom: 8, letterSpacing: '0.02em' }}>
                  Position {art.slot} · Until {art.until}
                </div>
                <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted }}>Scan QR to learn more</div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <Hairline />

      {/* Wall Grid */}
      <div style={{ padding: '64px 32px', maxWidth: 1240, margin: '0 auto' }}>
        <div style={{ marginBottom: 12 }}><Eyebrow chapter="Layout" label="The physical wall" /></div>
        <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500, letterSpacing: '-0.02em', color: t.ink, marginBottom: 40 }}>
          Slot map
        </h2>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8, maxWidth: 720 }}>
          {ROWS.flatMap(row =>
            COLS.map(col => {
              const key = `${row}${col}`
              const state = SLOT_STATES[key]
              const isLive = state === 'live'
              return (
                <div
                  key={key}
                  onClick={isLive ? () => window.location.href = `/physical-wall/a/slot-${key.toLowerCase()}` : undefined}
                  style={{
                    ...slotStyle(state),
                    borderRadius: 4,
                    padding: '16px 8px',
                    textAlign: 'center',
                    cursor: isLive ? 'pointer' : 'default',
                    position: 'relative',
                  }}
                >
                  {isLive && (
                    <span style={{
                      position: 'absolute', top: 6, right: 6,
                      width: 6, height: 6, borderRadius: '50%',
                      background: t.signal, display: 'block',
                    }} />
                  )}
                  <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 600 }}>{key}</div>
                </div>
              )
            })
          )}
        </div>

        {/* Legend */}
        <div style={{ display: 'flex', gap: 24, marginTop: 28, flexWrap: 'wrap' }}>
          {[
            { state: 'available', label: 'Available' },
            { state: 'live', label: 'Live — click to view' },
            { state: 'booked', label: 'Booked' },
            { state: 'maintenance', label: 'Maintenance' },
          ].map(({ state, label }) => (
            <div key={state} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{
                ...slotStyle(state as SlotState),
                width: 20, height: 20, borderRadius: 4,
              }} />
              <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>{label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
