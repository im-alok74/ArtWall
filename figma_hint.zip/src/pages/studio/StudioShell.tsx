import { Link, useLocation, Outlet } from 'react-router'
import { t } from '../../components/tokens'

const NAV_ITEMS = [
  { icon: '◻', label: 'Overview', href: '/studio' },
  { icon: '◰', label: 'Artworks', href: '/studio/artworks' },
  { icon: '◫', label: 'Collections', href: '/studio/collections' },
  { icon: '⊟', label: 'Series', href: '/studio/series' },
  { icon: '⊞', label: 'Exhibitions', href: '/studio/exhibitions' },
  { icon: '◈', label: 'Rooms', href: '/studio/rooms' },
  { icon: '◉', label: 'Locations', href: '/studio/locations' },
  { icon: '▦', label: 'Calendar', href: '/studio/calendar' },
  { icon: '☑', label: 'Tasks', href: '/studio/tasks' },
  { icon: '◎', label: 'Contacts', href: '/studio/contacts' },
  { icon: '₹', label: 'Sales', href: '/studio/sales' },
  { icon: '⊡', label: 'Invoices', href: '/studio/invoices' },
  { icon: '◇', label: 'Payments', href: '/studio/payments' },
  { icon: '◳', label: 'Documents', href: '/studio/documents' },
  { icon: '⬡', label: 'Certificates', href: '/studio/certificates' },
  { icon: '◈', label: 'Provenance', href: '/studio/provenance' },
  { icon: '▦', label: 'Insights', href: '/studio/insights' },
  { icon: '◱', label: 'Reports', href: '/studio/reports' },
  { icon: '◌', label: 'Settings', href: '/studio/settings' },
]

const PAGE_TITLES: Record<string, string> = {
  '/studio': 'Overview',
  '/studio/artworks': 'Artworks',
  '/studio/artworks/new': 'New Artwork',
  '/studio/collections': 'Collections',
  '/studio/series': 'Series',
  '/studio/exhibitions': 'Exhibitions',
  '/studio/rooms': 'Rooms',
  '/studio/locations': 'Locations',
  '/studio/calendar': 'Calendar',
  '/studio/tasks': 'Tasks',
  '/studio/contacts': 'Contacts',
  '/studio/sales': 'Sales',
  '/studio/invoices': 'Invoices',
  '/studio/payments': 'Payments',
  '/studio/documents': 'Documents',
  '/studio/certificates': 'Certificates',
  '/studio/provenance': 'Provenance',
  '/studio/insights': 'Insights',
  '/studio/reports': 'Reports',
  '/studio/settings': 'Settings',
}

function NavItem({ icon, label, href, active }: { icon: string; label: string; href: string; active: boolean }) {
  return (
    <Link
      to={href}
      style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '8px 16px', borderRadius: 4, textDecoration: 'none',
        background: active ? t.ink : 'transparent',
        color: active ? t.wallPaper : t.inkMuted,
        fontSize: 13, fontFamily: 'var(--font-sans)', fontWeight: active ? 500 : 400,
        transition: 'background 0.12s, color 0.12s',
      }}
      onMouseEnter={e => { if (!active) { (e.currentTarget as HTMLElement).style.background = t.band; (e.currentTarget as HTMLElement).style.color = t.ink } }}
      onMouseLeave={e => { if (!active) { (e.currentTarget as HTMLElement).style.background = 'transparent'; (e.currentTarget as HTMLElement).style.color = t.inkMuted } }}
    >
      <span style={{ fontSize: 14, lineHeight: 1, flexShrink: 0, width: 16, textAlign: 'center' }}>{icon}</span>
      <span>{label}</span>
    </Link>
  )
}

export default function StudioShell() {
  const location = useLocation()
  const currentPath = location.pathname
  const pageTitle = PAGE_TITLES[currentPath] ?? 'Studio'

  // Breadcrumb
  const parts = currentPath.replace(/^\//, '').split('/')
  const breadcrumb = parts.map((p, i) => ({
    label: p.charAt(0).toUpperCase() + p.slice(1).replace(/-/g, ' '),
    href: '/' + parts.slice(0, i + 1).join('/'),
  }))

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: t.band, fontFamily: 'var(--font-sans)' }}>
      {/* Sidebar */}
      <div style={{
        width: 220, flexShrink: 0, background: t.wallPaper,
        borderRight: `1px solid ${t.hairline}`,
        display: 'flex', flexDirection: 'column',
        position: 'fixed', top: 0, left: 0, bottom: 0, zIndex: 40, overflowY: 'auto',
      }}>
        {/* Logo */}
        <div style={{ padding: '20px 16px 16px', borderBottom: `1px solid ${t.hairline}` }}>
          <Link to="/" style={{ textDecoration: 'none' }}>
            <span style={{
              fontFamily: 'var(--font-heading)', fontSize: 18, fontWeight: 500,
              color: t.ink, letterSpacing: '-0.02em',
            }}>ArtWall</span>
          </Link>
          <div style={{ marginTop: 4 }}>
            <span style={{ fontSize: 11, color: t.inkMuted, letterSpacing: '0.04em' }}>Studio</span>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: '12px 8px', display: 'flex', flexDirection: 'column', gap: 2 }}>
          {NAV_ITEMS.map(item => (
            <NavItem
              key={item.href}
              {...item}
              active={item.href === '/studio' ? currentPath === '/studio' : currentPath.startsWith(item.href)}
            />
          ))}
        </nav>

        {/* Back to site */}
        <div style={{ padding: '12px 16px', borderTop: `1px solid ${t.hairline}` }}>
          <Link to="/" style={{
            fontSize: 12, color: t.inkMuted, textDecoration: 'none',
            display: 'flex', alignItems: 'center', gap: 6,
          }}>
            <span>←</span>
            <span>Back to site</span>
          </Link>
        </div>
      </div>

      {/* Main */}
      <div style={{ flex: 1, marginLeft: 220, display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
        {/* Header */}
        <header style={{
          position: 'fixed', top: 0, left: 220, right: 0, height: 56, zIndex: 30,
          background: t.wallPaper, borderBottom: `1px solid ${t.hairline}`,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 32px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            {breadcrumb.map((crumb, i) => (
              <span key={crumb.href} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                {i > 0 && <span style={{ color: t.hairlineStrong, fontSize: 12 }}>/</span>}
                <Link
                  to={crumb.href}
                  style={{
                    fontSize: 13, color: i === breadcrumb.length - 1 ? t.ink : t.inkMuted,
                    textDecoration: 'none', fontWeight: i === breadcrumb.length - 1 ? 500 : 400,
                  }}
                >
                  {crumb.label}
                </Link>
              </span>
            ))}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <Link to="/studio/artworks/new" style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '7px 14px', background: t.ink, color: t.wallPaper,
              borderRadius: 4, fontSize: 12, fontWeight: 500, textDecoration: 'none',
              border: `1px solid ${t.ink}`,
            }}>
              + Add new
            </Link>
            <div style={{
              width: 32, height: 32, borderRadius: '50%', background: t.footer,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer',
            }}>
              <span style={{ fontSize: 12, fontWeight: 600, color: t.wallPaper }}>PK</span>
            </div>
          </div>
        </header>

        {/* Content */}
        <main style={{ flex: 1, marginTop: 56, padding: '32px', minHeight: 0 }}>
          <Outlet />
        </main>
      </div>
    </div>
  )
}
