import { useState, useRef } from 'react'
import { t } from '../../components/tokens'
import { Btn, Hairline } from '../../components/ui'

function Field({
  label, id, required, hint, children,
}: {
  label: string; id?: string; required?: boolean; hint?: string; children: React.ReactNode;
}) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <label htmlFor={id} style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, letterSpacing: '-0.01em' }}>
        {label}{required && <span style={{ color: t.signal, marginLeft: 2 }}>*</span>}
      </label>
      {children}
      {hint && <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>{hint}</span>}
    </div>
  )
}

const inputStyle: React.CSSProperties = {
  width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14,
  color: '#0c0f1d', background: '#f7f9fb', border: '1px solid #cbd5e1',
  borderRadius: 4, outline: 'none',
}

const selectStyle: React.CSSProperties = { ...inputStyle, cursor: 'pointer' }

export default function ArtworkNew() {
  const [form, setForm] = useState({
    title: '',
    year: new Date().getFullYear().toString(),
    medium: '',
    width: '',
    height: '',
    depth: '',
    edition: 'unique',
    editionNumber: '',
    editionTotal: '',
    description: '',
    price: '',
    series: '',
    collection: '',
    tags: '',
  })
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [dragging, setDragging] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  const handleFile = (file: File) => {
    const url = URL.createObjectURL(file)
    setImagePreview(url)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragging(false)
    const file = e.dataTransfer.files[0]
    if (file && file.type.startsWith('image/')) handleFile(file)
  }

  const statusBadge = form.title || form.medium
    ? { label: 'Draft', bg: '#f0f9ff', color: '#0369a1' }
    : null

  return (
    <div style={{ maxWidth: 1040 }}>
      <div style={{ marginBottom: 28 }}>
        <h1 style={{
          fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 500,
          color: t.ink, letterSpacing: '-0.025em',
        }}>New artwork</h1>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 32, alignItems: 'flex-start' }}>
        {/* Form */}
        <form onSubmit={e => e.preventDefault()} style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, padding: '28px 28px', display: 'flex', flexDirection: 'column', gap: 20 }}>

            <Field label="Title" id="title" required>
              <input id="title" value={form.title} onChange={set('title')} placeholder="e.g. Monsoon Study No. 5" style={inputStyle} />
            </Field>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <Field label="Year" id="year" required>
                <input id="year" type="number" value={form.year} onChange={set('year')} style={inputStyle} />
              </Field>
              <Field label="Medium" id="medium" required>
                <select id="medium" value={form.medium} onChange={set('medium')} style={selectStyle}>
                  <option value="">Select medium</option>
                  <option>Painting</option>
                  <option>Drawing</option>
                  <option>Sculpture</option>
                  <option>Photography</option>
                  <option>Mixed media</option>
                  <option>Printmaking</option>
                  <option>Digital</option>
                  <option>Textile</option>
                  <option>Other</option>
                </select>
              </Field>
            </div>

            <Field label="Dimensions (cm)" hint="Width × Height × Depth. Leave Depth blank for flat works.">
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <input value={form.width} onChange={set('width')} placeholder="W" style={{ ...inputStyle, width: 90 }} />
                <span style={{ color: t.inkMuted, fontSize: 14 }}>×</span>
                <input value={form.height} onChange={set('height')} placeholder="H" style={{ ...inputStyle, width: 90 }} />
                <span style={{ color: t.inkMuted, fontSize: 14 }}>×</span>
                <input value={form.depth} onChange={set('depth')} placeholder="D" style={{ ...inputStyle, width: 90 }} />
              </div>
            </Field>

            <Field label="Edition" id="edition">
              <select id="edition" value={form.edition} onChange={set('edition')} style={selectStyle}>
                <option value="unique">Unique</option>
                <option value="limited">Limited edition</option>
              </select>
            </Field>

            {form.edition === 'limited' && (
              <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                <Field label="Edition number" id="edNum">
                  <input id="edNum" type="number" value={form.editionNumber} onChange={set('editionNumber')} placeholder="e.g. 3" style={{ ...inputStyle, width: 120 }} />
                </Field>
                <span style={{ color: t.inkMuted, fontSize: 16, marginTop: 22 }}>/</span>
                <Field label="Total in edition" id="edTotal">
                  <input id="edTotal" type="number" value={form.editionTotal} onChange={set('editionTotal')} placeholder="e.g. 10" style={{ ...inputStyle, width: 120 }} />
                </Field>
              </div>
            )}

            <Field label="Description">
              <textarea
                value={form.description}
                onChange={set('description')}
                placeholder="Describe the work — materials, process, intent, context."
                rows={4}
                style={{ ...inputStyle, resize: 'vertical' }}
              />
            </Field>

            <Field label="Price (₹)" id="price" required>
              <div style={{ position: 'relative' }}>
                <span style={{
                  position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)',
                  fontSize: 14, color: t.inkMuted, fontFamily: 'var(--font-sans)',
                }}>₹</span>
                <input id="price" type="number" value={form.price} onChange={set('price')}
                  placeholder="0"
                  style={{ ...inputStyle, paddingLeft: 26 }}
                />
              </div>
            </Field>

            <Hairline />

            {/* Image upload */}
            <Field label="Artwork image">
              <div
                onClick={() => fileRef.current?.click()}
                onDragOver={e => { e.preventDefault(); setDragging(true) }}
                onDragLeave={() => setDragging(false)}
                onDrop={handleDrop}
                style={{
                  border: `1.5px dashed ${dragging ? t.ink : t.hairlineStrong}`,
                  borderRadius: 4, padding: imagePreview ? 0 : '32px 24px',
                  textAlign: 'center', cursor: 'pointer', background: dragging ? t.band : 'transparent',
                  transition: 'border-color 0.15s, background 0.15s', overflow: 'hidden',
                }}
              >
                {imagePreview ? (
                  <img src={imagePreview} alt="Preview" style={{ width: '100%', maxHeight: 240, objectFit: 'cover', display: 'block' }} />
                ) : (
                  <>
                    <p style={{ fontSize: 13, fontWeight: 500, color: t.ink, marginBottom: 6 }}>
                      Drag image here or click to browse
                    </p>
                    <p style={{ fontSize: 12, color: t.inkMuted }}>
                      JPG, PNG, TIFF up to 50 MB. Use the highest resolution available.
                    </p>
                  </>
                )}
              </div>
              <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }}
                onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f) }}
              />
            </Field>

            <Hairline />

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <Field label="Series" hint="Optional">
                <input value={form.series} onChange={set('series')} placeholder="e.g. Monsoon Studies" style={inputStyle} />
              </Field>
              <Field label="Collection" hint="Optional">
                <input value={form.collection} onChange={set('collection')} placeholder="e.g. Personal archive" style={inputStyle} />
              </Field>
            </div>

            <Field label="Tags" hint="Optional. Comma-separated: e.g. watercolour, coastal, 2024">
              <input value={form.tags} onChange={set('tags')} placeholder="watercolour, coastal, 2024" style={inputStyle} />
            </Field>
          </div>

          <div style={{ display: 'flex', gap: 12, marginTop: 20 }}>
            <Btn type="submit" variant="primary">Save artwork</Btn>
            <Btn type="button" variant="quiet">Save as draft</Btn>
          </div>
        </form>

        {/* Preview card */}
        <div style={{ position: 'sticky', top: 88 }}>
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: t.inkMuted, marginBottom: 12 }}>
            Preview
          </p>
          <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, overflow: 'hidden' }}>
            <div style={{ aspectRatio: '4/3', background: t.band, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
              {imagePreview ? (
                <img src={imagePreview} alt="Preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <span style={{ fontSize: 32, opacity: 0.2 }}>◰</span>
              )}
            </div>
            <div style={{ padding: '16px 18px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
                <p style={{ fontSize: 14, fontWeight: 500, color: t.ink, lineHeight: 1.3 }}>
                  {form.title || <span style={{ color: t.inkMuted, fontWeight: 400, fontStyle: 'italic' }}>Untitled</span>}
                </p>
                {statusBadge && (
                  <span style={{
                    fontSize: 11, fontWeight: 600, padding: '2px 7px', borderRadius: 2,
                    background: statusBadge.bg, color: statusBadge.color, flexShrink: 0, marginLeft: 8,
                  }}>{statusBadge.label}</span>
                )}
              </div>
              <p style={{ fontSize: 12, color: t.inkMuted, marginBottom: 10 }}>
                {[form.medium || 'Medium', form.year].filter(Boolean).join(' · ')}
                {(form.width && form.height) && ` · ${form.width} × ${form.height}${form.depth ? ' × ' + form.depth : ''} cm`}
              </p>
              {form.edition === 'limited' && form.editionNumber && form.editionTotal && (
                <p style={{ fontSize: 12, color: t.inkMuted, marginBottom: 10 }}>
                  {`Edition ${form.editionNumber} of ${form.editionTotal}`}
                </p>
              )}
              {form.price && (
                <div style={{ borderTop: `1px solid ${t.hairline}`, paddingTop: 10 }}>
                  <p style={{ fontSize: 13, fontWeight: 500, color: t.ink }}>₹{Number(form.price).toLocaleString('en-IN')}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
