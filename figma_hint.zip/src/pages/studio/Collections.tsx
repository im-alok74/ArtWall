import { StudioEmptyState } from './StudioEmpty'

export default function Collections() {
  return (
    <StudioEmptyState
      icon="◫"
      title={"No collections yet."}
      body={"Collections group your artworks by theme, series, or any logic that works for you. Once you have at least two artworks, create your first collection here."}
      ctaLabel="Create collection"
      ctaHref="/studio/collections/new"
    />
  )
}
