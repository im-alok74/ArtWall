import { StudioEmptyState } from './StudioEmpty'

export default function Sales() {
  return (
    <StudioEmptyState
      icon="₹"
      title={"No sales recorded yet."}
      body={"When you sell an artwork, record it here. Sales appear in your year-end reports, link to certificates of authenticity, and feed into your provenance history."}
      ctaLabel="Record a sale"
      ctaHref="/studio/sales/new"
    />
  )
}
