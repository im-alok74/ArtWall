import { useState } from 'react'
import { Link } from 'react-router'
import { t } from '../../components/tokens'
import { Btn } from '../../components/ui'

type Filter = 'All' | 'Painting' | 'Sculpture' | 'Photography'

const ARTWORKS = [
  { id: 1, title: 'Monsoon Study No. 4', medium: 'Oil on canvas', year: 2024, status: 'On wall', price: '₹32,000', photo: 'photo-1578662996442-48f60103fc96' },
  { id: 2, title: 'Red Geometry Series No. 7', medium: 'Acrylic on paper', year: 2023, status: 'Available', price: '₹18,500', photo: 'photo-1541961017774-22349e4a1262' },
  { id: 3, title: 'Tidal Pull No. 2', medium: 'Mixed media', year: 2023, status: 'Sold', price: '₹18,000', photo: 'photo-1579783902614-a3fb3927b6a5' },
  { id: 4, title: 'Summer Meridian', medium: 'Oil on canvas', year: 2024, status: 'Available', price: '₹45,000', photo: 'photo-1549887534-1541e9326688' },
  { id: 5, title: 'Salt Flat Study', medium: 'Photography', year: 2022, status: 'Available', price: '₹12,000', photo: 'photo-1506905925346-21bda4d32df4' },
  { id: 6, title: 'Untitled (Ochre)', medium: 'Oil on canvas', year: 2024, status: 'Available', price: '₹28,000', photo: 'photo-1565073624497-7144969d5c8c' },
  { id: 7, title: 'Marble Fragment I', medium: 'Sculpture', year: 2021, status: 'Sold', price: '₹95,000', photo: 'photo-1561214115-f2f134cc4912' },
  { id: 8, title: 'Hill Station (Monsoon)', medium: 'Photography', year: 2023, status: 'Available', price: '₹9,500', photo: 'photo-1470770841072-f978cf4d019e' },
  { id: 9, title: 'Weave Study No. 3', medium: 'Textile', year: 2024, status: 'Available', price: '₹22,000', photo: 'photo-1558769132-cb1aea458c5e' },
]

const STATUS_COLORS: Record<string, { bg: string; color: string }> = {
  'Available': { bg: '#f0fdf4', color: '#166534' },
  'Sold': { bg: '#fef2f2', color: '#991b1b' },
  'On wall': { bg: '#eff6ff', color: '#1d4ed8' },
}

export default function Artworks() {
  const [filter, setFilter] = useState<Filter>('All')
  const [search, setSearch] = useState('')

  const filtered = ARTWORKS.filter(a => {
    const matchesFilter = filter === 'All' || a.medium.toLowerCase().includes(filter.toLowerCase())
    const matchesSearch = a.title.toLowerCase().includes(search.toLowerCase()) || a.medium.toLowerCase().includes(search.toLowerCase())
    return matchesFilter && matchesSearch
  })

  return (
    <div style={{ maxWidth: 1100 }}>
      {/* Top bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24, flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
          <h1 style={{
            fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 500,
            color: t.ink, letterSpacing: '-0.025em',
          }}>Artworks</h1>
          <span style={{ fontSize: 13, color: t.inkMuted }}>{filtered.length}</span>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
          {/* Search */}
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search artworks…"
            style={{
              padding: '8px 12px', fontFamily: 'var(--font-sans)', fontSize: 13,
              color: t.ink, background: t.wallPaper, border: `1px solid ${t.hairlineStrong}`,
              borderRadius: 4, outline: 'none', width: 200,
            }}
          />
          {/* Filter tabs */}
          <div style={{ display: 'flex', border: `1px solid ${t.hairlineStrong}`, borderRadius: 4, overflow: 'hidden' }}>
            {(['All', 'Painting', 'Sculpture', 'Photography'] as Filter[]).map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                style={{
                  padding: '7px 14px', fontSize: 12, fontWeight: filter === f ? 600 : 400,
                  background: filter === f ? t.ink : t.wallPaper,
                  color: filter === f ? t.wallPaper : t.inkMuted,
                  border: 'none', borderLeft: f !== 'All' ? `1px solid ${t.hairlineStrong}` : 'none',
                  cursor: 'pointer', fontFamily: 'var(--font-sans)', transition: 'background 0.12s',
                }}
              >
                {f}
              </button>
            ))}
          </div>
          <Link to="/studio/artworks/new" style={{ textDecoration: 'none' }}>
            <Btn variant="primary">+ Add artwork</Btn>
          </Link>
        </div>
      </div>

      {/* Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, marginBottom: 32 }}>
        {filtered.map(artwork => {
          const sc = STATUS_COLORS[artwork.status] ?? { bg: t.band, color: t.inkMuted }
          return (
            <div key={artwork.id} style={{
              background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, overflow: 'hidden',
              cursor: 'pointer',
            }}>
              <div style={{ aspectRatio: '4/3', overflow: 'hidden', background: t.band }}>
                <img
                  src={`https://images.unsplash.com/${artwork.photo}?w=500&h=400&fit=crop&auto=format`}
                  alt={artwork.title}
                  style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
                />
              </div>
              <div style={{ padding: '14px 16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
                  <p style={{ fontSize: 13, fontWeight: 500, color: t.ink, lineHeight: 1.3 }}>{artwork.title}</p>
                  <span style={{
                    fontSize: 11, fontWeight: 600, letterSpacing: '0.04em',
                    padding: '2px 7px', borderRadius: 2, flexShrink: 0, marginLeft: 8,
                    background: sc.bg, color: sc.color,
                  }}>{artwork.status}</span>
                </div>
                <p style={{ fontSize: 12, color: t.inkMuted, marginBottom: 10 }}>
                  {artwork.medium} · {artwork.year}
                </p>
                <div style={{ borderTop: `1px solid ${t.hairline}`, paddingTop: 10 }}>
                  <p style={{ fontSize: 13, fontWeight: 500, color: t.ink }}>{artwork.price}</p>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Pagination */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 4 }}>
        {[1, 2, 3, 4].map(p => (
          <button
            key={p}
            style={{
              width: 32, height: 32, borderRadius: 4, border: `1px solid ${p === 1 ? t.ink : t.hairlineStrong}`,
              background: p === 1 ? t.ink : 'transparent', color: p === 1 ? t.wallPaper : t.inkMuted,
              fontSize: 13, cursor: 'pointer', fontFamily: 'var(--font-sans)',
            }}
          >
            {p}
          </button>
        ))}
      </div>
    </div>
  )
}
