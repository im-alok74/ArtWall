import { t } from '../../components/tokens'
import { Hairline } from '../../components/ui'

const METRICS = [
  { label: 'Artworks', value: '34', sub: '3 added this month' },
  { label: 'Active bookings', value: '2', sub: 'Next: Slot A3, 14 Jan' },
  { label: 'Certificates issued', value: '28', sub: '2 this week' },
  { label: 'Sales this year', value: '₹1,24,000', sub: '↑ 18% vs last year' },
]

const ACTIVITY = [
  { icon: '⬡', text: 'Certificate issued for Monsoon Study No. 4', time: '2h ago' },
  { icon: '◰', text: 'Artwork added: Summer Meridian (Oil on canvas)', time: '6h ago' },
  { icon: '▦', text: 'Wall slot A3 booking confirmed · 14 Jan – 28 Jan', time: '1d ago' },
  { icon: '₹', text: 'Sale recorded for Tidal Pull No. 2 · ₹18,000', time: '2d ago' },
  { icon: '◰', text: 'Artwork updated: Red Geometry Series No. 7', time: '3d ago' },
]

const QUICK_ACTIONS = [
  { label: 'Add artwork', href: '/studio/artworks/new', icon: '+' },
  { label: 'Book wall slot', href: '/studio/calendar', icon: '▦' },
  { label: 'Issue certificate', href: '/studio/certificates', icon: '⬡' },
]

export default function StudioOverview() {
  const now = new Date()
  const hour = now.getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'
  const dateStr = now.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })

  return (
    <div style={{ maxWidth: 1000 }}>
      {/* Greeting */}
      <div style={{ marginBottom: 36 }}>
        <h1 style={{
          fontFamily: 'var(--font-heading)', fontSize: 'clamp(24px, 2.5vw, 32px)',
          fontWeight: 500, color: t.ink, letterSpacing: '-0.025em', marginBottom: 6,
        }}>
          {greeting}, Priya.
        </h1>
        <p style={{ fontSize: 13, color: t.inkMuted }}>{dateStr}</p>
      </div>

      {/* Metric cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 32 }}>
        {METRICS.map(m => (
          <div key={m.label} style={{
            background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, padding: '20px 24px',
          }}>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: t.inkMuted, marginBottom: 10 }}>
              {m.label}
            </p>
            <p style={{ fontFamily: 'var(--font-heading)', fontSize: 32, fontWeight: 500, color: t.ink, letterSpacing: '-0.03em', marginBottom: 6 }}>
              {m.value}
            </p>
            <p style={{ fontSize: 12, color: t.inkMuted }}>{m.sub}</p>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 36 }}>
        {QUICK_ACTIONS.map(a => (
          <a key={a.label} href={a.href} style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            padding: '10px 18px', background: t.wallPaper,
            border: `1px solid ${t.hairlineStrong}`, borderRadius: 4,
            fontSize: 13, fontWeight: 500, color: t.ink, textDecoration: 'none',
            fontFamily: 'var(--font-sans)',
          }}>
            <span style={{ fontSize: 14 }}>{a.icon}</span>
            {a.label}
          </a>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 24 }}>
        {/* Activity feed */}
        <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4 }}>
          <div style={{ padding: '16px 24px', borderBottom: `1px solid ${t.hairline}` }}>
            <h2 style={{ fontSize: 13, fontWeight: 600, color: t.ink }}>Recent activity</h2>
          </div>
          <div>
            {ACTIVITY.map((item, i) => (
              <div key={i}>
                <div style={{ display: 'flex', gap: 14, padding: '14px 24px', alignItems: 'center' }}>
                  <span style={{ fontSize: 15, color: t.inkMuted, flexShrink: 0 }}>{item.icon}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: 13, color: t.ink, lineHeight: 1.4 }}>{item.text}</p>
                  </div>
                  <span style={{ fontSize: 12, color: t.inkMuted, flexShrink: 0 }}>{item.time}</span>
                </div>
                {i < ACTIVITY.length - 1 && <Hairline />}
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming wall slot */}
        <div>
          <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4 }}>
            <div style={{ padding: '16px 24px', borderBottom: `1px solid ${t.hairline}` }}>
              <h2 style={{ fontSize: 13, fontWeight: 600, color: t.ink }}>Upcoming wall slot</h2>
            </div>
            <div style={{ padding: '20px 24px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
                <div>
                  <p style={{
                    fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 500,
                    color: t.ink, letterSpacing: '-0.02em', marginBottom: 4,
                  }}>Slot A3</p>
                  <p style={{ fontSize: 13, color: t.inkMuted }}>ArtWall Bandra East</p>
                </div>
                <span style={{
                  display: 'inline-block', fontSize: 11, fontWeight: 600, letterSpacing: '0.06em',
                  textTransform: 'uppercase', padding: '3px 8px', borderRadius: 2,
                  background: '#dcfce7', color: '#166534',
                }}>Confirmed</span>
              </div>
              <Hairline />
              <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 12, color: t.inkMuted }}>Duration</span>
                  <span style={{ fontSize: 13, fontWeight: 500, color: t.ink }}>14 Jan – 28 Jan 2025</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 12, color: t.inkMuted }}>Slot size</span>
                  <span style={{ fontSize: 13, fontWeight: 500, color: t.ink }}>1.2m × 0.9m</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 12, color: t.inkMuted }}>Amount paid</span>
                  <span style={{ fontSize: 13, fontWeight: 500, color: t.ink }}>₹4,500</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 12, color: t.inkMuted }}>Artwork assigned</span>
                  <span style={{ fontSize: 13, fontWeight: 500, color: t.ink }}>Monsoon Study No. 4</span>
                </div>
              </div>
              <div style={{ marginTop: 20 }}>
                <a href="/studio/calendar" style={{
                  fontSize: 13, color: t.ink, textDecoration: 'underline', fontFamily: 'var(--font-sans)',
                }}>
                  View all bookings →
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
