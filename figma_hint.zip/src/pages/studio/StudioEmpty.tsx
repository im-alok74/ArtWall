import { t } from '../../components/tokens'
import { Btn } from '../../components/ui'

export interface EmptyStateProps {
  icon: string
  title: string
  body: string
  ctaLabel: string
  ctaHref: string
}

export function StudioEmptyState({ icon, title, body, ctaLabel, ctaHref }: EmptyStateProps) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      minHeight: 'calc(100vh - 56px - 64px)',
      padding: '48px 24px',
    }}>
      <div style={{
        border: `1px solid ${t.hairline}`, borderRadius: 4, padding: '48px 40px',
        textAlign: 'center', maxWidth: 440, width: '100%', background: t.wallPaper,
      }}>
        <div style={{
          fontFamily: 'var(--font-heading)', fontSize: 56, fontWeight: 500,
          color: t.hairlineStrong, lineHeight: 1, marginBottom: 24,
        }}>
          {icon}
        </div>
        <h2 style={{
          fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 500,
          color: t.ink, letterSpacing: '-0.02em', marginBottom: 12,
        }}>
          {title}
        </h2>
        <p style={{
          fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted,
          lineHeight: 1.65, marginBottom: 28,
        }}>
          {body}
        </p>
        <Btn href={ctaHref} variant="primary">{ctaLabel}</Btn>
      </div>
    </div>
  )
}

export default StudioEmptyState
