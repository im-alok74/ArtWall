import { Link, useParams } from 'react-router'
import { t } from '../components/tokens'
import { Hairline, Badge, PageShell, Btn } from '../components/ui'

const ARTISTS = [
  { name: "Priya Mehta", handle: "priya-mehta", city: "Jaipur", medium: "Painting", artworks: 23, founding: true, photo: "1486413869840-a99ac0a4c031", bio: "Priya Mehta works from her studio in Jaipur, where the textures of Rajasthani architecture inform every canvas. Her painting practice spans intimate domestic scenes and sweeping large-scale landscapes. She joined ArtWall as a founding member in 2024." },
  { name: "Arjun Nair", handle: "arjun-nair", city: "Kochi", medium: "Photography", artworks: 41, founding: true, photo: "1614244139209-53c071a4737d", bio: "Arjun Nair is a documentary photographer based in Kochi whose work traces the coastline communities of Kerala through light and tide. His long-format series have been exhibited across South Asia. He is a founding member of ArtWall and one of its most-collected photographers." },
  { name: "Sunita Rao", handle: "sunita-rao", city: "Bengaluru", medium: "Sculpture", artworks: 9, founding: false, photo: "1613353948391-9822c7407534", bio: "Sunita Rao creates sculptural work from reclaimed metal and organic matter gathered around her Bengaluru studio. Her practice interrogates the boundary between industrial waste and natural form. Each piece is a singular object; she does not edition." },
  { name: "Dev Kapoor", handle: "dev-kapoor", city: "Delhi", medium: "Painting", artworks: 17, founding: true, photo: "1627890458144-4c0c481bf4b8", bio: "Dev Kapoor paints from Delhi, drawing on the city's layered visual culture — Mughal geometry, modernist housing blocks, and the kinetics of street life. His large canvases are built up in slow, deliberate layers of oil. He joined ArtWall at founding and has shown work at art fairs in Delhi and Mumbai." },
  { name: "Meera Krishnan", handle: "meera-krishnan", city: "Chennai", medium: "Mixed Media", artworks: 12, founding: false, photo: "1615065137920-bef75ea862b7", bio: "Meera Krishnan works across mixed media, weaving together hand-printed textile, collage, and painted surface in her Chennai studio. Her pieces often reference classical Carnatic visual codes reinterpreted through a contemporary lens. She joined ArtWall in 2025." },
  { name: "Ravi Sharma", handle: "ravi-sharma", city: "Jaipur", medium: "Painting", artworks: 31, founding: true, photo: "1741805190547-6da79a18b41a", bio: "Ravi Sharma is one of Jaipur's most active painters, maintaining a prolific output that ranges from intimate studies to monumental works destined for institutional collections. His palette is rooted in the desert light of Rajasthan. He was among the first artists invited to join ArtWall at its founding." },
  { name: "Lakshmi Patel", handle: "lakshmi-patel", city: "Ahmedabad", medium: "Photography", artworks: 27, founding: false, photo: "1773944449123-0089f239a4b3", bio: "Lakshmi Patel photographs the built environment of Gujarat, focusing on the tension between vernacular architecture and rapid urban change. Working in medium format, she produces prints of exceptional tonal richness. She joined ArtWall in 2025." },
  { name: "Vikram Das", handle: "vikram-das", city: "Kolkata", medium: "Painting", artworks: 19, founding: true, photo: "1775567978439-7d94381a9847", bio: "Vikram Das works from a studio overlooking the Hooghly, and that river's shifting greens and greys are ever-present in his oil paintings. He was trained at the Government College of Art and Craft, Kolkata, and joined ArtWall as a founding member. His work is held in several private collections across India." },
  { name: "Ananya Singh", handle: "ananya-singh", city: "Mumbai", medium: "Sculpture", artworks: 7, founding: false, photo: "1750319157047-8d6523f9c53a", bio: "Ananya Singh sculpts in cast bronze and fired ceramic from her studio in Bandra, Mumbai, exploring the body as site of memory. Her pieces are small in scale but dense with psychological weight. She joined ArtWall in 2025 with a debut series of seven works." },
  { name: "Kabir Malhotra", handle: "kabir-malhotra", city: "Pune", medium: "Mixed Media", artworks: 14, founding: false, photo: "1758267928035-6716c00ff3c1", bio: "Kabir Malhotra makes mixed-media work that collapses digital print, hand-stitching, and found paper into layered surfaces that reward close attention. Based in Pune, he has exhibited at independent art spaces across Maharashtra. He joined ArtWall in 2025." },
  { name: "Divya Iyer", handle: "divya-iyer", city: "Hyderabad", medium: "Painting", artworks: 8, founding: false, photo: "1774689305776-a4d005b42a2a", bio: "Divya Iyer paints quietly from her Hyderabad studio, building up thin washes of watercolour and gouache into luminous, meditative compositions. She is interested in the ordinary moments of domestic life and the way light moves through them. She joined ArtWall in 2025." },
  { name: "Sanjay Gupta", handle: "sanjay-gupta", city: "Jaipur", medium: "Photography", artworks: 22, founding: true, photo: "1676742663664-2da16ddcad7a", bio: "Sanjay Gupta photographs the craft traditions of Rajasthan, documenting block-printers, potters, and weavers with an unhurried, intimate eye. His images are widely published and have been exhibited internationally. He joined ArtWall as a founding member and is among its most-followed photographers." },
]

const ARTWORKS = [
  { title: "Amber at Dawn", medium: "Oil on canvas", year: 2023, price: "₹28,000", photo: "1535056626760-b283260686b1" },
  { title: "Pink City Study No. 4", medium: "Watercolour on paper", year: 2024, price: "₹12,500", photo: "1685643096239-9b517edf150f" },
  { title: "Haveli Interior", medium: "Oil on canvas", year: 2022, price: "₹45,000", photo: "1772987020530-4ceac482c95a" },
  { title: "Market Morning", medium: "Acrylic on board", year: 2024, price: null, photo: "1778975144951-ea2a990c4ab4" },
  { title: "Study in Terracotta", medium: "Mixed media", year: 2023, price: "₹18,000", photo: "1758380388480-6f329811c09b" },
  { title: "Monsoon Light", medium: "Oil on canvas", year: 2024, price: "₹36,000", photo: "1768366778536-f4e32064cc2c" },
]

export default function ArtistProfile() {
  const { handle } = useParams<{ handle: string }>()
  const artist = ARTISTS.find((a) => a.handle === handle)

  if (!artist) {
    return (
      <PageShell>
        <div style={{
          fontFamily: "var(--font-sans)",
          fontSize: 16,
          color: t.inkMuted,
          paddingTop: 64,
          textAlign: "center",
        }}>
          <p style={{ fontFamily: "var(--font-heading)", fontSize: 28, color: t.ink, marginBottom: 12 }}>
            Artist not found
          </p>
          <p style={{ marginBottom: 32 }}>
            We could not find an artist matching that profile.
          </p>
          <Link to="/artists" style={{
            fontFamily: "var(--font-sans)",
            fontSize: 13,
            fontWeight: 500,
            padding: "10px 20px",
            borderRadius: 4,
            border: `1px solid ${t.hairline}`,
            color: t.ink,
            background: "transparent",
            textDecoration: "none",
          }}>
            Back to Artist Directory
          </Link>
        </div>
      </PageShell>
    )
  }

  return (
    <div>
      {/* Header band */}
      <div style={{ background: t.band, padding: "64px 0" }}>
        <div style={{ maxWidth: 1240, margin: "0 auto", padding: "0 64px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: 48, alignItems: "start" }}>
            {/* Photo */}
            <img
              src={`https://images.unsplash.com/photo-${artist.photo}?w=480&h=480&fit=crop&auto=format`}
              alt={artist.name}
              style={{
                width: 240,
                height: 240,
                objectFit: "cover",
                borderRadius: 4,
                border: `1px solid ${t.hairline}`,
                display: "block",
              }}
            />
            {/* Info */}
            <div>
              <h1 style={{
                fontFamily: "var(--font-heading)",
                fontSize: 40,
                fontWeight: 500,
                letterSpacing: "-0.03em",
                lineHeight: 1.1,
                color: t.ink,
                margin: "0 0 10px",
              }}>
                {artist.name}
              </h1>
              <p style={{
                fontFamily: "var(--font-sans)",
                fontSize: 14,
                color: t.inkMuted,
                margin: "0 0 16px",
              }}>
                {artist.city} · {artist.medium}
              </p>
              {artist.founding && (
                <div style={{ marginBottom: 20 }}>
                  <Badge label="Founding Member" />
                </div>
              )}
              <p style={{
                fontFamily: "var(--font-sans)",
                fontSize: 14,
                color: t.inkMuted,
                lineHeight: 1.7,
                maxWidth: 520,
                margin: 0,
              }}>
                {artist.bio}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Works section */}
      <PageShell>
        <div style={{ marginBottom: 40 }}>
          <h2 style={{
            fontFamily: "var(--font-heading)",
            fontSize: "clamp(24px, 3vw, 36px)",
            fontWeight: 500,
            letterSpacing: "-0.025em",
            color: t.ink,
            margin: "0 0 8px",
          }}>
            Works in Catalogue
          </h2>
          <p style={{ fontFamily: "var(--font-sans)", fontSize: 14, color: t.inkMuted }}>
            {artist.artworks} works total · showing 6
          </p>
        </div>

        <Hairline />

        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: 24,
          margin: "40px 0 72px",
        }}>
          {ARTWORKS.map((w, i) => (
            <div
              key={i}
              style={{
                border: `1px solid ${t.hairline}`,
                borderRadius: 4,
                overflow: "hidden",
                background: t.wallPaper,
              }}
            >
              <img
                src={`https://images.unsplash.com/photo-${w.photo}?w=600&h=480&fit=crop&auto=format`}
                alt={w.title}
                style={{ width: "100%", height: 240, objectFit: "cover", display: "block" }}
              />
              <div style={{ padding: 14 }}>
                <div style={{
                  fontFamily: "var(--font-heading)",
                  fontSize: 16,
                  fontWeight: 500,
                  color: t.ink,
                  letterSpacing: "-0.02em",
                  marginBottom: 4,
                }}>
                  {w.title}
                </div>
                <div style={{
                  fontFamily: "var(--font-sans)",
                  fontSize: 12,
                  color: t.inkMuted,
                  marginBottom: w.price ? 8 : 0,
                }}>
                  {w.medium} · {w.year}
                </div>
                {w.price && (
                  <div style={{
                    fontFamily: "var(--font-sans)",
                    fontSize: 14,
                    fontWeight: 600,
                    color: t.ink,
                  }}>
                    {w.price}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <Hairline />

        {/* Enquiry section */}
        <div style={{
          padding: "48px 0 80px",
          display: "flex",
          flexDirection: "column",
          gap: 12,
          alignItems: "flex-start",
        }}>
          <h3 style={{
            fontFamily: "var(--font-heading)",
            fontSize: 22,
            fontWeight: 500,
            color: t.ink,
            letterSpacing: "-0.02em",
            margin: "0 0 4px",
          }}>
            {"Enquire about this artist's work"}
          </h3>
          <p style={{
            fontFamily: "var(--font-sans)",
            fontSize: 14,
            color: t.inkMuted,
            margin: "0 0 20px",
          }}>
            Get in touch with our team to learn more about availability, pricing, and commissions.
          </p>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <Btn variant="primary" href="/contact">Send Enquiry</Btn>
            <Btn variant="quiet" href="/contact">View Full Catalogue</Btn>
          </div>
        </div>
      </PageShell>
    </div>
  )
}
