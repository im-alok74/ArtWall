import { useState } from 'react'
import { t } from '../components/tokens'
import { Eyebrow, Hairline, Btn, Field, PageShell } from '../components/ui'

export default function Contact() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [subject, setSubject] = useState('General Enquiry')
  const [message, setMessage] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const inputStyle: React.CSSProperties = {
    width: '100%',
    padding: '10px 12px',
    fontFamily: 'var(--font-sans)',
    fontSize: 14,
    color: t.ink,
    background: t.band,
    border: `1px solid ${t.hairlineStrong}`,
    borderRadius: 4,
    boxSizing: 'border-box',
    outline: 'none',
  }

  return (
    <PageShell>
      <Eyebrow chapter="09" label="Contact" />
      <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 48, fontWeight: 500, color: t.ink, marginTop: 16, marginBottom: 48 }}>
        Contact
      </h1>

      <div style={{ display: 'flex', gap: 64, alignItems: 'flex-start', flexWrap: 'wrap' }}>
        {/* Left column */}
        <div style={{ flex: '0 0 38%', minWidth: 220 }}>
          <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 500, color: t.ink, marginTop: 0, marginBottom: 20 }}>
            Get in touch
          </h2>

          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, fontWeight: 600, margin: 0 }}>
            ArtWall Labs
          </p>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, margin: '4px 0 0' }}>
            Jawahar Kala Kendra Area
          </p>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, margin: '2px 0 0' }}>
            Jaipur, Rajasthan 302004
          </p>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, margin: '2px 0 16px' }}>
            India
          </p>

          <a
            href="mailto:hello@artwallabs.in"
            style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.signal, textDecoration: 'none', display: 'block', marginBottom: 24 }}
          >
            hello@artwallabs.in
          </a>

          <Hairline />

          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, lineHeight: 1.7, marginTop: 20, marginBottom: 16 }}>
            We respond to all enquiries within two business days. For urgent matters related to physical wall installations, please include your booking reference in the subject line.
          </p>

          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, margin: 0 }}>
            Press and media enquiries: press@artwallabs.in
          </p>
        </div>

        {/* Right column */}
        <div style={{ flex: '1 1 0', minWidth: 280 }}>
          {submitted ? (
            <div style={{
              background: t.band,
              border: `1px solid ${t.hairline}`,
              padding: 32,
              borderRadius: 4,
            }}>
              <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 500, color: t.ink, margin: '0 0 12px' }}>
                Message sent.
              </h3>
              <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, margin: '0 0 20px' }}>
                We will be in touch within two business days.
              </p>
              <Btn
                variant="quiet"
                onClick={() => {
                  setSubmitted(false)
                  setName('')
                  setEmail('')
                  setSubject('General Enquiry')
                  setMessage('')
                }}
              >
                Send another
              </Btn>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
              <Field label="Name" placeholder="Your name" required />
              <Field label="Email" type="email" placeholder="your@email.com" required />

              {/* Subject dropdown */}
              <div>
                <label style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, display: 'block', marginBottom: 6, fontWeight: 500 }}>
                  Subject
                </label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  style={inputStyle}
                >
                  <option>General Enquiry</option>
                  <option>Physical Wall Booking</option>
                  <option>Studio Access</option>
                  <option>Partnership</option>
                  <option>Press</option>
                </select>
              </div>

              {/* Message textarea */}
              <div>
                <label style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, display: 'block', marginBottom: 6, fontWeight: 500 }}>
                  Message
                </label>
                <textarea
                  rows={5}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  style={{ ...inputStyle, resize: 'vertical' }}
                  placeholder="How can we help?"
                />
              </div>

              <div>
                <Btn type="submit" onClick={() => setSubmitted(true)}>
                  Send Message
                </Btn>
              </div>
            </div>
          )}
        </div>
      </div>
    </PageShell>
  )
}
