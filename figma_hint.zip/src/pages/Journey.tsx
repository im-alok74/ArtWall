import { t } from '../components/tokens'
import { Eyebrow, PageShell } from '../components/ui'

interface Step {
  num: number
  title: string
  body: string
  detail: string
}

const steps: Step[] = [
  {
    num: 1,
    title: 'Register',
    body: "Artist applies at artwallabs.in. ArtWall reviews the portfolio — a minimum of 5 works and evidence of active practice are required. Accepted artists receive their unique handle and access to the Studio dashboard.",
    detail: 'Review within 5 business days',
  },
  {
    num: 2,
    title: 'Catalogue',
    body: "Artist uploads artwork metadata: title, medium, dimensions, year, edition size, and asking price. Each artwork receives a unique catalogue ID. Images are accepted in JPG or PNG format up to 20 MB.",
    detail: 'JPG / PNG · max 20 MB per image',
  },
  {
    num: 3,
    title: 'Book a Wall',
    body: "Artist browses available physical wall slots across partner venues in Jaipur, Mumbai, Delhi, and Bengaluru. Slots of 7, 14, or 28 days are available. A booking fee of ₹800–₹3,200 applies depending on venue tier and duration.",
    detail: '₹800 – ₹3,200 · 7 / 14 / 28-day slots',
  },
  {
    num: 4,
    title: 'QR Scans',
    body: "Each artwork panel carries a printed QR code that links directly to the artwork's provenance page. Every scan is logged with timestamp and location. Analytics surface in the Studio dashboard within 24 hours.",
    detail: 'Analytics available within 24 hours',
  },
  {
    num: 5,
    title: 'Enquiries & Sales',
    body: "Interested buyers submit enquiries through the provenance page. ArtWall facilitates the introduction. Sales may be recorded directly on-platform; ArtWall takes an 8% platform fee and the artist retains 92%.",
    detail: 'Artist keeps 92% · 8% platform fee',
  },
  {
    num: 6,
    title: 'Royalties',
    body: "When a work is resold, the original artist receives a 5% resale royalty automatically enforced via the certificate transfer protocol. Payouts are processed on the 1st of each month via NEFT or UPI.",
    detail: '5% resale royalty · paid 1st of month',
  },
]

// For this simple linear page every step is treated as "completed" except
// the last which is shown as "current". Adjust as needed when wiring state.
function stepState(num: number): 'completed' | 'current' | 'pending' {
  if (num < steps.length) return 'completed'
  if (num === steps.length) return 'current'
  return 'pending'
}

function indicatorStyle(state: 'completed' | 'current' | 'pending'): React.CSSProperties {
  const base: React.CSSProperties = {
    width: 32,
    height: 32,
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontFamily: 'var(--font-sans)',
    fontSize: 12,
    fontWeight: 600,
    flexShrink: 0,
    zIndex: 1,
    position: 'relative',
  }
  if (state === 'completed') return { ...base, background: t.ink, color: t.wallPaper }
  if (state === 'current') return { ...base, background: t.signal, color: t.wallPaper }
  return { ...base, background: t.band, color: t.inkMuted, border: `1px solid ${t.hairline}` }
}

export default function Journey() {
  return (
    <PageShell>
      <div style={{ marginBottom: 16 }}>
        <Eyebrow chapter="02" label="How It Works" />
      </div>
      <h1 style={{
        fontFamily: 'var(--font-heading)',
        fontSize: 'clamp(36px, 5vw, 48px)',
        fontWeight: 500,
        letterSpacing: '-0.03em',
        lineHeight: 1.15,
        color: t.ink,
        marginBottom: 72,
      }}>
        From Studio to Sale
      </h1>

      <div style={{ position: 'relative', maxWidth: 760 }}>
        {/* Vertical spine */}
        <div style={{
          position: 'absolute',
          left: 15,
          top: 16,
          bottom: 16,
          width: 1,
          background: t.hairline,
        }} />

        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {steps.map((step, i) => {
            const state = stepState(step.num)
            const isLast = i === steps.length - 1
            return (
              <div
                key={step.num}
                style={{
                  display: 'flex',
                  gap: 32,
                  paddingBottom: isLast ? 0 : 56,
                  alignItems: 'flex-start',
                }}
              >
                {/* Left: indicator */}
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                  <div style={indicatorStyle(state)}>
                    {state === 'completed'
                      ? <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><polyline points="2,6 5,9 10,3" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
                      : step.num
                    }
                  </div>
                </div>

                {/* Right: content */}
                <div style={{ paddingTop: 4 }}>
                  <h3 style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 20,
                    fontWeight: 500,
                    letterSpacing: '-0.02em',
                    color: t.ink,
                    margin: 0,
                    marginBottom: 10,
                    lineHeight: 1.3,
                  }}>
                    {step.title}
                  </h3>
                  <p style={{
                    fontFamily: 'var(--font-sans)',
                    fontSize: 14,
                    color: t.inkMuted,
                    lineHeight: 1.7,
                    margin: 0,
                    marginBottom: 14,
                  }}>
                    {step.body}
                  </p>
                  <div style={{
                    display: 'inline-block',
                    fontFamily: 'var(--font-sans)',
                    fontSize: 11,
                    fontWeight: 500,
                    letterSpacing: '0.03em',
                    color: t.signal,
                    background: t.band,
                    border: `1px solid ${t.hairline}`,
                    borderRadius: 4,
                    padding: '4px 10px',
                  }}>
                    {step.detail}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </PageShell>
  )
}
