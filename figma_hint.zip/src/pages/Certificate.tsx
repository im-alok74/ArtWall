import { useState } from 'react';
import { t } from '../components/tokens';
import { Eyebrow, Hairline, PageShell } from '../components/ui';

const artworks = [
  {
    artist: "Priya Mehta",
    title: "Amber at Dawn",
    medium: "Oil on canvas",
    dimensions: "90 × 120 cm",
    year: "2023",
    edition: "Original (1 of 1)",
    hash: "a3f9c2d1e4b7f08c9a6d3e1b2f4a8c0d7e3b9f1a4c6d2e8b0f5a7c1d3e9b4f2",
  },
  {
    artist: "Arjun Nair",
    title: "Shore Memory XII",
    medium: "Archival pigment print",
    dimensions: "60 × 90 cm",
    year: "2024",
    edition: "3 of 10",
    hash: "b7e2a4f1c8d5e0b3f9a6c1d4e7b2f5a8c0d3e6b9f1a4c7d0e3b6f2a5c8d1e4b7",
  },
  {
    artist: "Ravi Sharma",
    title: "Monsoon Terrace",
    medium: "Acrylic on board",
    dimensions: "45 × 60 cm",
    year: "2024",
    edition: "Original (1 of 1)",
    hash: "c1d4e7b0f3a6c9d2e5b8f1a4c7d0e3b6f9a2c5d8e1b4f7a0c3d6e9b2f5a8c1d4",
  },
];

const chainNodes = [
  { title: "Artwork Created", subtitle: "Artist registers work, metadata locked" },
  { title: "Certificate Issued", subtitle: "SHA-256 hash generated, certificate ID assigned" },
  { title: "First Sale", subtitle: "Certificate transfers to buyer, artist royalty pool activated" },
  { title: "Transfer Logged", subtitle: "Public ledger entry created, QR code updated" },
  { title: "Resale", subtitle: "5% royalty triggered, new owner certificate issued" },
];

function CertField({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div style={{ display: 'flex', gap: 16, marginBottom: 12, alignItems: 'flex-start' }}>
      <span
        style={{
          flex: '0 0 140px',
          fontSize: 11,
          color: t.inkMuted,
          textTransform: 'uppercase',
          letterSpacing: '0.08em',
          fontFamily: 'var(--font-sans)',
          paddingTop: 1,
        }}
      >
        {label}
      </span>
      <span
        style={{
          flex: 1,
          fontSize: mono ? 10 : 13,
          color: t.ink,
          fontFamily: mono ? 'monospace' : 'var(--font-sans)',
          wordBreak: 'break-all',
          lineHeight: 1.5,
        }}
      >
        {value}
      </span>
    </div>
  );
}

export default function Certificate() {
  const [index, setIndex] = useState(0);
  const art = artworks[index];
  const certId = "AWL-" + art.hash.slice(0, 8).toUpperCase();

  function prev() {
    setIndex((i) => (i - 1 + artworks.length) % artworks.length);
  }
  function next() {
    setIndex((i) => (i + 1) % artworks.length);
  }

  return (
    <PageShell>
      {/* Section 1 — Header */}
      <section style={{ marginBottom: 72 }}>
        <Eyebrow chapter="06" label="Provenance" />
        <h1
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 48,
            fontWeight: 500,
            color: t.ink,
            margin: '16px 0 24px',
            lineHeight: 1.15,
          }}
        >
          The Certificate Chain
        </h1>
        <p
          style={{
            fontFamily: 'var(--font-sans)',
            fontSize: 18,
            color: t.inkMuted,
            maxWidth: 640,
            lineHeight: 1.7,
            margin: 0,
          }}
        >
          Every artwork on ArtWall carries a permanent, verifiable provenance certificate. It follows
          the work through every transfer — from studio to first buyer, and through every resale.
        </p>
      </section>

      <Hairline />

      {/* Section 2 — Chain Diagram */}
      <section style={{ marginTop: 64, marginBottom: 80 }}>
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: 8,
            alignItems: 'center',
          }}
        >
          {chainNodes.map((node, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div
                style={{
                  border: `1px solid ${t.hairline}`,
                  padding: 16,
                  borderRadius: 4,
                  minWidth: 140,
                  textAlign: 'center',
                }}
              >
                <div
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: 14,
                    fontWeight: 500,
                    color: t.ink,
                    marginBottom: 6,
                  }}
                >
                  {node.title}
                </div>
                <div
                  style={{
                    fontFamily: 'var(--font-sans)',
                    fontSize: 11,
                    color: t.inkMuted,
                    lineHeight: 1.4,
                  }}
                >
                  {node.subtitle}
                </div>
              </div>
              {i < chainNodes.length - 1 && (
                <span
                  style={{
                    fontSize: 20,
                    color: t.inkMuted,
                    flexShrink: 0,
                    fontFamily: 'var(--font-sans)',
                  }}
                >
                  →
                </span>
              )}
            </div>
          ))}
        </div>
      </section>

      <Hairline />

      {/* Section 3 — Demo Certificate */}
      <section style={{ marginTop: 64, marginBottom: 96 }}>
        {/* Navigation */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 16,
            marginBottom: 32,
          }}
        >
          <button
            onClick={prev}
            style={{
              background: 'none',
              border: `1px solid ${t.hairline}`,
              borderRadius: 4,
              padding: '6px 14px',
              cursor: 'pointer',
              fontFamily: 'var(--font-sans)',
              fontSize: 14,
              color: t.ink,
            }}
          >
            ←
          </button>
          <span
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: 13,
              color: t.inkMuted,
            }}
          >
            {index + 1} of {artworks.length}
          </span>
          <button
            onClick={next}
            style={{
              background: 'none',
              border: `1px solid ${t.hairline}`,
              borderRadius: 4,
              padding: '6px 14px',
              cursor: 'pointer',
              fontFamily: 'var(--font-sans)',
              fontSize: 14,
              color: t.ink,
            }}
          >
            →
          </button>
        </div>

        {/* Certificate card */}
        <div
          style={{
            border: `2px solid ${t.ink}`,
            borderRadius: 4,
            maxWidth: 640,
            margin: '0 auto',
            padding: 48,
          }}
        >
          {/* Certificate header */}
          <div style={{ textAlign: 'center', marginBottom: 24 }}>
            <div
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 11,
                letterSpacing: '0.3em',
                textTransform: 'uppercase',
                color: t.ink,
                marginBottom: 20,
              }}
            >
              ARTWALLABS
            </div>
            <div
              style={{
                height: 1,
                background: t.hairline,
                marginBottom: 20,
              }}
            />
            <div
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 22,
                fontWeight: 500,
                color: t.ink,
              }}
            >
              CERTIFICATE OF AUTHENTICITY
            </div>
          </div>

          {/* Fields */}
          <div style={{ marginTop: 32 }}>
            <CertField label="Artist" value={art.artist} />
            <CertField label="Title" value={art.title} />
            <CertField label="Medium" value={art.medium} />
            <CertField label="Dimensions" value={art.dimensions} />
            <CertField label="Year" value={art.year} />
            <CertField label="Edition" value={art.edition} />
            <CertField label="Certificate ID" value={certId} />
            <CertField label="SHA-256 Hash" value={art.hash} mono />
            <CertField label="Issued By" value="ArtWall Labs, Jaipur" />
          </div>

          {/* QR placeholder */}
          <div style={{ display: 'flex', justifyContent: 'center', margin: '32px 0 24px' }}>
            <div
              style={{
                width: 64,
                height: 64,
                border: `2px dashed ${t.hairlineStrong}`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <span
                style={{
                  fontSize: 10,
                  color: t.inkMuted,
                  fontFamily: 'var(--font-sans)',
                }}
              >
                QR
              </span>
            </div>
          </div>

          {/* Signature line */}
          <div style={{ height: 1, background: t.hairline, marginBottom: 8 }} />
          <div
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: 10,
              color: t.inkMuted,
              textAlign: 'center',
            }}
          >
            Authorised Signatory
          </div>
        </div>
      </section>
    </PageShell>
  );
}
