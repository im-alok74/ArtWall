import { useState } from 'react'
import { Link } from 'react-router'
import { t } from '../components/tokens'
import { Eyebrow, Btn, Field, PageShell } from '../components/ui'

const STEPS = [
  {
    type: 'radio' as const,
    question: 'Who are you?',
    options: [
      'Emerging artist (under 5 years active practice)',
      'Mid-career artist (5–15 years)',
      'Established artist (15+ years)',
      'Artist-educator (teaching alongside practice)',
    ],
  },
  {
    type: 'checkbox' as const,
    question: 'How do you sell today?',
    options: [
      'Through personal networks and introductions',
      'Gallery or dealer representation',
      'Art fairs and exhibitions',
      'Instagram or online direct sales',
      'I rarely sell',
    ],
  },
  {
    type: 'radio' as const,
    question: 'What is your biggest pain?',
    options: [
      'Visibility — nobody knows my work exists',
      "Pricing — I don’t know what my work is worth",
      'Logistics — showing and shipping are complicated',
      'Trust — buyers worry about authenticity',
      'Income — I cannot live from my practice',
    ],
  },
  {
    type: 'checkbox' as const,
    question: 'What tools do you use?',
    options: [
      'Google Sheets or Excel to track inventory',
      'Instagram as my primary portfolio',
      'A personal website',
      'WhatsApp for buyer communication',
      'Nothing structured',
    ],
  },
  {
    type: 'contact' as const,
    question: 'Contact info',
    options: [],
  },
]

type Answers = Record<number, number | number[] | undefined>

export default function Survey() {
  const [step, setStep] = useState(0)
  const [answers, setAnswers] = useState<Answers>({})
  const [submitted, setSubmitted] = useState(false)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')

  const currentStep = STEPS[step]

  function selectRadio(idx: number) {
    setAnswers((prev) => ({ ...prev, [step]: idx }))
  }

  function toggleCheckbox(idx: number) {
    setAnswers((prev) => {
      const current = (prev[step] as number[] | undefined) ?? []
      const next = current.includes(idx)
        ? current.filter((i) => i !== idx)
        : [...current, idx]
      return { ...prev, [step]: next }
    })
  }

  function isChecked(idx: number): boolean {
    const val = answers[step]
    if (Array.isArray(val)) return val.includes(idx)
    return val === idx
  }

  function handleNext() {
    if (step < 4) setStep((s) => s + 1)
    else setSubmitted(true)
  }

  if (submitted) {
    return (
      <PageShell>
        <div style={{ maxWidth: 560 }}>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 36, fontWeight: 500, color: t.ink, marginBottom: 20, marginTop: 0 }}>
            Thank you.
          </h1>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 16, color: t.inkMuted, lineHeight: 1.7, marginBottom: 32 }}>
            Your responses help us build ArtWall for artists like you. If you left your email, we will share the aggregated findings when the survey closes.
          </p>
          <Link to="/">
            <Btn variant="quiet">Back to Home</Btn>
          </Link>
        </div>
      </PageShell>
    )
  }

  return (
    <PageShell>
      <Eyebrow chapter="" label="Survey" />
      <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 40, fontWeight: 500, color: t.ink, marginTop: 16, marginBottom: 12 }}>
        Tell us about your practice
      </h1>
      <p style={{ fontFamily: 'var(--font-sans)', fontSize: 16, color: t.inkMuted, lineHeight: 1.7, marginBottom: 40, maxWidth: 560 }}>
        Five questions. No account required. Completely anonymous unless you choose to share your contact.
      </p>

      {/* Progress bar */}
      <div style={{ width: '100%', height: 4, background: t.hairline, borderRadius: 2, marginBottom: 8, overflow: 'hidden' }}>
        <div
          style={{
            height: '100%',
            width: `${(step / 4) * 100}%`,
            background: t.signal,
            borderRadius: 2,
            transition: 'width 0.3s ease',
          }}
        />
      </div>
      <p style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginBottom: 32 }}>
        Step {step + 1} of 5
      </p>

      {/* Step content */}
      <div style={{ maxWidth: 600 }}>
        <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 500, color: t.ink, marginBottom: 20, marginTop: 0 }}>
          {currentStep.question}
        </h2>

        {(currentStep.type === 'radio' || currentStep.type === 'checkbox') &&
          currentStep.options.map((option, idx) => {
            const selected = isChecked(idx)
            return (
              <div
                key={idx}
                onClick={() =>
                  currentStep.type === 'radio' ? selectRadio(idx) : toggleCheckbox(idx)
                }
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  border: `1px solid ${selected ? t.ink : t.hairline}`,
                  background: selected ? t.band : t.wallPaper,
                  padding: '12px 16px',
                  borderRadius: 4,
                  cursor: 'pointer',
                  marginBottom: 8,
                  fontFamily: 'var(--font-sans)',
                  fontSize: 14,
                  color: t.ink,
                  userSelect: 'none',
                  transition: 'border-color 0.15s, background 0.15s',
                }}
              >
                <span>{option}</span>
                {selected && (
                  <span style={{ color: t.signal, fontWeight: 600, marginLeft: 12 }}>&#10003;</span>
                )}
              </div>
            )
          })}

        {currentStep.type === 'contact' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Field label="Name" placeholder="Your name" />
            <Field label="Email" type="email" placeholder="your@email.com" />
            <p style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, margin: 0 }}>
              Optional. We use this only to share the survey findings with you.
            </p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <div style={{ display: 'flex', gap: 12, marginTop: 32, alignItems: 'center' }}>
        <Btn
          variant="quiet"
          onClick={() => setStep((s) => s - 1)}
          disabled={step === 0}
        >
          Back
        </Btn>
        <Btn onClick={handleNext}>
          {step === 4 ? 'Submit' : 'Next'}
        </Btn>
      </div>
    </PageShell>
  )
}
