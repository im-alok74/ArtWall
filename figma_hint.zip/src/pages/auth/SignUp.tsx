import { useState } from 'react'
import { Link } from 'react-router'
import { t } from '../../components/tokens'
import { Btn, Hairline } from '../../components/ui'

function PasswordStrengthMeter({ password }: { password: string }) {
  const len = password.length
  const strength = len === 0 ? 0 : len < 6 ? 1 : len < 10 ? 2 : len < 14 ? 3 : 4
  const colors = ['', '#ef4444', '#f59e0b', '#22c55e', '#16a34a']
  const labels = ['', 'Weak', 'Fair', 'Good', 'Strong']
  return (
    <div style={{ marginTop: 6 }}>
      <div style={{ display: 'flex', gap: 4, marginBottom: 4 }}>
        {[1, 2, 3, 4].map(i => (
          <div key={i} style={{
            flex: 1, height: 3, borderRadius: 2,
            background: i <= strength ? colors[strength] : t.hairlineStrong,
            transition: 'background 0.2s',
          }} />
        ))}
      </div>
      {password.length > 0 && (
        <span style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: colors[strength] }}>
          {labels[strength]}
        </span>
      )}
    </div>
  )
}

function FormField({
  label, type = 'text', value, onChange, placeholder, required, hint, id,
}: {
  label: string; type?: string; value: string; onChange: (v: string) => void;
  placeholder?: string; required?: boolean; hint?: string; id: string;
}) {
  const [focused, setFocused] = useState(false)
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <label htmlFor={id} style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, letterSpacing: '-0.01em' }}>
        {label}{required && <span style={{ color: t.signal, marginLeft: 2 }}>*</span>}
      </label>
      <input
        id={id}
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          width: '100%', padding: '10px 12px',
          fontFamily: 'var(--font-sans)', fontSize: 14,
          color: t.ink, background: t.band,
          border: `1px solid ${focused ? t.ink : t.hairlineStrong}`,
          borderRadius: 4, outline: 'none', transition: 'border-color 0.15s',
        }}
      />
      {hint && <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>{hint}</span>}
    </div>
  )
}

export default function SignUp() {
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' })
  const [consented, setConsented] = useState(false)
  const [marketing, setMarketing] = useState(false)

  const set = (k: keyof typeof form) => (v: string) => setForm(f => ({ ...f, [k]: v }))

  const checkboxStyle: React.CSSProperties = {
    width: 16, height: 16, accentColor: t.ink, cursor: 'pointer', flexShrink: 0,
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', fontFamily: 'var(--font-sans)' }}>
      {/* Left column */}
      <div style={{
        width: '44%', minWidth: 340, background: t.footer, padding: '64px 56px',
        display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
        position: 'sticky', top: 0, height: '100vh', overflowY: 'auto',
      }}>
        <div>
          {/* Wordmark */}
          <div style={{ marginBottom: 48 }}>
            <span style={{
              fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 500,
              color: t.wallPaper, letterSpacing: '-0.02em',
            }}>ArtWall</span>
          </div>

          <h1 style={{
            fontFamily: 'var(--font-heading)', fontSize: 'clamp(28px, 3vw, 40px)',
            fontWeight: 500, color: t.wallPaper, letterSpacing: '-0.03em',
            lineHeight: 1.15, marginBottom: 20,
          }}>
            {"Join India's art infrastructure."}
          </h1>

          <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.65)', lineHeight: 1.65, marginBottom: 48 }}>
            {"ArtWall Labs builds the tools India's independent artists need to manage their work, issue certificates of authenticity, and exhibit in physical spaces — without relying on galleries or platforms that take a cut."}
          </p>

          {/* Steps */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0, marginBottom: 48 }}>
            {[
              { n: '01', title: 'We review your application', body: 'Our team looks at every application personally. You will hear back within 48 hours.' },
              { n: '02', title: 'You get your founding member number', body: 'A unique number that anchors every certificate and provenance record you ever issue.' },
              { n: '03', title: 'Full Studio access, free for year one', body: 'Artworks, bookings, certificates, sales — everything in one place, at no cost for your first year.' },
            ].map((step, i) => (
              <div key={step.n}>
                {i > 0 && <div style={{ width: 1, height: 20, background: 'rgba(255,255,255,0.12)', marginLeft: 15, marginTop: 0 }} />}
                <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
                  <div style={{
                    width: 30, height: 30, borderRadius: '50%',
                    border: '1px solid rgba(255,255,255,0.2)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    flexShrink: 0, marginTop: 2,
                  }}>
                    <span style={{ fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,0.5)' }}>{step.n}</span>
                  </div>
                  <div>
                    <p style={{ fontSize: 13, fontWeight: 500, color: t.wallPaper, marginBottom: 4 }}>{step.title}</p>
                    <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)', lineHeight: 1.55 }}>{step.body}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quote */}
        <div style={{ borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: 28 }}>
          <p style={{ fontSize: 14, fontStyle: 'italic', color: 'rgba(255,255,255,0.55)', lineHeight: 1.6, marginBottom: 12 }}>
            {"\"Finally, a platform that treats the artist's archive as seriously as the work itself. My provenance records are clean for the first time in fifteen years.\""}
          </p>
          <p style={{ fontSize: 12, fontWeight: 500, color: 'rgba(255,255,255,0.35)' }}>
            Meera Krishnaswamy — Painter, Chennai
          </p>
        </div>
      </div>

      {/* Right column */}
      <div style={{ flex: 1, padding: '64px 56px', overflowY: 'auto', background: t.wallPaper }}>
        <div style={{ maxWidth: 440 }}>
          <h2 style={{
            fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500,
            color: t.ink, letterSpacing: '-0.025em', marginBottom: 8,
          }}>Create your account</h2>
          <p style={{ fontSize: 14, color: t.inkMuted, marginBottom: 36, lineHeight: 1.5 }}>
            Free for independent artists during the founding period.
          </p>

          <form onSubmit={e => e.preventDefault()} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <FormField id="name" label="Full name" value={form.name} onChange={set('name')} placeholder="As it will appear on certificates" required />
            <FormField id="email" label="Email" type="email" value={form.email} onChange={set('email')} placeholder="you@example.com" required />

            <div>
              <FormField id="password" label="Password" type="password" value={form.password} onChange={set('password')} placeholder="Minimum 8 characters" required />
              <PasswordStrengthMeter password={form.password} />
            </div>

            <FormField id="confirm" label="Confirm password" type="password" value={form.confirm} onChange={set('confirm')} required
              hint={form.confirm.length > 0 && form.confirm !== form.password ? "Passwords do not match." : undefined}
            />

            <Hairline />

            {/* Privacy notice */}
            <div style={{
              padding: '14px 16px', background: t.band, borderRadius: 4,
              border: `1px solid ${t.hairline}`,
            }}>
              <p style={{ fontSize: 12, color: t.inkMuted, lineHeight: 1.6 }}>
                {"ArtWall Labs stores your name and email to operate your account. We never sell your data. You can delete your account and all records from Settings at any time."}
              </p>
            </div>

            {/* Required consent */}
            <label style={{ display: 'flex', gap: 12, alignItems: 'flex-start', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={consented}
                onChange={e => setConsented(e.target.checked)}
                style={checkboxStyle}
              />
              <span style={{ fontSize: 13, color: t.ink, lineHeight: 1.55 }}>
                {"I agree to ArtWall Labs storing my name, email, and account activity to operate this service. Required to create an account."}{' '}
                <span style={{ color: t.signal, cursor: 'pointer', textDecoration: 'underline' }}>Privacy policy</span>
              </span>
            </label>

            {/* Optional marketing */}
            <label style={{ display: 'flex', gap: 12, alignItems: 'flex-start', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={marketing}
                onChange={e => setMarketing(e.target.checked)}
                style={checkboxStyle}
              />
              <span style={{ fontSize: 13, color: t.inkMuted, lineHeight: 1.55 }}>
                <span style={{
                  display: 'inline-block', fontSize: 10, fontWeight: 600,
                  color: t.inkMuted, letterSpacing: '0.08em', textTransform: 'uppercase',
                  border: `1px solid ${t.hairlineStrong}`, borderRadius: 2,
                  padding: '1px 5px', marginRight: 6, verticalAlign: 'middle',
                }}>Optional</span>
                {"Send me occasional updates about new features, exhibition calls, and ArtWall news. No more than twice a month."}
              </span>
            </label>

            <div style={{ paddingTop: 4 }}>
              <Btn type="submit" variant="primary" disabled={!consented}>
                Create account
              </Btn>
            </div>

            <p style={{ fontSize: 13, color: t.inkMuted }}>
              Already have an account?{' '}
              <Link to="/sign-in" style={{ color: t.ink, fontWeight: 500, textDecoration: 'underline' }}>Sign in</Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  )
}
