import { useState } from 'react'
import { t } from '../../components/tokens'
import { Btn, Hairline } from '../../components/ui'

function ConsentRow({
  id, checked, onChange, children, optional = false,
}: {
  id: string; checked: boolean; onChange: (v: boolean) => void;
  children: React.ReactNode; optional?: boolean;
}) {
  return (
    <label htmlFor={id} style={{ display: 'flex', gap: 14, alignItems: 'flex-start', cursor: 'pointer', width: '100%' }}>
      <div style={{ paddingTop: 2, flexShrink: 0 }}>
        <input
          id={id}
          type="checkbox"
          checked={checked}
          onChange={e => onChange(e.target.checked)}
          style={{ width: 18, height: 18, accentColor: t.ink, cursor: 'pointer' }}
        />
      </div>
      <div style={{ flex: 1 }}>
        {optional && (
          <span style={{
            display: 'inline-block', fontSize: 10, fontWeight: 600,
            color: t.inkMuted, letterSpacing: '0.08em', textTransform: 'uppercase',
            border: `1px solid ${t.hairlineStrong}`, borderRadius: 2,
            padding: '1px 5px', marginRight: 8, verticalAlign: 'middle',
          }}>Optional</span>
        )}
        <span style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, lineHeight: 1.6 }}>
          {children}
        </span>
      </div>
    </label>
  )
}

function Section({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ padding: '28px 0' }}>
      {children}
    </div>
  )
}

export default function Welcome() {
  const [ageConfirmed, setAgeConfirmed] = useState(false)
  const [showParentalForm, setShowParentalForm] = useState(false)
  const [guardianName, setGuardianName] = useState('')
  const [guardianEmail, setGuardianEmail] = useState('')
  const [accountConsent, setAccountConsent] = useState(false)
  const [profilePublic, setProfilePublic] = useState(false)
  const [foundingMember, setFoundingMember] = useState(false)

  const canContinue = ageConfirmed && accountConsent

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)',
    fontSize: 14, color: t.ink, background: t.band,
    border: `1px solid ${t.hairlineStrong}`, borderRadius: 4, outline: 'none',
  }

  return (
    <div style={{
      minHeight: '100vh', background: t.wallPaper, display: 'flex',
      flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: '48px 24px', fontFamily: 'var(--font-sans)',
    }}>
      <div style={{ width: '100%', maxWidth: 560 }}>
        {/* Header */}
        <div style={{ marginBottom: 36, textAlign: 'center' }}>
          <span style={{
            fontFamily: 'var(--font-heading)', fontSize: 20, fontWeight: 500,
            color: t.ink, letterSpacing: '-0.02em', display: 'block', marginBottom: 24,
          }}>ArtWall</span>
          <h1 style={{
            fontFamily: 'var(--font-heading)', fontSize: 'clamp(24px, 3vw, 32px)',
            fontWeight: 500, color: t.ink, letterSpacing: '-0.025em',
            lineHeight: 1.2, marginBottom: 12,
          }}>Before we continue</h1>
          <p style={{ fontSize: 14, color: t.inkMuted, lineHeight: 1.6 }}>
            We need a moment to confirm a few things. This keeps your account and your work protected.
          </p>
        </div>

        <div style={{ border: `1px solid ${t.hairline}`, borderRadius: 4 }}>

          {/* Section 1: Age declaration */}
          <Section>
            <div style={{ padding: '0 28px' }}>
              <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: t.inkMuted, marginBottom: 16 }}>
                Age declaration
              </p>
              <ConsentRow id="age" checked={ageConfirmed} onChange={v => { setAgeConfirmed(v); if (v) setShowParentalForm(false) }}>
                I confirm I am 18 or older.
              </ConsentRow>
              <div style={{ marginTop: 12, marginLeft: 32 }}>
                <button
                  onClick={() => setShowParentalForm(p => !p)}
                  style={{
                    background: 'none', border: 'none', padding: 0, cursor: 'pointer',
                    fontSize: 13, color: t.signal, textDecoration: 'underline',
                    fontFamily: 'var(--font-sans)',
                  }}
                >
                  {showParentalForm ? 'Cancel parental consent' : 'Under 18? Click here for the parental consent path.'}
                </button>
              </div>
              {showParentalForm && (
                <div style={{
                  marginTop: 16, marginLeft: 32, padding: 20,
                  background: t.band, borderRadius: 4, border: `1px solid ${t.hairline}`,
                  display: 'flex', flexDirection: 'column', gap: 14,
                }}>
                  <p style={{ fontSize: 13, color: t.inkMuted, lineHeight: 1.5 }}>
                    {"If you are under 18, a parent or guardian must consent on your behalf. Enter their details below and we will send them a consent request."}
                  </p>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    <label style={{ fontSize: 12, fontWeight: 500, color: t.ink }}>{"Guardian's full name"}</label>
                    <input
                      value={guardianName} onChange={e => setGuardianName(e.target.value)}
                      placeholder="Full legal name" style={inputStyle}
                    />
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    <label style={{ fontSize: 12, fontWeight: 500, color: t.ink }}>{"Guardian's email address"}</label>
                    <input
                      type="email" value={guardianEmail} onChange={e => setGuardianEmail(e.target.value)}
                      placeholder="guardian@example.com" style={inputStyle}
                    />
                  </div>
                  <Btn variant="quiet">Send consent request</Btn>
                </div>
              )}
            </div>
          </Section>

          <Hairline />

          {/* Section 2: Required account consent */}
          <Section>
            <div style={{ padding: '0 28px' }}>
              <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: t.inkMuted, marginBottom: 16 }}>
                Account data — required
              </p>
              <ConsentRow id="account-consent" checked={accountConsent} onChange={setAccountConsent}>
                {"ArtWall Labs will store your name, email, and booking details to operate your account. You can withdraw this consent at any time from your account settings."}
              </ConsentRow>
            </div>
          </Section>

          <Hairline />

          {/* Section 3: Optional profile publication */}
          <Section>
            <div style={{ padding: '0 28px' }}>
              <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: t.inkMuted, marginBottom: 16 }}>
                Profile publication — optional
              </p>
              <ConsentRow id="profile-public" checked={profilePublic} onChange={setProfilePublic} optional>
                {"Show my artist profile on the public ArtWall website. Turning this off hides your profile but not your bookings."}
              </ConsentRow>
              {profilePublic && (
                <div style={{ marginTop: 10, marginLeft: 32 }}>
                  <button
                    onClick={() => setProfilePublic(false)}
                    style={{
                      background: 'none', border: 'none', padding: 0, cursor: 'pointer',
                      fontSize: 12, color: t.inkMuted, textDecoration: 'underline',
                      fontFamily: 'var(--font-sans)',
                    }}
                  >
                    Withdraw — hide my public profile
                  </button>
                </div>
              )}
            </div>
          </Section>

          <Hairline />

          {/* Section 4: Founding member opt-in */}
          <Section>
            <div style={{ padding: '0 28px' }}>
              <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: t.inkMuted, marginBottom: 16 }}>
                Founding member listing — optional
              </p>
              <ConsentRow id="founding" checked={foundingMember} onChange={setFoundingMember} optional>
                {"List me as a founding member of ArtWall Labs. Your founding number will appear on all certificates you issue."}
              </ConsentRow>
              {foundingMember && (
                <div style={{ marginTop: 10, marginLeft: 32 }}>
                  <button
                    onClick={() => setFoundingMember(false)}
                    style={{
                      background: 'none', border: 'none', padding: 0, cursor: 'pointer',
                      fontSize: 12, color: t.inkMuted, textDecoration: 'underline',
                      fontFamily: 'var(--font-sans)',
                    }}
                  >
                    Withdraw — remove my founding member listing
                  </button>
                </div>
              )}
            </div>
          </Section>

        </div>

        {/* Submit */}
        <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 12 }}>
          {!canContinue && (
            <p style={{ fontSize: 12, color: t.inkMuted }}>
              {!ageConfirmed && !accountConsent
                ? 'Please confirm your age and agree to account data storage to continue.'
                : !ageConfirmed
                ? 'Please confirm your age to continue.'
                : 'Please agree to account data storage to continue.'}
            </p>
          )}
          <div>
            <Btn type="submit" variant="primary" disabled={!canContinue}>
              Continue to Studio
            </Btn>
          </div>
        </div>
      </div>
    </div>
  )
}
