import { useState } from 'react'
import { Link } from 'react-router'
import { t } from '../../components/tokens'
import { Btn, Hairline } from '../../components/ui'

function FormField({
  label, type = 'text', value, onChange, placeholder, id, error,
}: {
  label: string; type?: string; value: string; onChange: (v: string) => void;
  placeholder?: string; id: string; error?: string;
}) {
  const [focused, setFocused] = useState(false)
  const borderColor = error ? '#ef4444' : focused ? t.ink : t.hairlineStrong
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <label htmlFor={id} style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, letterSpacing: '-0.01em' }}>
        {label}
      </label>
      <input
        id={id}
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          width: '100%', padding: '10px 12px',
          fontFamily: 'var(--font-sans)', fontSize: 14,
          color: t.ink, background: t.band,
          border: `1px solid ${borderColor}`,
          borderRadius: 4, outline: 'none', transition: 'border-color 0.15s',
        }}
      />
      {error && <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: '#ef4444' }}>{error}</span>}
    </div>
  )
}

type ErrorState = 'none' | 'wrong-password' | 'rate-limited'

export default function SignIn() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [errorState, setErrorState] = useState<ErrorState>('none')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Simulate error states for demonstration
    if (password === 'ratelimit') {
      setErrorState('rate-limited')
    } else if (password.length > 0 && password !== 'correct') {
      setErrorState('wrong-password')
    } else {
      setErrorState('none')
    }
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', fontFamily: 'var(--font-sans)' }}>
      {/* Left column */}
      <div style={{
        width: '44%', minWidth: 340, background: t.footer, padding: '64px 56px',
        display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
        position: 'sticky', top: 0, height: '100vh', overflowY: 'auto',
      }}>
        <div>
          <div style={{ marginBottom: 56 }}>
            <span style={{
              fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 500,
              color: t.wallPaper, letterSpacing: '-0.02em',
            }}>ArtWall</span>
          </div>

          <h1 style={{
            fontFamily: 'var(--font-heading)', fontSize: 'clamp(28px, 3vw, 40px)',
            fontWeight: 500, color: t.wallPaper, letterSpacing: '-0.03em',
            lineHeight: 1.15, marginBottom: 20,
          }}>
            Your studio is waiting.
          </h1>

          <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.55)', lineHeight: 1.65, marginBottom: 40 }}>
            {"Manage your artworks, issue certificates, and track every sale and exhibition — all in one place built for India's independent artists."}
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {[
              'Certificate of authenticity, issued in 60 seconds',
              'Wall slot bookings, calendar, and logistics',
              'Full sales and provenance history',
            ].map(item => (
              <div key={item} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <div style={{
                  width: 5, height: 5, borderRadius: '50%', background: 'rgba(255,255,255,0.3)',
                  flexShrink: 0, marginTop: 6,
                }} />
                <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.5)', lineHeight: 1.5 }}>{item}</p>
              </div>
            ))}
          </div>
        </div>

        <div style={{ borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: 28 }}>
          <p style={{ fontSize: 12, fontWeight: 500, color: 'rgba(255,255,255,0.3)' }}>
            {"ArtWall Labs · India's art infrastructure"}
          </p>
        </div>
      </div>

      {/* Right column */}
      <div style={{ flex: 1, padding: '64px 56px', overflowY: 'auto', background: t.wallPaper, display: 'flex', alignItems: 'flex-start' }}>
        <div style={{ maxWidth: 400, width: '100%' }}>
          <h2 style={{
            fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500,
            color: t.ink, letterSpacing: '-0.025em', marginBottom: 8,
          }}>Welcome back</h2>
          <p style={{ fontSize: 14, color: t.inkMuted, marginBottom: 36, lineHeight: 1.5 }}>
            Sign in to access your Studio.
          </p>

          {/* Rate-limited callout */}
          {errorState === 'rate-limited' && (
            <div style={{
              padding: '14px 16px', background: '#fef2f2',
              border: '1px solid #fecaca', borderRadius: 4, marginBottom: 24,
            }}>
              <p style={{ fontSize: 13, fontWeight: 500, color: '#991b1b', marginBottom: 4 }}>Too many attempts</p>
              <p style={{ fontSize: 13, color: '#b91c1c', lineHeight: 1.5 }}>
                {"Your account has been temporarily locked after multiple failed sign-in attempts. Please wait 15 minutes before trying again, or reset your password."}
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <FormField
              id="email" label="Email" type="email"
              value={email} onChange={setEmail}
              placeholder="you@example.com"
            />

            <div>
              <FormField
                id="password" label="Password" type="password"
                value={password} onChange={v => { setPassword(v); setErrorState('none') }}
                error={errorState === 'wrong-password' ? "Incorrect password. Please try again." : undefined}
              />
              <div style={{ marginTop: 8, textAlign: 'right' }}>
                <Link to="/forgot-password" style={{ fontSize: 12, color: t.inkMuted, textDecoration: 'underline' }}>
                  Forgot password?
                </Link>
              </div>
            </div>

            <Hairline />

            <Btn type="submit" variant="primary">Sign in</Btn>

            <p style={{ fontSize: 13, color: t.inkMuted }}>
              New to ArtWall?{' '}
              <Link to="/sign-up" style={{ color: t.ink, fontWeight: 500, textDecoration: 'underline' }}>Create account</Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  )
}
