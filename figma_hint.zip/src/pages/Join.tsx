import { useState } from 'react'
import { t } from '../components/tokens'
import { Eyebrow, Hairline } from '../components/ui'

export default function Join() {
  const [email, setEmail] = useState('')
  const [medium, setMedium] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) setSubmitted(true)
  }

  return (
    <div style={{ background: t.wallPaper, minHeight: '100vh', paddingTop: 96 }}>
      {/* Page header */}
      <div style={{ background: t.band, borderBottom: `1px solid ${t.hairline}`, padding: '48px 64px' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto' }}>
          <div style={{ marginBottom: 16 }}>
            <Eyebrow chapter="07" label="Founding cohort" />
          </div>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 'clamp(32px, 4vw, 52px)', fontWeight: 500, letterSpacing: '-0.03em', lineHeight: 1.1, color: t.ink, maxWidth: 640 }}>
            Be part of what India's art ecosystem becomes.
          </h1>
        </div>
      </div>

      <div style={{ maxWidth: 1240, margin: '0 auto', padding: '64px 64px 96px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, alignItems: 'start' }}>
        {/* Left — argument */}
        <div>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 17, lineHeight: 1.7, color: t.inkMuted, marginBottom: 40, maxWidth: 480 }}>
            The founding cohort is a numbered, permanent set. Your artist number is part of your provenance record — it stays on every certificate you ever issue. There is no waitlist for a later round. This is the round.
          </p>

          <div style={{ marginBottom: 48, display: 'flex', flexDirection: 'column', gap: 20 }}>
            {[
              { n: '01', title: 'Permanent founding member number', body: 'On every certificate you issue, forever. A number that says you were here before this became obvious.' },
              { n: '02', title: 'Full Studio access, free for year one', body: 'Catalogue, provenance, invoices, certificates — everything, at no cost while we build alongside you.' },
              { n: '03', title: 'Priority wall booking', body: 'First access to Physical Wall slots in Jaipur, and every city we open next.' },
              { n: '04', title: 'Inaugural community exhibition', body: 'Your works in the first ArtWall Labs exhibition — documented, certificated, permanent.' },
              { n: '05', title: 'Direct input into product direction', body: 'Monthly calls with the team. Your practice shapes what gets built next.' },
            ].map(b => (
              <div key={b.n} style={{ display: 'flex', gap: 16, paddingBottom: 20, borderBottom: `1px solid ${t.hairline}` }}>
                <span style={{ fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 500, color: t.signal, letterSpacing: '0.1em', minWidth: 24, marginTop: 3 }}>{b.n}</span>
                <div>
                  <div style={{ fontFamily: 'var(--font-sans)', fontSize: 14, fontWeight: 500, color: t.ink, marginBottom: 4 }}>{b.title}</div>
                  <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, lineHeight: 1.6 }}>{b.body}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Quote */}
          <div style={{ borderLeft: `2px solid ${t.hairline}`, paddingLeft: 24 }}>
            <blockquote style={{ fontFamily: 'var(--font-heading)', fontSize: 18, fontStyle: 'italic', fontWeight: 400, color: t.ink, lineHeight: 1.55, marginBottom: 12 }}>
              "I joined because my practice deserved infrastructure, not charity."
            </blockquote>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted }}>Kavya Singh · Founding member #0007 · Mumbai</div>
          </div>
        </div>

        {/* Right — form */}
        <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, padding: '40px 36px', position: 'sticky', top: 80 }}>
          {submitted ? (
            <div style={{ textAlign: 'center', padding: '40px 0' }}>
              <div style={{ width: 52, height: 52, borderRadius: '50%', border: `1.5px solid ${t.signal}`, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px', color: t.signal, fontSize: 22 }}>✓</div>
              <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: 26, fontWeight: 500, letterSpacing: '-0.015em', color: t.ink, marginBottom: 12 }}>{"You're on the list."}</h3>
              <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, lineHeight: 1.65 }}>
                {"We'll send your founding number and next steps to"} <strong>{email}</strong> {"within 48 hours."}
              </p>
            </div>
          ) : (
            <>
              <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: 24, fontWeight: 500, letterSpacing: '-0.015em', color: t.ink, marginBottom: 6 }}>
                Join the founding cohort
              </h3>
              <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 28, lineHeight: 1.6 }}>
                Open to artists based in India. No fee to register.
              </p>

              <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {[
                  { label: 'Full name', type: 'text', ph: 'Priya Mehta' },
                  { label: 'Email address', type: 'email', ph: 'priya@example.com' },
                  { label: 'City', type: 'text', ph: 'Jaipur' },
                ].map(f => (
                  <div key={f.label}>
                    <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>{f.label}</label>
                    <input
                      type={f.type}
                      placeholder={f.ph}
                      required={f.type === 'email'}
                      value={f.type === 'email' ? email : undefined}
                      onChange={f.type === 'email' ? e => setEmail(e.target.value) : undefined}
                      style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: t.ink, background: t.band, border: `1px solid ${t.hairlineStrong}`, borderRadius: 4, outline: 'none' }}
                      onFocus={e => (e.currentTarget.style.borderColor = t.ink)}
                      onBlur={e => (e.currentTarget.style.borderColor = t.hairlineStrong)}
                    />
                  </div>
                ))}

                <div>
                  <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>Primary medium</label>
                  <select value={medium} onChange={e => setMedium(e.target.value)} style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, color: medium ? t.ink : t.inkMuted, background: t.band, border: `1px solid ${t.hairlineStrong}`, borderRadius: 4, outline: 'none', appearance: 'none', cursor: 'pointer' }}>
                    <option value="" disabled>Select a medium</option>
                    {['Painting', 'Sculpture', 'Photography', 'Mixed media', 'Printmaking', 'Drawing', 'Digital', 'Textile', 'Other'].map(m => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>

                <div style={{ borderTop: `1px solid ${t.hairline}`, paddingTop: 16, display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <label style={{ display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer' }}>
                    <input type="checkbox" required style={{ marginTop: 2, accentColor: t.ink, width: 14, height: 14, flexShrink: 0 }} />
                    <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, lineHeight: 1.55 }}>
                      I consent to ArtWall Labs storing my registration information to process my application. I can withdraw this at any time.{' '}
                      <a href="/physical-wall/account" style={{ color: t.ink }}>Privacy notice</a>
                    </span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer' }}>
                    <input type="checkbox" style={{ marginTop: 2, accentColor: t.ink, width: 14, height: 14, flexShrink: 0 }} />
                    <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, lineHeight: 1.55 }}>
                      {"I'd like to receive updates about the platform and community events."} <em>(Optional)</em>
                    </span>
                  </label>
                </div>

                <button type="submit" style={{ fontFamily: 'var(--font-sans)', fontSize: 14, fontWeight: 500, color: t.wallPaper, background: t.ink, border: 'none', borderRadius: 4, padding: '13px 24px', cursor: 'pointer', letterSpacing: '-0.01em', transition: 'background 0.15s', marginTop: 4 }}
                  onMouseEnter={e => (e.currentTarget.style.background = t.emberGlow)}
                  onMouseLeave={e => (e.currentTarget.style.background = t.ink)}
                >
                  Request founding membership
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
