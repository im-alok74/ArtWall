import { useState } from 'react';
import { Link } from 'react-router';
import { t } from '../components/tokens';
import { Eyebrow, Hairline, Btn, PageShell } from '../components/ui';

const filters = ['All', 'Painting', 'Photography', 'Sculpture', 'Mixed Media'];

const artworks = [
  { id: 1, title: "Amber at Dawn", artist: "Priya Mehta", medium: "Painting", photo: "1535056626760-b283260686b1", h: 360 },
  { id: 2, title: "Shore Memory XII", artist: "Arjun Nair", medium: "Photography", photo: "1685643096239-9b517edf150f", h: 280 },
  { id: 3, title: "Terracotta Study", artist: "Sunita Rao", medium: "Sculpture", photo: "1772987020530-4ceac482c95a", h: 320 },
  { id: 4, title: "Gallery Evening", artist: "Dev Kapoor", medium: "Painting", photo: "1778975144951-ea2a990c4ab4", h: 240 },
  { id: 5, title: "Market Morning", artist: "Ravi Sharma", medium: "Painting", photo: "1758380388480-6f329811c09b", h: 300 },
  { id: 6, title: "Old City Light", artist: "Lakshmi Patel", medium: "Photography", photo: "1768366778536-f4e32064cc2c", h: 360 },
  { id: 7, title: "Haveli Interior", artist: "Priya Mehta", medium: "Painting", photo: "1766890410688-77af00a1dc41", h: 220 },
  { id: 8, title: "The Collectors", artist: "Vikram Das", medium: "Painting", photo: "1780933333107-903b8c065b4d", h: 280 },
  { id: 9, title: "Lit Frames", artist: "Arjun Nair", medium: "Photography", photo: "1764922168474-8048361bc764", h: 340 },
  { id: 10, title: "Abstract Pair", artist: "Meera Krishnan", medium: "Mixed Media", photo: "1776671158741-ebe753d7fcf4", h: 260 },
  { id: 11, title: "Framed Study", artist: "Ananya Singh", medium: "Painting", photo: "1758718036458-a7e88219dbd4", h: 300 },
  { id: 12, title: "Evening Gallery", artist: "Sanjay Gupta", medium: "Photography", photo: "1785798696332-54bc5400ad3f", h: 360 },
  { id: 13, title: "Warm Interior", artist: "Divya Iyer", medium: "Painting", photo: "1685643096239-9b517edf150f", h: 240 },
  { id: 14, title: "Portrait Study", artist: "Kabir Malhotra", medium: "Mixed Media", photo: "1535056626760-b283260686b1", h: 320 },
  { id: 15, title: "Golden Hour", artist: "Priya Mehta", medium: "Painting", photo: "1772987020530-4ceac482c95a", h: 280 },
  { id: 16, title: "Wall Archive", artist: "Ravi Sharma", medium: "Painting", photo: "1778975144951-ea2a990c4ab4", h: 360 },
  { id: 17, title: "QR Wall Study", artist: "Dev Kapoor", medium: "Photography", photo: "1758380388480-6f329811c09b", h: 220 },
  { id: 18, title: "Skylight Hall", artist: "Vikram Das", medium: "Painting", photo: "1768366778536-f4e32064cc2c", h: 300 },
  { id: 19, title: "Spotlight Pair", artist: "Lakshmi Patel", medium: "Photography", photo: "1766890410688-77af00a1dc41", h: 340 },
  { id: 20, title: "Brushwork Study", artist: "Sunita Rao", medium: "Mixed Media", photo: "1780933333107-903b8c065b4d", h: 260 },
];

type Artwork = typeof artworks[number];

export default function WallDigital() {
  const [activeFilter, setActiveFilter] = useState('All');
  const [selectedArtwork, setSelectedArtwork] = useState<Artwork | null>(null);

  const filtered = activeFilter === 'All'
    ? artworks
    : artworks.filter((w) => w.medium === activeFilter);

  return (
    <PageShell>
      {/* Page Header */}
      <section style={{ marginBottom: 48 }}>
        <Eyebrow chapter="07" label="Wall" />
        <h1
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: 48,
            fontWeight: 500,
            color: t.ink,
            margin: '16px 0 24px',
            lineHeight: 1.15,
          }}
        >
          The Digital Wall
        </h1>
        <p
          style={{
            fontFamily: 'var(--font-sans)',
            fontSize: 18,
            color: t.inkMuted,
            maxWidth: 640,
            lineHeight: 1.7,
            margin: 0,
          }}
        >
          Every artwork currently exhibited across ArtWall's physical venues — in one place. Click
          any work to see its provenance, artist, and enquiry options.
        </p>
      </section>

      <Hairline />

      {/* Filter chips */}
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          gap: 8,
          marginTop: 32,
          marginBottom: 40,
        }}
      >
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setActiveFilter(f)}
            style={{
              background: activeFilter === f ? t.ink : 'none',
              color: activeFilter === f ? t.wallPaper : t.inkMuted,
              border: `1px solid ${activeFilter === f ? t.ink : t.hairline}`,
              borderRadius: 4,
              padding: '6px 16px',
              cursor: 'pointer',
              fontFamily: 'var(--font-sans)',
              fontSize: 13,
            }}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Masonry grid */}
      <div
        style={{
          columnCount: 3,
          columnGap: 16,
        }}
      >
        {filtered.map((w) => (
          <div
            key={w.id}
            onClick={() => setSelectedArtwork(w)}
            style={{
              breakInside: 'avoid',
              marginBottom: 16,
              border: `1px solid ${t.hairline}`,
              borderRadius: 4,
              overflow: 'hidden',
              cursor: 'pointer',
            }}
          >
            <img
              src={`https://images.unsplash.com/photo-${w.photo}?w=600&h=${w.h}&fit=crop&auto=format`}
              alt={w.title}
              style={{ width: '100%', height: w.h, objectFit: 'cover', display: 'block' }}
            />
            <div style={{ padding: 12 }}>
              <div
                style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 12,
                  color: t.inkMuted,
                  marginBottom: 4,
                }}
              >
                {w.artist}
              </div>
              <div
                style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 13,
                  fontWeight: 500,
                  color: t.ink,
                  marginBottom: 4,
                }}
              >
                {w.title}
              </div>
              <div
                style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 11,
                  color: t.inkMuted,
                }}
              >
                {w.medium}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Detail Dialog */}
      {selectedArtwork && (
        <div
          onClick={() => setSelectedArtwork(null)}
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(12,15,29,0.6)',
            zIndex: 200,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              background: t.wallPaper,
              maxWidth: 480,
              width: '90%',
              padding: 40,
              borderRadius: 4,
              border: `1px solid ${t.hairline}`,
              position: 'relative',
            }}
          >
            <button
              onClick={() => setSelectedArtwork(null)}
              style={{
                position: 'absolute',
                top: 16,
                right: 16,
                cursor: 'pointer',
                fontSize: 20,
                fontFamily: 'var(--font-sans)',
                background: 'none',
                border: 'none',
                color: t.inkMuted,
                lineHeight: 1,
                padding: 0,
              }}
            >
              ×
            </button>

            <img
              src={`https://images.unsplash.com/photo-${selectedArtwork.photo}?w=600&h=280&fit=crop&auto=format`}
              alt={selectedArtwork.title}
              style={{ width: '100%', height: 280, objectFit: 'cover', display: 'block', borderRadius: 4, marginBottom: 24 }}
            />

            <h2
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 24,
                fontWeight: 500,
                color: t.ink,
                margin: '0 0 8px',
              }}
            >
              {selectedArtwork.title}
            </h2>
            <div
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 14,
                color: t.inkMuted,
                marginBottom: 4,
              }}
            >
              {selectedArtwork.artist}
            </div>
            <div
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 13,
                color: t.inkMuted,
                marginBottom: 20,
              }}
            >
              {selectedArtwork.medium}
            </div>

            <Hairline />

            <div style={{ marginTop: 20, marginBottom: 20 }}>
              <Link
                to="/certificate"
                style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 14,
                  color: t.signal,
                  textDecoration: 'none',
                }}
              >
                View provenance certificate
              </Link>
            </div>

            <Btn href="/contact">Enquire</Btn>
          </div>
        </div>
      )}
    </PageShell>
  );
}
