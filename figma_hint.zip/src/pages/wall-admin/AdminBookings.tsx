import { useState } from 'react'
import { t } from '../../components/tokens'
import { Badge, Btn } from '../../components/ui'

type BookingStatus = 'held' | 'paid' | 'live' | 'cancelled' | 'pending'

interface Booking {
  ref: string
  artist: string
  slot: string
  dates: string
  artwork: string
  status: BookingStatus
  amount: string
}

const INITIAL: Booking[] = [
  { ref: 'AWL-2025-0842', artist: 'Meera Iyer', slot: 'A3', dates: 'Jan 15 – Jan 28', artwork: "Monsoon Light III", status: 'pending', amount: '₹4,200' },
  { ref: 'AWL-2025-0841', artist: 'Rohan Das', slot: 'B2', dates: 'Jan 12 – Jan 25', artwork: "City at Rest", status: 'paid', amount: '₹3,600' },
  { ref: 'AWL-2025-0840', artist: 'Priya Mehta', slot: 'C1', dates: 'Jan 20 – Feb 3', artwork: "Still — Garden #4", status: 'live', amount: '₹4,800' },
  { ref: 'AWL-2025-0839', artist: 'Ankit Rao', slot: 'D4', dates: 'Jan 8 – Jan 18', artwork: "Red Ground", status: 'held', amount: '₹2,800' },
  { ref: 'AWL-2025-0838', artist: 'Sunita Joshi', slot: 'A1', dates: 'Jan 1 – Jan 14', artwork: "Dawn Sequence", status: 'live', amount: '₹3,900' },
  { ref: 'AWL-2025-0837', artist: 'Kiran Patel', slot: 'B5', dates: 'Jan 3 – Jan 16', artwork: "Terrazzo I", status: 'paid', amount: '₹3,600' },
  { ref: 'AWL-2025-0836', artist: 'Nandini Rao', slot: 'C3', dates: 'Jan 5 – Jan 19', artwork: "Untitled (Blue)", status: 'held', amount: '₹4,200' },
  { ref: 'AWL-2025-0835', artist: 'Vikram Singh', slot: 'D2', dates: 'Dec 28 – Jan 10', artwork: "Evening Wash", status: 'cancelled', amount: '₹3,600' },
  { ref: 'AWL-2025-0834', artist: 'Leela Nambiar', slot: 'A5', dates: 'Jan 10 – Jan 24', artwork: "Form Study #7", status: 'live', amount: '₹4,800' },
  { ref: 'AWL-2025-0833', artist: 'Arjun Menon', slot: 'B1', dates: 'Jan 14 – Jan 28', artwork: "Passage", status: 'paid', amount: '₹3,200' },
]

function statusBadge(s: BookingStatus) {
  const map: Record<BookingStatus, Parameters<typeof Badge>[0]['color']> = {
    live: 'live',
    paid: 'live',
    held: 'held',
    pending: 'held',
    cancelled: 'ended',
  }
  const labels: Record<BookingStatus, string> = {
    live: 'Live', paid: 'Paid', held: 'Held', pending: 'Pending', cancelled: 'Cancelled',
  }
  return <Badge label={labels[s]} color={map[s]} />
}

export default function AdminBookings() {
  const [bookings, setBookings] = useState<Booking[]>(INITIAL)
  const [releaseTarget, setReleaseTarget] = useState<string | null>(null)
  const [reason, setReason] = useState('')
  const [confirmText, setConfirmText] = useState('')

  function markPaid(ref: string) {
    setBookings(bs => bs.map(b => b.ref === ref ? { ...b, status: 'paid' } : b))
  }

  function forceRelease() {
    if (!releaseTarget) return
    setBookings(bs => bs.map(b => b.ref === releaseTarget ? { ...b, status: 'cancelled' } : b))
    setReleaseTarget(null)
    setReason('')
    setConfirmText('')
  }

  const thStyle: React.CSSProperties = {
    fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 600, color: t.inkMuted,
    letterSpacing: '0.04em', textTransform: 'uppercase', padding: '10px 14px',
    textAlign: 'left', whiteSpace: 'nowrap',
    borderBottom: `1px solid ${t.hairline}`,
  }
  const tdStyle: React.CSSProperties = {
    fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink,
    padding: '12px 14px', borderBottom: `1px solid ${t.hairline}`,
    verticalAlign: 'middle',
  }

  return (
    <div>
      <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500, color: t.ink, letterSpacing: '-0.025em', marginBottom: 24 }}>
        Bookings
      </h1>

      <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: t.band }}>
              <th style={thStyle}>Ref</th>
              <th style={thStyle}>Artist</th>
              <th style={thStyle}>Slot</th>
              <th style={thStyle}>Dates</th>
              <th style={thStyle}>Artwork</th>
              <th style={thStyle}>Status</th>
              <th style={thStyle}>Amount</th>
              <th style={thStyle}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map(b => (
              <tr key={b.ref} style={{ transition: 'background 0.1s' }}
                onMouseEnter={e => (e.currentTarget.style.background = t.band)}
                onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
              >
                <td style={{ ...tdStyle, fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted, letterSpacing: '0.02em', whiteSpace: 'nowrap' }}>{b.ref}</td>
                <td style={{ ...tdStyle, fontWeight: 500 }}>{b.artist}</td>
                <td style={{ ...tdStyle, fontWeight: 600 }}>{b.slot}</td>
                <td style={{ ...tdStyle, whiteSpace: 'nowrap', color: t.inkMuted }}>{b.dates}</td>
                <td style={tdStyle}>{b.artwork}</td>
                <td style={tdStyle}>{statusBadge(b.status)}</td>
                <td style={{ ...tdStyle, fontFamily: 'var(--font-heading)', fontSize: 14, whiteSpace: 'nowrap' }}>{b.amount}</td>
                <td style={{ ...tdStyle, whiteSpace: 'nowrap' }}>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    {(b.status === 'held' || b.status === 'pending') && (
                      <Btn variant="quiet" onClick={() => markPaid(b.ref)}>Mark paid</Btn>
                    )}
                    {b.status !== 'cancelled' && (
                      <Btn variant="danger" onClick={() => setReleaseTarget(b.ref)}>Force release</Btn>
                    )}
                    <a href="#" style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.signal, textDecoration: 'none' }}>View</a>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Force release modal */}
      {releaseTarget && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(12,15,29,0.5)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          onClick={e => { if (e.target === e.currentTarget) setReleaseTarget(null) }}
        >
          <div style={{ background: t.wallPaper, borderRadius: 4, padding: 32, width: 440, maxWidth: '90vw' }}>
            <div style={{ fontFamily: 'var(--font-heading)', fontSize: 20, fontWeight: 500, color: t.ink, marginBottom: 12 }}>
              Force release booking
            </div>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, lineHeight: 1.6, marginBottom: 20 }}>
              This will cancel the booking and notify the artist. You must enter a reason.
            </div>

            <div style={{ marginBottom: 16 }}>
              <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>Reason</label>
              <textarea
                value={reason}
                onChange={e => setReason(e.target.value)}
                rows={3}
                placeholder="Reason for cancellation..."
                style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', resize: 'vertical', boxSizing: 'border-box' }}
              />
            </div>

            <div style={{ marginBottom: 20 }}>
              <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.destructive, display: 'block', marginBottom: 6 }}>
                Type RELEASE to confirm
              </label>
              <input
                type="text"
                value={confirmText}
                onChange={e => setConfirmText(e.target.value)}
                placeholder="RELEASE"
                style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, background: t.band, border: `1px solid ${t.destructive}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box' }}
              />
            </div>

            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <Btn variant="quiet" onClick={() => setReleaseTarget(null)}>Cancel</Btn>
              <Btn variant="danger" disabled={confirmText !== 'RELEASE' || !reason.trim()} onClick={forceRelease}>
                Force release
              </Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
