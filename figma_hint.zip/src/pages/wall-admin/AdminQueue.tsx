import { useState, useRef } from 'react'
import { t } from '../../components/tokens'
import { Btn } from '../../components/ui'

interface QueueEntry {
  id: number
  name: string
  email: string
  size: string
  months: string
  joined: string
  note: string
}

const INITIAL: QueueEntry[] = [
  { id: 1, name: 'Rajan Pillai', email: 'rajan@studio.in', size: 'Medium', months: 'Feb, Mar', joined: 'Dec 12', note: '' },
  { id: 2, name: 'Anika Khanna', email: 'anika@khanna.art', size: 'Large', months: 'Feb', joined: 'Dec 14', note: '' },
  { id: 3, name: 'Dev Menon', email: 'dev@devmenon.com', size: 'Small', months: 'Mar, Apr', joined: 'Dec 18', note: 'Wants corner slot if possible' },
  { id: 4, name: 'Pallavi Das', email: 'pallavi@das.in', size: 'XL', months: 'Feb', joined: 'Dec 20', note: '' },
  { id: 5, name: 'Suresh Nambiar', email: 'suresh@art.in', size: 'Medium', months: 'Apr', joined: 'Dec 22', note: '' },
  { id: 6, name: 'Tara Bose', email: 'tara@bosequeries.in', size: 'Large', months: 'Mar', joined: 'Dec 28', note: 'Preferred: A row' },
  { id: 7, name: 'Girish Tiwari', email: 'girish@tiwari.co', size: 'Small', months: 'Feb, Mar, Apr', joined: 'Jan 2', note: '' },
  { id: 8, name: 'Nalini Bhat', email: 'nalini@nbhat.in', size: 'Medium', months: 'May', joined: 'Jan 5', note: '' },
  { id: 9, name: 'Sanjeev Iyer', email: 'sanjeev@iyer.art', size: 'Large', months: 'Mar', joined: 'Jan 6', note: '' },
  { id: 10, name: 'Chitra Gupta', email: 'chitra@studiogupta.in', size: 'XL', months: 'Apr, May', joined: 'Jan 8', note: '' },
  { id: 11, name: 'Mohan Kumar', email: 'mohan@mkunstudio.in', size: 'Medium', months: 'Mar', joined: 'Jan 9', note: 'Has shown interest in 2 slots' },
  { id: 12, name: 'Rekha Jain', email: 'rekha@jainarts.in', size: 'Small', months: 'May', joined: 'Jan 11', note: '' },
]

const SLOTS = ['A1','A2','A3','A4','A5','A6','B1','B2','B3','B4','B5','B6','C1','C2','C3','C4','C5','C6','D1','D2','D3','D4','D5','D6']

export default function AdminQueue() {
  const [entries, setEntries] = useState<QueueEntry[]>(INITIAL)
  const [noteOpen, setNoteOpen] = useState<number | null>(null)
  const [noteText, setNoteText] = useState('')
  const [removeConfirm, setRemoveConfirm] = useState<number | null>(null)
  const [offerOpen, setOfferOpen] = useState<number | null>(null)
  const [selectedSlot, setSelectedSlot] = useState('')

  function promote(id: number) {
    setEntries(es => {
      const idx = es.findIndex(e => e.id === id)
      if (idx <= 0) return es
      const next = [...es]
      ;[next[idx - 1], next[idx]] = [next[idx], next[idx - 1]]
      return next
    })
  }

  function demote(id: number) {
    setEntries(es => {
      const idx = es.findIndex(e => e.id === id)
      if (idx >= es.length - 1) return es
      const next = [...es]
      ;[next[idx], next[idx + 1]] = [next[idx + 1], next[idx]]
      return next
    })
  }

  function saveNote(id: number) {
    setEntries(es => es.map(e => e.id === id ? { ...e, note: noteText } : e))
    setNoteOpen(null)
  }

  function remove(id: number) {
    setEntries(es => es.filter(e => e.id !== id))
    setRemoveConfirm(null)
  }

  const thStyle: React.CSSProperties = {
    fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 600, color: t.inkMuted,
    letterSpacing: '0.04em', textTransform: 'uppercase', padding: '10px 14px',
    textAlign: 'left', whiteSpace: 'nowrap', borderBottom: `1px solid ${t.hairline}`,
  }
  const tdStyle: React.CSSProperties = {
    fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink,
    padding: '12px 14px', borderBottom: `1px solid ${t.hairline}`,
    verticalAlign: 'middle',
  }

  return (
    <div>
      <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500, color: t.ink, letterSpacing: '-0.025em', marginBottom: 24 }}>
        Queue
      </h1>

      <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: t.band }}>
              <th style={{ ...thStyle, width: 40 }}>#</th>
              <th style={thStyle}>Name</th>
              <th style={thStyle}>Email</th>
              <th style={thStyle}>Size</th>
              <th style={thStyle}>Months</th>
              <th style={thStyle}>Joined</th>
              <th style={thStyle}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {entries.map((e, i) => (
              <tr key={e.id}
                onMouseEnter={ev => (ev.currentTarget.style.background = t.band)}
                onMouseLeave={ev => (ev.currentTarget.style.background = 'transparent')}
              >
                <td style={{ ...tdStyle, fontWeight: 600, color: t.inkMuted, textAlign: 'center' }}>{i + 1}</td>
                <td style={{ ...tdStyle, fontWeight: 500 }}>
                  {e.name}
                  {e.note && (
                    <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted, marginTop: 2 }}>
                      {e.note}
                    </div>
                  )}
                </td>
                <td style={{ ...tdStyle, color: t.inkMuted }}>{e.email}</td>
                <td style={tdStyle}>{e.size}</td>
                <td style={{ ...tdStyle, color: t.inkMuted }}>{e.months}</td>
                <td style={{ ...tdStyle, color: t.inkMuted, whiteSpace: 'nowrap' }}>{e.joined}</td>
                <td style={{ ...tdStyle, whiteSpace: 'nowrap' }}>
                  <div style={{ display: 'flex', gap: 4, alignItems: 'center', flexWrap: 'wrap' }}>
                    <button
                      onClick={() => promote(e.id)}
                      disabled={i === 0}
                      title="Promote"
                      style={{ border: `1px solid ${t.hairline}`, background: 'none', cursor: i === 0 ? 'not-allowed' : 'pointer', borderRadius: 4, padding: '4px 8px', fontSize: 13, opacity: i === 0 ? 0.3 : 1 }}
                    >↑</button>
                    <button
                      onClick={() => demote(e.id)}
                      disabled={i === entries.length - 1}
                      title="Demote"
                      style={{ border: `1px solid ${t.hairline}`, background: 'none', cursor: i === entries.length - 1 ? 'not-allowed' : 'pointer', borderRadius: 4, padding: '4px 8px', fontSize: 13, opacity: i === entries.length - 1 ? 0.3 : 1 }}
                    >↓</button>
                    <button
                      onClick={() => { setNoteOpen(e.id); setNoteText(e.note) }}
                      title="Note"
                      style={{ border: `1px solid ${t.hairline}`, background: 'none', cursor: 'pointer', borderRadius: 4, padding: '4px 8px', fontSize: 13 }}
                    >📋</button>
                    <button
                      onClick={() => setRemoveConfirm(e.id)}
                      title="Remove"
                      style={{ border: `1px solid ${t.hairline}`, background: 'none', cursor: 'pointer', borderRadius: 4, padding: '4px 8px', fontSize: 13, color: t.destructive }}
                    >✕</button>
                    <Btn variant="quiet" onClick={() => { setOfferOpen(e.id); setSelectedSlot('') }}>Offer slot</Btn>
                  </div>

                  {/* Note popover */}
                  {noteOpen === e.id && (
                    <div style={{ position: 'absolute', zIndex: 50, background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, padding: 16, width: 260, marginTop: 8, boxShadow: '0 4px 16px rgba(0,0,0,0.1)' }}>
                      <textarea
                        autoFocus
                        value={noteText}
                        onChange={ev => setNoteText(ev.target.value)}
                        rows={3}
                        placeholder="Note about this artist..."
                        style={{ width: '100%', padding: '8px 10px', fontFamily: 'var(--font-sans)', fontSize: 12, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', resize: 'none', boxSizing: 'border-box', marginBottom: 8 }}
                      />
                      <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                        <Btn variant="ghost" onClick={() => setNoteOpen(null)}>Cancel</Btn>
                        <Btn onClick={() => saveNote(e.id)}>Save</Btn>
                      </div>
                    </div>
                  )}

                  {/* Offer slot */}
                  {offerOpen === e.id && (
                    <div style={{ position: 'absolute', zIndex: 50, background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, padding: 16, width: 220, marginTop: 8, boxShadow: '0 4px 16px rgba(0,0,0,0.1)' }}>
                      <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, marginBottom: 8 }}>Select slot</div>
                      <select
                        value={selectedSlot}
                        onChange={ev => setSelectedSlot(ev.target.value)}
                        style={{ width: '100%', padding: '8px 10px', fontFamily: 'var(--font-sans)', fontSize: 12, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', marginBottom: 10 }}
                      >
                        <option value="">Choose slot...</option>
                        {SLOTS.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                      <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                        <Btn variant="ghost" onClick={() => setOfferOpen(null)}>Cancel</Btn>
                        <Btn disabled={!selectedSlot} onClick={() => setOfferOpen(null)}>Send offer</Btn>
                      </div>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Remove confirmation */}
      {removeConfirm !== null && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(12,15,29,0.5)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          onClick={e => { if (e.target === e.currentTarget) setRemoveConfirm(null) }}
        >
          <div style={{ background: t.wallPaper, borderRadius: 4, padding: 28, width: 360, maxWidth: '90vw' }}>
            <div style={{ fontFamily: 'var(--font-heading)', fontSize: 18, fontWeight: 500, color: t.ink, marginBottom: 12 }}>
              Remove from queue?
            </div>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted, marginBottom: 20 }}>
              {entries.find(e => e.id === removeConfirm)?.name} will be removed from the waitlist.
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <Btn variant="quiet" onClick={() => setRemoveConfirm(null)}>Cancel</Btn>
              <Btn variant="danger" onClick={() => remove(removeConfirm)}>Remove</Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
