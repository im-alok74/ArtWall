import { useState } from 'react'
import { t } from '../../components/tokens'
import { Btn } from '../../components/ui'

function MetricCard({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div style={{
      background: t.wallPaper,
      border: `1px solid ${t.hairline}`,
      borderRadius: 4,
      padding: '24px 28px',
    }}>
      <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: 10 }}>
        {label}
      </div>
      <div style={{ fontFamily: 'var(--font-heading)', fontSize: 36, fontWeight: 500, color: t.ink, letterSpacing: '-0.03em', lineHeight: 1 }}>
        {value}
      </div>
      {sub && <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginTop: 6 }}>{sub}</div>}
    </div>
  )
}

const ALERTS = [
  {
    id: 1,
    text: 'Booking AWL-2025-0842: payment overdue by 3 days',
    action: 'Mark paid',
    variant: 'primary' as const,
  },
  {
    id: 2,
    text: 'Slot C4: 3-day gap between bookings (Jan 28 – Jan 31)',
    action: 'Fill gap',
    variant: 'quiet' as const,
  },
  {
    id: 3,
    text: "Artist Priya Mehta: agreement not signed, install in 2 days",
    action: 'Contact',
    variant: 'quiet' as const,
  },
  {
    id: 4,
    text: 'Booking AWL-2025-0839: artwork not received',
    action: 'Follow up',
    variant: 'quiet' as const,
  },
]

const READINESS = [
  { ok: true, label: 'Wall configured (24 slots)' },
  { ok: true, label: 'Payment gateway connected' },
  { ok: false, label: 'Refund policy not published' },
  { ok: true, label: 'Staff accounts created' },
  { ok: false, label: 'QR poster template not finalised' },
]

export default function AdminOverview() {
  const [dismissed, setDismissed] = useState<Set<number>>(new Set())

  return (
    <div>
      <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500, color: t.ink, letterSpacing: '-0.025em', marginBottom: 28 }}>
        Overview
      </h1>

      {/* Metric cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16, marginBottom: 36 }}>
        <MetricCard label="Active bookings" value="8" />
        <MetricCard label="Slots occupied" value="10/24" sub="14 available" />
        <MetricCard label="Revenue this month" value="₹38,400" />
        <MetricCard label="Queue length" value="12" sub="artists waiting" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 24, alignItems: 'start' }}>
        {/* Needs you */}
        <div>
          <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: t.ink, letterSpacing: '-0.01em', marginBottom: 14 }}>
            Needs you
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0, background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4 }}>
            {ALERTS.filter(a => !dismissed.has(a.id)).map((alert, i, arr) => (
              <div
                key={alert.id}
                style={{
                  padding: '16px 20px',
                  borderBottom: i < arr.length - 1 ? `1px solid ${t.hairline}` : 'none',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: 16,
                }}
              >
                <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, lineHeight: 1.5, flex: 1 }}>
                  {alert.text}
                </div>
                <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
                  <Btn variant={alert.variant} onClick={() => setDismissed(s => new Set([...s, alert.id]))}>
                    {alert.action}
                  </Btn>
                </div>
              </div>
            ))}
            {dismissed.size === ALERTS.length && (
              <div style={{ padding: '24px 20px', textAlign: 'center', fontFamily: 'var(--font-sans)', fontSize: 13, color: t.inkMuted }}>
                All items resolved
              </div>
            )}
          </div>
        </div>

        {/* Launch readiness */}
        <div>
          <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: t.ink, letterSpacing: '-0.01em', marginBottom: 14 }}>
            Launch readiness
          </div>
          <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4 }}>
            {READINESS.map((item, i) => (
              <div
                key={i}
                style={{
                  padding: '12px 20px',
                  borderBottom: i < READINESS.length - 1 ? `1px solid ${t.hairline}` : 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 12,
                }}
              >
                <span style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 15,
                  color: item.ok ? '#166534' : t.destructive,
                  flexShrink: 0,
                }}>
                  {item.ok ? '✓' : '✗'}
                </span>
                <span style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: 13,
                  color: item.ok ? t.ink : t.inkMuted,
                  textDecoration: item.ok ? 'none' : 'none',
                }}>
                  {item.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
