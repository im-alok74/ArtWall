import { useState } from 'react'
import { t } from '../../components/tokens'
import { Btn } from '../../components/ui'

interface SizeRow {
  id: number
  name: string
  dimensions: string
  pricePerWeek: string
  editing: boolean
}

interface AddonRow {
  id: number
  name: string
  price: string
  available: boolean
}

const INITIAL_SIZES: SizeRow[] = [
  { id: 1, name: 'Small', dimensions: 'Up to 50 × 50 cm', pricePerWeek: '₹600', editing: false },
  { id: 2, name: 'Medium', dimensions: 'Up to 80 × 80 cm', pricePerWeek: '₹900', editing: false },
  { id: 3, name: 'Large', dimensions: 'Up to 120 × 120 cm', pricePerWeek: '₹1,400', editing: false },
  { id: 4, name: 'XL', dimensions: 'Up to 180 × 120 cm', pricePerWeek: '₹2,000', editing: false },
]

const INITIAL_ADDONS: AddonRow[] = [
  { id: 1, name: 'Hanging & installation', price: '₹800', available: true },
  { id: 2, name: 'Lighting spot', price: '₹400 / week', available: true },
  { id: 3, name: 'Artist label printing', price: '₹150', available: true },
  { id: 4, name: 'Packaging & crating', price: '₹600', available: false },
  { id: 5, name: 'Extended insurance', price: '₹300 / week', available: true },
  { id: 6, name: 'Photography session', price: '₹1,200', available: false },
]

const TABS = ['Sizes', 'Add-ons', 'Refund policy', 'Wall settings']

function SizesTab() {
  const [rows, setRows] = useState<SizeRow[]>(INITIAL_SIZES)
  const [editVals, setEditVals] = useState<Record<number, Partial<SizeRow>>>({})

  function startEdit(id: number) {
    const r = rows.find(r => r.id === id)!
    setEditVals(ev => ({ ...ev, [id]: { name: r.name, dimensions: r.dimensions, pricePerWeek: r.pricePerWeek } }))
    setRows(rs => rs.map(r => r.id === id ? { ...r, editing: true } : r))
  }

  function saveEdit(id: number) {
    const v = editVals[id] || {}
    setRows(rs => rs.map(r => r.id === id ? { ...r, ...v, editing: false } : r))
  }

  function addRow() {
    const id = Date.now()
    setRows(rs => [...rs, { id, name: 'New size', dimensions: '—', pricePerWeek: '₹0', editing: true }])
    setEditVals(ev => ({ ...ev, [id]: { name: 'New size', dimensions: '—', pricePerWeek: '₹0' } }))
  }

  const thS: React.CSSProperties = { fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 600, color: t.inkMuted, letterSpacing: '0.04em', textTransform: 'uppercase', padding: '10px 14px', textAlign: 'left', borderBottom: `1px solid ${t.hairline}` }
  const tdS: React.CSSProperties = { fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, padding: '10px 14px', borderBottom: `1px solid ${t.hairline}`, verticalAlign: 'middle' }

  return (
    <div>
      <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, overflowX: 'auto', marginBottom: 16 }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: t.band }}>
              <th style={thS}>Size name</th>
              <th style={thS}>Dimensions</th>
              <th style={thS}>Price / week</th>
              <th style={thS}></th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.id}>
                <td style={tdS}>
                  {r.editing ? (
                    <input value={editVals[r.id]?.name ?? r.name} onChange={e => setEditVals(ev => ({ ...ev, [r.id]: { ...ev[r.id], name: e.target.value } }))} style={{ padding: '6px 8px', fontFamily: 'var(--font-sans)', fontSize: 13, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', width: '100%', boxSizing: 'border-box' }} />
                  ) : r.name}
                </td>
                <td style={tdS}>
                  {r.editing ? (
                    <input value={editVals[r.id]?.dimensions ?? r.dimensions} onChange={e => setEditVals(ev => ({ ...ev, [r.id]: { ...ev[r.id], dimensions: e.target.value } }))} style={{ padding: '6px 8px', fontFamily: 'var(--font-sans)', fontSize: 13, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', width: '100%', boxSizing: 'border-box' }} />
                  ) : r.dimensions}
                </td>
                <td style={tdS}>
                  {r.editing ? (
                    <input value={editVals[r.id]?.pricePerWeek ?? r.pricePerWeek} onChange={e => setEditVals(ev => ({ ...ev, [r.id]: { ...ev[r.id], pricePerWeek: e.target.value } }))} style={{ padding: '6px 8px', fontFamily: 'var(--font-sans)', fontSize: 13, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', width: 120, boxSizing: 'border-box' }} />
                  ) : r.pricePerWeek}
                </td>
                <td style={{ ...tdS, textAlign: 'right' }}>
                  {r.editing ? (
                    <Btn onClick={() => saveEdit(r.id)}>Save</Btn>
                  ) : (
                    <Btn variant="quiet" onClick={() => startEdit(r.id)}>Edit</Btn>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Btn variant="quiet" onClick={addRow}>+ Add row</Btn>
    </div>
  )
}

function AddonsTab() {
  const [rows, setRows] = useState<AddonRow[]>(INITIAL_ADDONS)

  const thS: React.CSSProperties = { fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 600, color: t.inkMuted, letterSpacing: '0.04em', textTransform: 'uppercase', padding: '10px 14px', textAlign: 'left', borderBottom: `1px solid ${t.hairline}` }
  const tdS: React.CSSProperties = { fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, padding: '12px 14px', borderBottom: `1px solid ${t.hairline}`, verticalAlign: 'middle' }

  return (
    <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ background: t.band }}>
            <th style={thS}>Service</th>
            <th style={thS}>Price</th>
            <th style={thS}>Status</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id}>
              <td style={{ ...tdS, fontWeight: 500 }}>{r.name}</td>
              <td style={{ ...tdS, fontFamily: 'var(--font-heading)' }}>{r.price}</td>
              <td style={tdS}>
                <button
                  onClick={() => setRows(rs => rs.map(row => row.id === r.id ? { ...row, available: !row.available } : row))}
                  style={{
                    padding: '4px 12px', border: 'none', borderRadius: 4, cursor: 'pointer',
                    fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 600,
                    background: r.available ? '#dcfce7' : t.hairline,
                    color: r.available ? '#166534' : t.inkMuted,
                    transition: 'background 0.15s',
                  }}
                >
                  {r.available ? 'Available' : 'Unavailable'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function RefundTab() {
  const [policy, setPolicy] = useState(`Cancellations made 14 or more days before the booking start date are eligible for a full refund minus a ₹200 processing fee.

Cancellations made 7–13 days before the start date receive a 50% refund.

Cancellations made fewer than 7 days before the start date are non-refundable.

If ArtWall Labs cancels a booking for operational reasons, a full refund will be issued within 5–7 business days.

No refunds are issued once artwork has been installed.`)
  const [saved, setSaved] = useState(false)

  return (
    <div style={{ maxWidth: 640 }}>
      <textarea
        value={policy}
        onChange={e => { setPolicy(e.target.value); setSaved(false) }}
        rows={12}
        style={{ width: '100%', padding: '14px 16px', fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', resize: 'vertical', lineHeight: 1.7, boxSizing: 'border-box', marginBottom: 12 }}
      />
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <Btn onClick={() => setSaved(true)}>Save</Btn>
        {saved && <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: '#166534' }}>Saved · Last updated Jan 15, 2025</span>}
        {!saved && <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>Last updated Jan 15, 2025</span>}
      </div>
    </div>
  )
}

function WallSettingsTab() {
  const [form, setForm] = useState({
    wallName: 'ArtWall Labs — Bandra',
    address: '42 Hill Road, Bandra West, Mumbai 400050',
    hours: 'Mon–Sat 10:00 AM – 8:00 PM, Sun 11:00 AM – 6:00 PM',
    maxConcurrent: '24',
    gst: '27AABCA1234B1ZP',
  })
  const [saved, setSaved] = useState(false)

  function update(k: keyof typeof form, v: string) {
    setForm(f => ({ ...f, [k]: v }))
    setSaved(false)
  }

  const fieldStyle: React.CSSProperties = { width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', boxSizing: 'border-box' }

  return (
    <div style={{ maxWidth: 520, display: 'flex', flexDirection: 'column', gap: 18 }}>
      {([
        ['wallName', 'Wall name'],
        ['address', 'Address'],
        ['hours', 'Opening hours'],
        ['maxConcurrent', 'Max concurrent bookings'],
        ['gst', 'GST registration number'],
      ] as [keyof typeof form, string][]).map(([k, label]) => (
        <div key={k}>
          <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>
            {label}
          </label>
          {k === 'address' ? (
            <textarea
              value={form[k]}
              onChange={e => update(k, e.target.value)}
              rows={2}
              style={{ ...fieldStyle, resize: 'none' }}
            />
          ) : (
            <input
              type="text"
              value={form[k]}
              onChange={e => update(k, e.target.value)}
              style={fieldStyle}
            />
          )}
        </div>
      ))}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <Btn onClick={() => setSaved(true)}>Save settings</Btn>
        {saved && <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: '#166534' }}>Saved</span>}
      </div>
    </div>
  )
}

export default function AdminCatalogs() {
  const [activeTab, setActiveTab] = useState(0)

  return (
    <div>
      <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500, color: t.ink, letterSpacing: '-0.025em', marginBottom: 24 }}>
        Catalogs
      </h1>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 0, borderBottom: `1px solid ${t.hairline}`, marginBottom: 28 }}>
        {TABS.map((tab, i) => (
          <button
            key={tab}
            onClick={() => setActiveTab(i)}
            style={{
              padding: '10px 20px',
              fontFamily: 'var(--font-sans)',
              fontSize: 13,
              fontWeight: activeTab === i ? 600 : 400,
              color: activeTab === i ? t.ink : t.inkMuted,
              background: 'none',
              border: 'none',
              borderBottom: activeTab === i ? `2px solid ${t.ink}` : '2px solid transparent',
              cursor: 'pointer',
              marginBottom: -1,
              transition: 'color 0.15s',
            }}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 0 && <SizesTab />}
      {activeTab === 1 && <AddonsTab />}
      {activeTab === 2 && <RefundTab />}
      {activeTab === 3 && <WallSettingsTab />}
    </div>
  )
}
