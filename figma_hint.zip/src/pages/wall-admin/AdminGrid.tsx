import { useState } from 'react'
import { t } from '../../components/tokens'
import { Btn } from '../../components/ui'

type SlotStatus = 'available' | 'booked' | 'live' | 'maintenance'
type SlotSize = 'Small' | 'Medium' | 'Large' | 'XL'

interface Slot {
  id: string
  size: SlotSize
  status: SlotStatus
  notes: string
}

const STATUS_COLORS: Record<SlotStatus, { bg: string; text: string; label: string }> = {
  available: { bg: '#dcfce7', text: '#166534', label: 'Available' },
  booked: { bg: t.ink, text: t.wallPaper, label: 'Booked' },
  live: { bg: t.signal, text: t.wallPaper, label: 'Live' },
  maintenance: { bg: '#fef9c3', text: '#854d0e', label: 'Maintenance' },
}

const LEGAL_TRANSITIONS: Record<SlotStatus, SlotStatus[]> = {
  available: ['booked', 'maintenance'],
  booked: ['live', 'available', 'maintenance'],
  live: ['available', 'maintenance'],
  maintenance: ['available'],
}

const ROWS = ['A', 'B', 'C', 'D']
const COLS = [1, 2, 3, 4, 5, 6]

function makeInitialSlots(): Slot[] {
  const statuses: SlotStatus[] = ['available', 'booked', 'live', 'maintenance', 'available', 'booked', 'live', 'available', 'booked', 'live', 'available', 'maintenance', 'available', 'booked', 'live', 'available', 'booked', 'available', 'booked', 'live', 'available', 'available', 'maintenance', 'booked']
  const sizes: SlotSize[] = ['Small', 'Medium', 'Large', 'Medium', 'Small', 'XL', 'Medium', 'Large', 'Small', 'Medium', 'XL', 'Small', 'Medium', 'Large', 'Small', 'Medium', 'Small', 'Large', 'Medium', 'XL', 'Small', 'Medium', 'Large', 'Small']
  return ROWS.flatMap((row, ri) =>
    COLS.map((col, ci) => ({
      id: `${row}${col}`,
      size: sizes[ri * 6 + ci] || 'Medium',
      status: statuses[ri * 6 + ci] || 'available',
      notes: '',
    }))
  )
}

export default function AdminGrid() {
  const [slots, setSlots] = useState<Slot[]>(makeInitialSlots())
  const [selected, setSelected] = useState<string | null>(null)
  const [modal, setModal] = useState<Slot | null>(null)
  const [releaseInput, setReleaseInput] = useState('')
  const [confirmRelease, setConfirmRelease] = useState(false)
  const [templateName, setTemplateName] = useState('')
  const [showTemplateSave, setShowTemplateSave] = useState(false)
  const [rows, setRows] = useState(ROWS)
  const [cols, setCols] = useState(COLS)

  function openModal(slotId: string) {
    const s = slots.find(s => s.id === slotId)
    if (s) { setModal({ ...s }); setReleaseInput(''); setConfirmRelease(false) }
  }

  function saveModal() {
    if (!modal) return
    setSlots(ss => ss.map(s => s.id === modal.id ? { ...modal } : s))
    setModal(null)
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500, color: t.ink, letterSpacing: '-0.025em' }}>
          Wall Grid
        </h1>
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn variant="quiet" onClick={() => setShowTemplateSave(v => !v)}>Save as template</Btn>
        </div>
      </div>

      {showTemplateSave && (
        <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, padding: '16px 20px', marginBottom: 20, display: 'flex', gap: 10, alignItems: 'center' }}>
          <input
            type="text"
            value={templateName}
            onChange={e => setTemplateName(e.target.value)}
            placeholder="Template name..."
            style={{ flex: 1, padding: '8px 12px', fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none' }}
          />
          <Btn onClick={() => { setShowTemplateSave(false); setTemplateName('') }}>Save</Btn>
          <Btn variant="ghost" onClick={() => setShowTemplateSave(false)}>Cancel</Btn>
        </div>
      )}

      {/* Legend */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 20, flexWrap: 'wrap' }}>
        {(Object.entries(STATUS_COLORS) as [SlotStatus, typeof STATUS_COLORS[SlotStatus]][]).map(([k, v]) => (
          <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 12, height: 12, borderRadius: 2, background: v.bg, border: k === 'available' ? `1px solid #86efac` : 'none' }} />
            <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>{v.label}</span>
          </div>
        ))}
      </div>

      {/* Grid */}
      <div style={{ display: 'inline-block', background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, padding: 20, marginBottom: 24 }}>
        <div style={{ display: 'grid', gridTemplateColumns: `32px repeat(${cols.length}, 96px)`, gap: 8 }}>
          {/* Column headers */}
          <div />
          {cols.map(c => (
            <div key={c} style={{ textAlign: 'center', fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted, fontWeight: 600 }}>
              {c}
            </div>
          ))}
          {/* Rows */}
          {rows.map(row => (
            <>
              <div key={row + '-label'} style={{ display: 'flex', alignItems: 'center', fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted, fontWeight: 600 }}>
                {row}
              </div>
              {cols.map(col => {
                const slotId = `${row}${col}`
                const slot = slots.find(s => s.id === slotId)
                if (!slot) return <div key={slotId} />
                const colors = STATUS_COLORS[slot.status]
                return (
                  <button
                    key={slotId}
                    onClick={() => openModal(slotId)}
                    style={{
                      background: colors.bg,
                      color: colors.text,
                      border: selected === slotId ? `2px solid ${t.signal}` : '2px solid transparent',
                      borderRadius: 4,
                      padding: '10px 6px',
                      cursor: 'pointer',
                      fontFamily: 'var(--font-sans)',
                      fontSize: 11,
                      fontWeight: 600,
                      textAlign: 'center',
                      transition: 'opacity 0.15s',
                      minHeight: 56,
                    }}
                    onFocus={() => setSelected(slotId)}
                    onBlur={() => setSelected(null)}
                    tabIndex={0}
                    aria-label={`Slot ${slotId}, ${slot.size}, ${slot.status}`}
                  >
                    <div style={{ fontWeight: 700 }}>{slotId}</div>
                    <div style={{ opacity: 0.75, marginTop: 2 }}>{slot.size}</div>
                  </button>
                )
              })}
            </>
          ))}
        </div>
      </div>

      {/* Grid controls */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 12, flexWrap: 'wrap' }}>
        <Btn variant="quiet" onClick={() => {
          const next = String.fromCharCode(rows[rows.length - 1].charCodeAt(0) + 1)
          setRows(r => [...r, next])
          setSlots(ss => {
            const newSlots = cols.map(c => ({ id: `${next}${c}`, size: 'Medium' as SlotSize, status: 'available' as SlotStatus, notes: '' }))
            return [...ss, ...newSlots]
          })
        }}>+ Add row</Btn>
        <Btn variant="quiet" onClick={() => {
          if (rows.length <= 1) return
          const removed = rows[rows.length - 1]
          setRows(r => r.slice(0, -1))
          setSlots(ss => ss.filter(s => !s.id.startsWith(removed)))
        }}>− Remove row</Btn>
        <Btn variant="quiet" onClick={() => {
          const next = cols[cols.length - 1] + 1
          setCols(c => [...c, next])
          setSlots(ss => {
            const newSlots = rows.map(r => ({ id: `${r}${next}`, size: 'Medium' as SlotSize, status: 'available' as SlotStatus, notes: '' }))
            return [...ss, ...newSlots]
          })
        }}>+ Add column</Btn>
        <Btn variant="quiet" onClick={() => {
          if (cols.length <= 1) return
          const removed = cols[cols.length - 1]
          setCols(c => c.slice(0, -1))
          setSlots(ss => ss.filter(s => !s.id.endsWith(String(removed))))
        }}>− Remove column</Btn>
      </div>

      {/* Keyboard hint */}
      <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>
        Tab to select slot · Enter to open · Arrow keys to navigate
      </div>

      {/* ── Slot modal ── */}
      {modal && (
        <div
          style={{
            position: 'fixed', inset: 0, background: 'rgba(12,15,29,0.5)',
            zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
          onClick={e => { if (e.target === e.currentTarget) setModal(null) }}
        >
          <div style={{
            background: t.wallPaper, borderRadius: 4, padding: 32,
            width: 420, maxWidth: '90vw',
            boxShadow: '0 16px 48px rgba(0,0,0,0.18)',
          }}>
            <div style={{ fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 500, color: t.ink, letterSpacing: '-0.02em', marginBottom: 24 }}>
              Slot {modal.id}
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {/* Size */}
              <div>
                <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>Size category</label>
                <select
                  value={modal.size}
                  onChange={e => setModal(m => m ? { ...m, size: e.target.value as SlotSize } : m)}
                  style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none' }}
                >
                  {(['Small', 'Medium', 'Large', 'XL'] as SlotSize[]).map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              {/* Status */}
              <div>
                <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>Status</label>
                <select
                  value={modal.status}
                  onChange={e => setModal(m => m ? { ...m, status: e.target.value as SlotStatus } : m)}
                  style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none' }}
                >
                  {LEGAL_TRANSITIONS[modal.status].concat([modal.status]).map(s => (
                    <option key={s} value={s}>{STATUS_COLORS[s].label}</option>
                  ))}
                </select>
              </div>

              {/* Notes */}
              <div>
                <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, display: 'block', marginBottom: 6 }}>Notes</label>
                <textarea
                  value={modal.notes}
                  onChange={e => setModal(m => m ? { ...m, notes: e.target.value } : m)}
                  rows={3}
                  style={{ width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none', resize: 'vertical', boxSizing: 'border-box' }}
                />
              </div>

              {/* Force release */}
              <div style={{ borderTop: `1px solid ${t.hairline}`, paddingTop: 16 }}>
                {!confirmRelease ? (
                  <Btn variant="danger" onClick={() => setConfirmRelease(true)}>Force release</Btn>
                ) : (
                  <div>
                    <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: t.destructive, marginBottom: 8 }}>
                      Type RELEASE to confirm force release
                    </div>
                    <input
                      type="text"
                      value={releaseInput}
                      onChange={e => setReleaseInput(e.target.value)}
                      placeholder="RELEASE"
                      style={{ width: '100%', padding: '8px 12px', fontFamily: 'var(--font-sans)', fontSize: 13, border: `1px solid ${t.destructive}`, borderRadius: 4, outline: 'none', marginBottom: 8, boxSizing: 'border-box' }}
                    />
                    <Btn variant="danger" disabled={releaseInput !== 'RELEASE'} onClick={() => { setModal(m => m ? { ...m, status: 'available' } : m); setConfirmRelease(false) }}>
                      Confirm release
                    </Btn>
                  </div>
                )}
              </div>

              {/* Save / cancel */}
              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', paddingTop: 8 }}>
                <Btn variant="quiet" onClick={() => setModal(null)}>Cancel</Btn>
                <Btn onClick={saveModal}>Save</Btn>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
