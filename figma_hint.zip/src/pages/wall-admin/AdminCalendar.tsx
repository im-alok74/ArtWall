import { useState } from 'react'
import { t } from '../../components/tokens'

const SLOTS = ['A1','A2','A3','A4','A5','A6','B1','B2','B3','B4','B5','B6','C1','C2','C3','C4','C5','C6','D1','D2','D3','D4','D5','D6']

type BookingStatus = 'booked' | 'held' | 'live'

interface CalBooking {
  slot: string
  start: number // day of month (1-based)
  end: number
  label: string
  status: BookingStatus
}

const BOOKINGS: CalBooking[] = [
  { slot: 'A1', start: 1, end: 10, label: 'Meera Iyer', status: 'live' },
  { slot: 'A1', start: 14, end: 22, label: 'Rohan Das', status: 'booked' },
  { slot: 'A2', start: 3, end: 12, label: 'Priya Mehta', status: 'live' },
  { slot: 'A2', start: 16, end: 28, label: 'Ankit Rao', status: 'booked' },
  { slot: 'A3', start: 1, end: 18, label: 'Sunita Joshi', status: 'booked' },
  { slot: 'A4', start: 5, end: 9, label: 'Rahul Nair', status: 'held' },
  { slot: 'A4', start: 14, end: 25, label: 'Divya Sharma', status: 'live' },
  { slot: 'A5', start: 1, end: 31, label: 'Kiran Patel', status: 'live' },
  { slot: 'A6', start: 8, end: 19, label: 'Leela Nambiar', status: 'booked' },
  { slot: 'B1', start: 2, end: 11, label: 'Arjun Menon', status: 'held' },
  { slot: 'B1', start: 16, end: 28, label: 'Pooja Sinha', status: 'booked' },
  { slot: 'B2', start: 1, end: 7, label: 'Suresh Babu', status: 'live' },
  { slot: 'B2', start: 12, end: 24, label: 'Neha Kapoor', status: 'booked' },
  { slot: 'B3', start: 4, end: 16, label: 'Vikram Singh', status: 'booked' },
  { slot: 'B4', start: 1, end: 31, label: 'Anjali Bose', status: 'live' },
  { slot: 'B5', start: 6, end: 14, label: 'Ravi Kumar', status: 'held' },
  { slot: 'B5', start: 19, end: 28, label: 'Deepa Nair', status: 'booked' },
  { slot: 'B6', start: 10, end: 22, label: 'Arun Pillai', status: 'booked' },
  { slot: 'C1', start: 1, end: 12, label: 'Meena Das', status: 'live' },
  { slot: 'C1', start: 15, end: 26, label: 'Sanjay Gupta', status: 'booked' },
  { slot: 'C2', start: 3, end: 20, label: 'Kavita Rao', status: 'booked' },
  { slot: 'C3', start: 1, end: 9, label: 'Aditya Jain', status: 'held' },
  // C4 has a gap Jan 28-31 (noted in overview)
  { slot: 'C4', start: 5, end: 17, label: 'Smita Shah', status: 'live' },
  { slot: 'C4', start: 21, end: 27, label: 'Manoj Tiwari', status: 'booked' },
  { slot: 'C5', start: 2, end: 14, label: 'Nandini Rao', status: 'booked' },
  { slot: 'C6', start: 8, end: 31, label: 'Pradeep Iyer', status: 'live' },
  { slot: 'D1', start: 1, end: 18, label: 'Geeta Pillai', status: 'booked' },
  { slot: 'D2', start: 5, end: 25, label: 'Ramesh Nair', status: 'held' },
  { slot: 'D3', start: 3, end: 13, label: 'Usha Menon', status: 'live' },
  { slot: 'D4', start: 1, end: 10, label: 'Sudhir Bhat', status: 'booked' },
  { slot: 'D5', start: 7, end: 28, label: 'Lalitha Das', status: 'live' },
  { slot: 'D6', start: 4, end: 19, label: 'Prakash Rao', status: 'booked' },
]

const STATUS_STYLES: Record<BookingStatus, React.CSSProperties> = {
  booked: { background: t.ink, color: t.wallPaper },
  held: { background: t.band, color: t.ink, border: `1px solid ${t.hairline}` },
  live: { background: '#dcfce7', color: '#166534' },
}

const DAYS_IN_JAN = 31

function findGaps(slotId: string): Array<{ start: number; end: number }> {
  const bs = BOOKINGS.filter(b => b.slot === slotId).sort((a, b) => a.start - b.start)
  const gaps: Array<{ start: number; end: number }> = []
  for (let i = 0; i < bs.length - 1; i++) {
    const gapStart = bs[i].end + 1
    const gapEnd = bs[i + 1].start - 1
    if (gapEnd - gapStart >= 2) {
      gaps.push({ start: gapStart, end: gapEnd })
    }
  }
  return gaps
}

export default function AdminCalendar() {
  const [month, setMonth] = useState('Jan 2025')
  const days = Array.from({ length: DAYS_IN_JAN }, (_, i) => i + 1)
  const DAY_W = 28

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500, color: t.ink, letterSpacing: '-0.025em' }}>
          Calendar
        </h1>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button
            onClick={() => setMonth('Dec 2024')}
            style={{ border: 'none', background: 'none', cursor: 'pointer', fontFamily: 'var(--font-sans)', fontSize: 18, color: t.ink, padding: '4px 8px' }}
          >
            ‹
          </button>
          <span style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: t.ink, minWidth: 80, textAlign: 'center' }}>
            {month}
          </span>
          <button
            onClick={() => setMonth('Feb 2025')}
            style={{ border: 'none', background: 'none', cursor: 'pointer', fontFamily: 'var(--font-sans)', fontSize: 18, color: t.ink, padding: '4px 8px' }}
          >
            ›
          </button>
        </div>
      </div>

      {/* Legend */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 16, flexWrap: 'wrap' }}>
        {([['booked', 'Booked/paid'], ['held', 'Held'], ['live', 'Live/installed']] as const).map(([k, l]) => (
          <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 16, height: 12, borderRadius: 2, ...STATUS_STYLES[k] }} />
            <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>{l}</span>
          </div>
        ))}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 16, height: 12, borderRadius: 2, background: '#fef3c7' }} />
          <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>Gap 3+ days</span>
        </div>
      </div>

      {/* Grid */}
      <div style={{ overflowX: 'auto', background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4 }}>
        <div style={{ minWidth: 32 + DAYS_IN_JAN * DAY_W + 32 }}>
          {/* Header row */}
          <div style={{ display: 'flex', borderBottom: `1px solid ${t.hairline}`, position: 'sticky', top: 0, background: t.wallPaper, zIndex: 10 }}>
            <div style={{ width: 56, flexShrink: 0, padding: '8px 12px' }} />
            {days.map(d => (
              <div key={d} style={{
                width: DAY_W, flexShrink: 0, textAlign: 'center',
                fontFamily: 'var(--font-sans)', fontSize: 10, color: t.inkMuted, fontWeight: 600,
                padding: '6px 0',
                borderLeft: `1px solid ${t.hairline}`,
              }}>
                {d}
              </div>
            ))}
          </div>

          {/* Slot rows */}
          {SLOTS.map((slotId, si) => {
            const slotBookings = BOOKINGS.filter(b => b.slot === slotId)
            const gaps = findGaps(slotId)
            return (
              <div
                key={slotId}
                style={{
                  display: 'flex',
                  borderBottom: si < SLOTS.length - 1 ? `1px solid ${t.hairline}` : 'none',
                  position: 'relative',
                  height: 40,
                  alignItems: 'center',
                }}
              >
                {/* Slot label */}
                <div style={{
                  width: 56, flexShrink: 0, padding: '0 12px',
                  fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 600, color: t.ink,
                }}>
                  {slotId}
                </div>

                {/* Day columns (background) */}
                <div style={{ position: 'absolute', left: 56, top: 0, bottom: 0, right: 0, display: 'flex' }}>
                  {days.map(d => (
                    <div key={d} style={{ width: DAY_W, flexShrink: 0, borderLeft: `1px solid ${t.hairline}`, height: '100%' }} />
                  ))}
                </div>

                {/* Gap highlights */}
                {gaps.map((g, gi) => (
                  <div
                    key={gi}
                    style={{
                      position: 'absolute',
                      left: 56 + (g.start - 1) * DAY_W,
                      width: (g.end - g.start + 1) * DAY_W,
                      top: 0, bottom: 0,
                      background: '#fef3c7',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      zIndex: 1,
                    }}
                  >
                    <span style={{ fontFamily: 'var(--font-sans)', fontSize: 9, color: '#92400e', whiteSpace: 'nowrap' }}>
                      Gap: {g.end - g.start + 1}d
                    </span>
                  </div>
                ))}

                {/* Bookings */}
                {slotBookings.map((b, bi) => (
                  <div
                    key={bi}
                    style={{
                      position: 'absolute',
                      left: 56 + (b.start - 1) * DAY_W + 1,
                      width: (b.end - b.start + 1) * DAY_W - 2,
                      top: 4, bottom: 4,
                      borderRadius: 3,
                      display: 'flex', alignItems: 'center', paddingLeft: 6,
                      zIndex: 2,
                      overflow: 'hidden',
                      ...STATUS_STYLES[b.status],
                    }}
                  >
                    <span style={{ fontFamily: 'var(--font-sans)', fontSize: 10, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {b.label}
                    </span>
                  </div>
                ))}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
