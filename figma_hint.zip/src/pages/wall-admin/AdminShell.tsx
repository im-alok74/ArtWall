import { Link, useLocation, Outlet } from 'react-router'
import { t } from '../../components/tokens'
import { Hairline } from '../../components/ui'

const NAV_ITEMS = [
  { icon: '◎', label: 'Overview', path: '/physical-wall/admin' },
  { icon: '⊞', label: 'Wall Grid', path: '/physical-wall/admin/grid' },
  { icon: '▦', label: 'Calendar', path: '/physical-wall/admin/calendar' },
  { icon: '◰', label: 'Bookings', path: '/physical-wall/admin/bookings' },
  { icon: '◫', label: 'Queue', path: '/physical-wall/admin/queue' },
  { icon: '◈', label: 'Catalogs', path: '/physical-wall/admin/catalogs' },
  { icon: '₹', label: 'Ledger', path: '/physical-wall/admin/ledger' },
]

const PAGE_TITLES: Record<string, string> = {
  '/physical-wall/admin': 'Overview',
  '/physical-wall/admin/grid': 'Wall Grid',
  '/physical-wall/admin/calendar': 'Calendar',
  '/physical-wall/admin/bookings': 'Bookings',
  '/physical-wall/admin/queue': 'Queue',
  '/physical-wall/admin/catalogs': 'Catalogs',
  '/physical-wall/admin/ledger': 'Ledger',
}

export default function AdminShell() {
  const { pathname } = useLocation()
  const pageTitle = PAGE_TITLES[pathname] || 'Admin'

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: t.band }}>
      {/* ── Sidebar ── */}
      <aside style={{
        width: 200,
        flexShrink: 0,
        background: t.footer,
        display: 'flex',
        flexDirection: 'column',
        position: 'fixed',
        top: 0,
        left: 0,
        bottom: 0,
        zIndex: 40,
      }}>
        {/* Logo */}
        <div style={{ padding: '22px 20px 18px', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ fontFamily: 'var(--font-heading)', fontSize: 17, fontWeight: 500, color: t.wallPaper, letterSpacing: '-0.02em', lineHeight: 1.2 }}>
            ArtWall
          </div>
          <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, color: 'rgba(255,255,255,0.4)', letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: 2 }}>
            Admin Console
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: '12px 0', overflowY: 'auto' }}>
          {NAV_ITEMS.map(item => {
            const isActive = pathname === item.path
            return (
              <Link
                key={item.path}
                to={item.path}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 10,
                  padding: '10px 20px',
                  textDecoration: 'none',
                  fontFamily: 'var(--font-sans)',
                  fontSize: 13,
                  fontWeight: isActive ? 600 : 400,
                  color: isActive ? t.wallPaper : 'rgba(255,255,255,0.55)',
                  background: isActive ? t.signal : 'transparent',
                  borderRadius: 0,
                  transition: 'background 0.15s, color 0.15s',
                }}
              >
                <span style={{ fontSize: 14, opacity: isActive ? 1 : 0.7 }}>{item.icon}</span>
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* Bottom link */}
        <div style={{ padding: '16px 20px', borderTop: '1px solid rgba(255,255,255,0.08)' }}>
          <Link
            to="/"
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: 12,
              color: 'rgba(255,255,255,0.4)',
              textDecoration: 'none',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
            }}
          >
            ← Back to site
          </Link>
        </div>
      </aside>

      {/* ── Main area ── */}
      <div style={{ marginLeft: 200, flex: 1, display: 'flex', flexDirection: 'column' }}>
        {/* Top bar */}
        <header style={{
          position: 'sticky',
          top: 0,
          zIndex: 30,
          height: 56,
          background: t.wallPaper,
          borderBottom: `1px solid ${t.hairline}`,
          display: 'flex',
          alignItems: 'center',
          padding: '0 32px',
          gap: 8,
        }}>
          <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>
            ArtWall Admin
          </span>
          <span style={{ color: t.hairline }}>›</span>
          <span style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: t.ink }}>
            {pageTitle}
          </span>
        </header>

        {/* Page content */}
        <main style={{ flex: 1, padding: '32px', overflowX: 'auto' }}>
          <Outlet />
        </main>
      </div>
    </div>
  )
}
