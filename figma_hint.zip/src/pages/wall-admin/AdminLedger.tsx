import { useState } from 'react'
import { t } from '../../components/tokens'
import { Btn } from '../../components/ui'

interface LedgerRow {
  date: string
  type: 'income' | 'expense'
  description: string
  reference: string
  amount: number
  category: string
}

const TRANSACTIONS: LedgerRow[] = [
  { date: 'Jan 2', type: 'income', description: 'Booking payment — Meera Iyer, A3', reference: 'AWL-2025-0841', amount: 4200, category: 'Booking' },
  { date: 'Jan 3', type: 'income', description: 'Booking payment — Kiran Patel, A5', reference: 'AWL-2025-0836', amount: 3900, category: 'Booking' },
  { date: 'Jan 4', type: 'expense', description: 'Installation service — 3 artworks', reference: 'INV-INST-001', amount: -2400, category: 'Installation' },
  { date: 'Jan 5', type: 'income', description: 'Booking payment — Rohan Das, B2', reference: 'AWL-2025-0839', amount: 3600, category: 'Booking' },
  { date: 'Jan 6', type: 'income', description: 'Ric Platter commission — Dec redemptions', reference: 'PLATTER-DEC-24', amount: 2800, category: 'Platter' },
  { date: 'Jan 7', type: 'expense', description: 'Wall maintenance — lighting repair', reference: 'MAINT-2025-01', amount: -1800, category: 'Maintenance' },
  { date: 'Jan 8', type: 'income', description: 'Booking payment — Priya Mehta, C1', reference: 'AWL-2025-0838', amount: 4800, category: 'Booking' },
  { date: 'Jan 9', type: 'expense', description: 'Printing — artist labels (batch 1)', reference: 'PRINT-001', amount: -600, category: 'Supplies' },
  { date: 'Jan 10', type: 'income', description: 'Booking payment — Sunita Joshi, D4', reference: 'AWL-2025-0835', amount: 2800, category: 'Booking' },
  { date: 'Jan 11', type: 'income', description: 'Add-on — lighting spot, Leela Nambiar', reference: 'ADDON-001', amount: 1600, category: 'Add-on' },
  { date: 'Jan 12', type: 'expense', description: 'Insurance premium — Jan 2025', reference: 'INS-JAN-25', amount: -3200, category: 'Insurance' },
  { date: 'Jan 13', type: 'income', description: 'Booking payment — Ankit Rao, B5', reference: 'AWL-2025-0833', amount: 3600, category: 'Booking' },
  { date: 'Jan 14', type: 'income', description: 'Ric Platter commission — Jan week 1', reference: 'PLATTER-JAN-W1', amount: 1400, category: 'Platter' },
  { date: 'Jan 15', type: 'expense', description: 'Refund — Vikram Singh (cancellation)', reference: 'REF-AWL-0835', amount: -1800, category: 'Refund' },
  { date: 'Jan 16', type: 'income', description: 'Booking payment — Nandini Rao, C3', reference: 'AWL-2025-0842', amount: 4200, category: 'Booking' },
  { date: 'Jan 17', type: 'expense', description: 'Staff wages — Jan week 2', reference: 'PAY-JAN-W2', amount: -4000, category: 'Staff' },
  { date: 'Jan 18', type: 'income', description: 'Booking payment — Arjun Menon, B1', reference: 'AWL-2025-0840', amount: 3200, category: 'Booking' },
  { date: 'Jan 19', type: 'income', description: 'Ric Platter commission — Jan week 2', reference: 'PLATTER-JAN-W2', amount: 2200, category: 'Platter' },
  { date: 'Jan 20', type: 'expense', description: 'Utilities — electricity Jan 1–15', reference: 'UTIL-JAN-A', amount: -1000, category: 'Utilities' },
]

const PLATTER_REDEMPTIONS = [
  { date: 'Jan 6', visitor: 'Rahul Sharma', billTotal: '₹1,840', discount: '₹184', ref: 'PL-2025-0061' },
  { date: 'Jan 8', visitor: 'Ananya Krishnan', billTotal: '₹2,200', discount: '₹220', ref: 'PL-2025-0062' },
  { date: 'Jan 10', visitor: 'Mohit Gupta', billTotal: '₹960', discount: '₹96', ref: 'PL-2025-0063' },
  { date: 'Jan 12', visitor: 'Deepa Nair', billTotal: '₹3,100', discount: '₹310', ref: 'PL-2025-0064' },
  { date: 'Jan 14', visitor: 'Siddharth Rao', billTotal: '₹1,400', discount: '₹140', ref: 'PL-2025-0065' },
  { date: 'Jan 15', visitor: "Priya Iyer", billTotal: '₹2,600', discount: '₹260', ref: 'PL-2025-0066' },
  { date: 'Jan 18', visitor: 'Arvind Kumar', billTotal: '₹1,700', discount: '₹170', ref: 'PL-2025-0067' },
]

function MetricCard({ label, value, sub, highlight }: { label: string; value: string; sub?: string; highlight?: boolean }) {
  return (
    <div style={{
      background: highlight ? t.ink : t.wallPaper,
      border: `1px solid ${highlight ? t.ink : t.hairline}`,
      borderRadius: 4,
      padding: '22px 24px',
    }}>
      <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 600, color: highlight ? 'rgba(255,255,255,0.55)' : t.inkMuted, letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 8 }}>
        {label}
      </div>
      <div style={{ fontFamily: 'var(--font-heading)', fontSize: 32, fontWeight: 500, color: highlight ? t.wallPaper : t.ink, letterSpacing: '-0.03em' }}>
        {value}
      </div>
      {sub && <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: highlight ? 'rgba(255,255,255,0.5)' : t.inkMuted, marginTop: 4 }}>{sub}</div>}
    </div>
  )
}

export default function AdminLedger() {
  const [month, setMonth] = useState('Jan 2025')

  const thStyle: React.CSSProperties = {
    fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 600, color: t.inkMuted,
    letterSpacing: '0.04em', textTransform: 'uppercase', padding: '10px 14px',
    textAlign: 'left', borderBottom: `1px solid ${t.hairline}`,
  }
  const tdStyle: React.CSSProperties = {
    fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink,
    padding: '11px 14px', borderBottom: `1px solid ${t.hairline}`,
    verticalAlign: 'middle',
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 28, fontWeight: 500, color: t.ink, letterSpacing: '-0.025em' }}>
          Ledger
        </h1>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <select
            value={month}
            onChange={e => setMonth(e.target.value)}
            style={{ padding: '8px 12px', fontFamily: 'var(--font-sans)', fontSize: 13, color: t.ink, background: t.band, border: `1px solid ${t.hairline}`, borderRadius: 4, outline: 'none' }}
          >
            {['Jan 2025', 'Dec 2024', 'Nov 2024'].map(m => <option key={m} value={m}>{m}</option>)}
          </select>
          <Btn variant="quiet" onClick={() => {}}>CSV Export</Btn>
        </div>
      </div>

      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 16, marginBottom: 32 }}>
        <MetricCard label="Revenue" value="₹38,400" />
        <MetricCard label="Expenses" value="₹12,800" />
        <MetricCard label="Net" value="₹25,600" highlight />
        <MetricCard label="Platter attribution" value="₹8,400" sub="From coupon redemptions" />
      </div>

      {/* Transactions */}
      <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: t.ink, marginBottom: 14 }}>
        Transactions — {month}
      </div>
      <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, overflowX: 'auto', marginBottom: 36 }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: t.band }}>
              <th style={thStyle}>Date</th>
              <th style={thStyle}>Type</th>
              <th style={thStyle}>Description</th>
              <th style={thStyle}>Reference</th>
              <th style={{ ...thStyle, textAlign: 'right' }}>Amount</th>
              <th style={thStyle}>Category</th>
            </tr>
          </thead>
          <tbody>
            {TRANSACTIONS.map((tx, i) => (
              <tr key={i}
                onMouseEnter={e => (e.currentTarget.style.background = t.band)}
                onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
              >
                <td style={{ ...tdStyle, color: t.inkMuted, whiteSpace: 'nowrap' }}>{tx.date}</td>
                <td style={tdStyle}>
                  <span style={{
                    fontFamily: 'var(--font-sans)', fontSize: 10, fontWeight: 600,
                    padding: '2px 7px', borderRadius: 3,
                    background: tx.type === 'income' ? '#dcfce7' : '#fee2e2',
                    color: tx.type === 'income' ? '#166534' : '#991b1b',
                    textTransform: 'uppercase', letterSpacing: '0.04em',
                  }}>
                    {tx.type}
                  </span>
                </td>
                <td style={tdStyle}>{tx.description}</td>
                <td style={{ ...tdStyle, fontFamily: 'var(--font-sans)', fontSize: 11, color: t.inkMuted, letterSpacing: '0.02em' }}>{tx.reference}</td>
                <td style={{ ...tdStyle, textAlign: 'right', fontFamily: 'var(--font-heading)', fontWeight: 500, color: tx.type === 'income' ? '#166534' : t.destructive, whiteSpace: 'nowrap' }}>
                  {tx.type === 'income' ? '+' : ''}₹{Math.abs(tx.amount).toLocaleString('en-IN')}
                </td>
                <td style={{ ...tdStyle, color: t.inkMuted }}>{tx.category}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Platter attribution */}
      <div style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: t.ink, marginBottom: 6 }}>
        Ric Platter attribution — {month}
      </div>
      <div style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted, marginBottom: 14 }}>
        Revenue attributable to art-wall visitors via coupon redemptions
      </div>
      <div style={{ background: t.wallPaper, border: `1px solid ${t.hairline}`, borderRadius: 4, overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: t.band }}>
              <th style={thStyle}>Date</th>
              <th style={thStyle}>Visitor</th>
              <th style={{ ...thStyle, textAlign: 'right' }}>Bill total</th>
              <th style={{ ...thStyle, textAlign: 'right' }}>Discount</th>
              <th style={thStyle}>Reference</th>
            </tr>
          </thead>
          <tbody>
            {PLATTER_REDEMPTIONS.map((r, i) => (
              <tr key={i}
                onMouseEnter={e => (e.currentTarget.style.background = t.band)}
                onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
              >
                <td style={{ ...tdStyle, color: t.inkMuted }}>{r.date}</td>
                <td style={{ ...tdStyle, fontWeight: 500 }}>{r.visitor}</td>
                <td style={{ ...tdStyle, textAlign: 'right', fontFamily: 'var(--font-heading)' }}>{r.billTotal}</td>
                <td style={{ ...tdStyle, textAlign: 'right', fontFamily: 'var(--font-heading)', color: '#166534' }}>{r.discount}</td>
                <td style={{ ...tdStyle, fontSize: 11, color: t.inkMuted }}>{r.ref}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
