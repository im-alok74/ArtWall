import { createBrowserRouter } from 'react-router'
import Root from './layouts/Root'
import AuthRoot from './layouts/AuthRoot'
import Home from './pages/Home'
import Platform from './pages/Platform'
import Journey from './pages/Journey'
import About from './pages/About'
import Community from './pages/Community'
import Artists from './pages/Artists'
import ArtistProfile from './pages/ArtistProfile'
import Certificate from './pages/Certificate'
import WallDigital from './pages/WallDigital'
import Join from './pages/Join'
import Survey from './pages/Survey'
import Contact from './pages/Contact'
import NotFound from './pages/NotFound'
import SignUp from './pages/auth/SignUp'
import SignIn from './pages/auth/SignIn'
import Welcome from './pages/auth/Welcome'
import StudioShell from './pages/studio/StudioShell'
import StudioOverview from './pages/studio/StudioOverview'
import Artworks from './pages/studio/Artworks'
import ArtworkNew from './pages/studio/ArtworkNew'
import Collections from './pages/studio/Collections'
import Sales from './pages/studio/Sales'
import PhysicalWall from './pages/wall-public/PhysicalWall'
import ArtworkDetail from './pages/wall-public/ArtworkDetail'
import Visit from './pages/wall-public/Visit'
import QRFail from './pages/wall-public/QRFail'
import Book from './pages/wall-artist/Book'
import Bookings from './pages/wall-artist/Bookings'
import Waitlist from './pages/wall-artist/Waitlist'
import Account from './pages/wall-artist/Account'
import Feedback from './pages/wall-artist/Feedback'
import Ops from './pages/wall-staff/Ops'
import PerkCounter from './pages/wall-staff/PerkCounter'
import AdminShell from './pages/wall-admin/AdminShell'
import AdminOverview from './pages/wall-admin/AdminOverview'
import AdminGrid from './pages/wall-admin/AdminGrid'
import AdminCalendar from './pages/wall-admin/AdminCalendar'
import AdminBookings from './pages/wall-admin/AdminBookings'
import AdminQueue from './pages/wall-admin/AdminQueue'
import AdminCatalogs from './pages/wall-admin/AdminCatalogs'
import AdminLedger from './pages/wall-admin/AdminLedger'

export const router = createBrowserRouter([
  // ── Marketing + public pages (Nav + Footer) ──
  {
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: 'platform', Component: Platform },
      { path: 'journey', Component: Journey },
      { path: 'about', Component: About },
      { path: 'community', Component: Community },
      { path: 'artists', Component: Artists },
      { path: 'artist/:handle', Component: ArtistProfile },
      { path: 'certificate', Component: Certificate },
      { path: 'wall', Component: WallDigital },
      { path: 'join', Component: Join },
      { path: 'survey', Component: Survey },
      { path: 'contact', Component: Contact },
      // Physical Wall – public
      { path: 'physical-wall', Component: PhysicalWall },
      { path: 'physical-wall/a/:id', Component: ArtworkDetail },
      { path: 'physical-wall/visit', Component: Visit },
      // Physical Wall – artist
      { path: 'physical-wall/book', Component: Book },
      { path: 'physical-wall/bookings', Component: Bookings },
      { path: 'physical-wall/waitlist', Component: Waitlist },
      { path: 'physical-wall/account', Component: Account },
      { path: 'physical-wall/feedback/:id', Component: Feedback },
      // Staff
      { path: 'physical-wall/ops', Component: Ops },
      { path: 'physical-wall/ops/perk/:token', Component: PerkCounter },
      // QR resolver
      { path: 'q/:token', Component: QRFail },
    ],
  },
  // ── Auth (minimal shell, no footer) ──
  {
    Component: AuthRoot,
    children: [
      { path: 'sign-up', Component: SignUp },
      { path: 'sign-in', Component: SignIn },
      { path: 'physical-wall/welcome', Component: Welcome },
    ],
  },
  // ── Studio ──
  {
    path: 'studio',
    Component: StudioShell,
    children: [
      { index: true, Component: StudioOverview },
      { path: 'artworks', Component: Artworks },
      { path: 'artworks/new', Component: ArtworkNew },
      { path: 'collections', Component: Collections },
      { path: 'sales', Component: Sales },
    ],
  },
  // ── Admin ──
  {
    path: 'physical-wall/admin',
    Component: AdminShell,
    children: [
      { index: true, Component: AdminOverview },
      { path: 'grid', Component: AdminGrid },
      { path: 'calendar', Component: AdminCalendar },
      { path: 'bookings', Component: AdminBookings },
      { path: 'queue', Component: AdminQueue },
      { path: 'catalogs', Component: AdminCatalogs },
      { path: 'ledger', Component: AdminLedger },
    ],
  },
  // ── 404 ──
  { path: '*', Component: NotFound },
])
