import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router'
import { t } from './tokens'

const navLinks = [
  { label: 'Platform', to: '/platform' },
  { label: 'Journey', to: '/journey' },
  { label: 'Community', to: '/community' },
  { label: 'Artists', to: '/artists' },
  { label: 'About', to: '/about' },
]

export default function Nav() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 32)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => { setMenuOpen(false) }, [location.pathname])

  return (
    <header style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      background: scrolled ? 'rgba(255,255,255,0.97)' : t.wallPaper,
      borderBottom: `1px solid ${scrolled ? t.hairline : 'transparent'}`,
      transition: 'border-color 0.2s, background 0.2s',
    }}>
      <div style={{
        maxWidth: 1240, margin: '0 auto', padding: '0 32px',
        height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <Link to="/" style={{ textDecoration: 'none', display: 'flex', flexDirection: 'column', gap: 1 }}>
          <span style={{ fontFamily: 'var(--font-heading)', fontSize: 18, fontWeight: 500, color: t.ink, letterSpacing: '-0.02em', lineHeight: 1 }}>
            ArtWall
          </span>
          <span style={{ fontFamily: 'var(--font-sans)', fontSize: 10, fontWeight: 400, color: t.inkMuted, letterSpacing: '0.12em', textTransform: 'uppercase', lineHeight: 1 }}>
            Labs
          </span>
        </Link>

        <nav style={{ display: 'flex', gap: 32, alignItems: 'center' }}>
          {navLinks.map(({ label, to }) => (
            <Link key={to} to={to} style={{
              fontFamily: 'var(--font-sans)', fontSize: 14, fontWeight: 400,
              color: location.pathname === to ? t.ink : t.inkMuted,
              textDecoration: 'none', letterSpacing: '-0.01em', transition: 'color 0.15s',
            }}
            onMouseEnter={e => (e.currentTarget.style.color = t.ink)}
            onMouseLeave={e => (e.currentTarget.style.color = location.pathname === to ? t.ink : t.inkMuted)}
            >
              {label}
            </Link>
          ))}
          <Link to="/join" style={{
            fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 500,
            color: t.wallPaper, background: t.ink, textDecoration: 'none',
            padding: '9px 18px', borderRadius: 4, letterSpacing: '-0.01em', transition: 'background 0.15s',
          }}
          onMouseEnter={e => (e.currentTarget.style.background = t.emberGlow)}
          onMouseLeave={e => (e.currentTarget.style.background = t.ink)}
          >
            Join Founding Cohort
          </Link>
        </nav>
      </div>
    </header>
  )
}
