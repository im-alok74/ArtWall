// ArtWall design tokens — single source of truth for all pages
export const t = {
  ink: '#0c0f1d',
  inkMuted: '#64748b',
  wallPaper: '#ffffff',
  wallCharcoal: '#f1f5f9',
  wallElevated: '#f8fafc',
  band: '#f7f9fb',
  hairline: '#e2e8f0',
  hairlineStrong: '#cbd5e1',
  signal: '#0e7490',
  signalBright: '#38bdf8',
  footer: '#1c2e38',
  emberGlow: '#2b3245',
  terracotta: '#94a3b8',
  destructive: '#dc2626',
} as const

export type Token = keyof typeof t
