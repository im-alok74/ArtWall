import { Link } from 'react-router'
import { t } from './tokens'

export default function Footer() {
  return (
    <footer style={{ background: t.footer }}>
      <div style={{ maxWidth: 1240, margin: '0 auto', padding: '64px 64px 40px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 48, paddingBottom: 48, borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
          <div>
            <div style={{ fontFamily: 'var(--font-heading)', fontSize: 20, fontWeight: 500, color: 'rgba(255,255,255,0.9)', letterSpacing: '-0.02em', marginBottom: 4 }}>ArtWall</div>
            <div style={{ fontFamily: 'var(--font-sans)', fontSize: 10, color: 'rgba(255,255,255,0.45)', letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 20 }}>Labs</div>
            <p style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: 'rgba(255,255,255,0.55)', lineHeight: 1.65, maxWidth: 220 }}>
              Infrastructure for India's artists. Based in Jaipur.
            </p>
          </div>
          {[
            { heading: 'Platform', links: [['Catalogue', '/platform'], ['Provenance', '/certificate'], ['Studio', '/studio'], ['Physical Wall', '/physical-wall'], ['Community', '/community']] },
            { heading: 'Company', links: [['About', '/about'], ['Journey', '/journey'], ['Artists', '/artists'], ['Contact', '/contact'], ['Join', '/join']] },
            { heading: 'Legal', links: [['Privacy notice', '#'], ['Terms', '#'], ['Data rights', '/physical-wall/account'], ['Grievance', '#'], ['DPDP compliance', '#']] },
          ].map(col => (
            <div key={col.heading}>
              <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 500, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', marginBottom: 16 }}>{col.heading}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {col.links.map(([label, to]) => (
                  <Link key={label} to={to} style={{ fontFamily: 'var(--font-sans)', fontSize: 13, color: 'rgba(255,255,255,0.65)', textDecoration: 'none', transition: 'color 0.15s' }}
                    onMouseEnter={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.9)')}
                    onMouseLeave={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.65)')}
                  >{label}</Link>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div style={{ paddingTop: 28, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
          <p style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: 'rgba(255,255,255,0.35)' }}>© 2025 ArtWall Labs. Registered in India.</p>
          <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: t.signal }} />
            <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: 'rgba(255,255,255,0.35)' }}>Wall live · Jaipur</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
