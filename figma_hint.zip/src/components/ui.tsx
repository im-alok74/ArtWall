// Shared micro-components used across all pages
import { t } from './tokens'

export function Eyebrow({ chapter, label }: { chapter: string; label: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <span className="eyebrow" style={{ color: t.signal }}>{chapter}</span>
      <span style={{ width: 20, height: 1, background: t.signal, display: 'inline-block' }} />
      <span className="eyebrow" style={{ color: t.signal }}>{label}</span>
    </div>
  )
}

export function Hairline() {
  return <div style={{ width: '100%', height: 1, background: t.hairline }} />
}

export function ChapterNumeral({ n }: { n: string }) {
  return (
    <span style={{
      fontFamily: 'var(--font-heading)', fontSize: 'clamp(60px, 8vw, 96px)',
      fontWeight: 500, color: t.wallCharcoal, letterSpacing: '-0.04em',
      lineHeight: 0.8, userSelect: 'none' as const, display: 'block',
    }}>{n}</span>
  )
}

export function SectionHeader({ eyebrow, chapter, title, numeral }: { eyebrow: string; chapter: string; title: string; numeral?: string }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 32, alignItems: 'end', marginBottom: 64 }}>
      <div>
        <div style={{ marginBottom: 20 }}><Eyebrow chapter={chapter} label={eyebrow} /></div>
        <h2 style={{
          fontFamily: 'var(--font-heading)', fontSize: 'clamp(28px, 3.5vw, 44px)',
          fontWeight: 500, letterSpacing: '-0.025em', lineHeight: 1.2, color: t.ink,
        }}>{title}</h2>
      </div>
      {numeral && <ChapterNumeral n={numeral} />}
    </div>
  )
}

export function Btn({ children, variant = 'primary', href, onClick, type = 'button', disabled }: {
  children: React.ReactNode
  variant?: 'primary' | 'quiet' | 'ghost' | 'danger'
  href?: string
  onClick?: () => void
  type?: 'button' | 'submit'
  disabled?: boolean
}) {
  const styles: Record<string, React.CSSProperties> = {
    primary: { background: t.ink, color: t.wallPaper, border: `1px solid ${t.ink}` },
    quiet: { background: 'transparent', color: t.ink, border: `1px solid ${t.hairline}` },
    ghost: { background: 'transparent', color: t.ink, border: 'none' },
    danger: { background: t.destructive, color: t.wallPaper, border: `1px solid ${t.destructive}` },
  }
  const base: React.CSSProperties = {
    fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 500,
    padding: '10px 20px', borderRadius: 4, cursor: disabled ? 'not-allowed' : 'pointer',
    letterSpacing: '-0.01em', textDecoration: 'none', display: 'inline-flex',
    alignItems: 'center', gap: 6, transition: 'background 0.15s, opacity 0.15s',
    opacity: disabled ? 0.5 : 1, ...styles[variant],
  }
  if (href) return <a href={href} style={base}>{children}</a>
  return <button type={type} style={base} onClick={onClick} disabled={disabled}>{children}</button>
}

export function Field({ label, type = 'text', placeholder, required, hint }: {
  label: string; type?: string; placeholder?: string; required?: boolean; hint?: string
}) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <label style={{ fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 500, color: t.ink, letterSpacing: '-0.01em' }}>
        {label}{required && <span style={{ color: t.signal, marginLeft: 2 }}>*</span>}
      </label>
      <input type={type} placeholder={placeholder} style={{
        width: '100%', padding: '10px 12px', fontFamily: 'var(--font-sans)', fontSize: 14,
        color: t.ink, background: t.band, border: `1px solid ${t.hairlineStrong}`,
        borderRadius: 4, outline: 'none',
      }}
        onFocus={e => (e.currentTarget.style.borderColor = t.ink)}
        onBlur={e => (e.currentTarget.style.borderColor = t.hairlineStrong)}
      />
      {hint && <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: t.inkMuted }}>{hint}</span>}
    </div>
  )
}

export function PageShell({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{ maxWidth: 1240, margin: '0 auto', padding: '96px 64px', ...style }}>
      {children}
    </div>
  )
}

export function EmptyState({ icon, title, body, cta }: { icon: string; title: string; body: string; cta?: React.ReactNode }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      textAlign: 'center', padding: '80px 32px', gap: 16,
    }}>
      <div style={{ fontFamily: 'var(--font-heading)', fontSize: 48, color: t.hairline, lineHeight: 1 }}>{icon}</div>
      <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: 22, fontWeight: 500, letterSpacing: '-0.015em', color: t.ink }}>{title}</h3>
      <p style={{ fontFamily: 'var(--font-sans)', fontSize: 14, color: t.inkMuted, lineHeight: 1.7, maxWidth: 360 }}>{body}</p>
      {cta}
    </div>
  )
}

export function Badge({ label, color = 'default' }: { label: string; color?: 'default' | 'live' | 'held' | 'ended' | 'blocked' }) {
  const colors: Record<string, { bg: string; text: string }> = {
    default: { bg: t.wallCharcoal, text: t.inkMuted },
    live: { bg: '#dcfce7', text: '#166534' },
    held: { bg: '#fef9c3', text: '#854d0e' },
    ended: { bg: t.wallCharcoal, text: t.inkMuted },
    blocked: { bg: '#fee2e2', text: '#991b1b' },
  }
  const c = colors[color] || colors.default
  return (
    <span style={{
      fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 500,
      background: c.bg, color: c.text, padding: '3px 8px', borderRadius: 4,
      letterSpacing: '0.04em', textTransform: 'uppercase' as const,
    }}>{label}</span>
  )
}
