import { Outlet, Link } from 'react-router'
import { t } from '../components/tokens'

export default function AuthRoot() {
  return (
    <>
      {/* Minimal auth header */}
      <header style={{ position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100, background: t.wallPaper, borderBottom: `1px solid ${t.hairline}`, height: 56, display: 'flex', alignItems: 'center', padding: '0 32px' }}>
        <Link to="/" style={{ textDecoration: 'none', display: 'flex', flexDirection: 'column', gap: 1 }}>
          <span style={{ fontFamily: 'var(--font-heading)', fontSize: 16, fontWeight: 500, color: t.ink, letterSpacing: '-0.02em', lineHeight: 1 }}>ArtWall</span>
          <span style={{ fontFamily: 'var(--font-sans)', fontSize: 9, fontWeight: 400, color: t.inkMuted, letterSpacing: '0.12em', textTransform: 'uppercase' as const, lineHeight: 1 }}>Labs</span>
        </Link>
      </header>
      <main style={{ paddingTop: 56 }}>
        <Outlet />
      </main>
    </>
  )
}
